// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vtb_behavioral.h for the primary calling header

#include "Vtb_behavioral__pch.h"
#include "Vtb_behavioral__Syms.h"
#include "Vtb_behavioral___024root.h"

VL_INLINE_OPT VlCoroutine Vtb_behavioral___024root___eval_initial__TOP__Vtiming__0(Vtb_behavioral___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtb_behavioral__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_behavioral___024root___eval_initial__TOP__Vtiming__0\n"); );
    // Init
    VlWide<7>/*223:0*/ __Vtemp_1;
    // Body
    __Vtemp_1[0U] = 0x2e766364U;
    __Vtemp_1[1U] = 0x6f72616cU;
    __Vtemp_1[2U] = 0x68617669U;
    __Vtemp_1[3U] = 0x655f6265U;
    __Vtemp_1[4U] = 0x7a696f6eU;
    __Vtemp_1[5U] = 0x6d756c61U;
    __Vtemp_1[6U] = 0x7369U;
    vlSymsp->_vm_contextp__->dumpfile(VL_CVT_PACK_STR_NW(7, __Vtemp_1));
    vlSymsp->_traceDumpOpen();
    vlSelf->tb_behavioral__DOT__clk = 0U;
    vlSelf->tb_behavioral__DOT__rst = 0U;
    vlSelf->tb_behavioral__DOT__coin = 0U;
    vlSelf->tb_behavioral__DOT__selezione = 0U;
    vlSelf->tb_behavioral__DOT__conferma = 0U;
    vlSelf->tb_behavioral__DOT__annulla = 0U;
    co_await vlSelf->__VdlySched.delay(0x4e20ULL, nullptr, 
                                       "behavioral/tb_behavioral.v", 
                                       72);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_behavioral__DOT__rst = 1U;
    co_await vlSelf->__VtrigSched_h2394ed64__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_behavioral.clk)", 
                                                       "behavioral/tb_behavioral.v", 
                                                       173);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_behavioral__DOT__coin = 0U;
    vlSelf->tb_behavioral__DOT__selezione = 5U;
    co_await vlSelf->__VtrigSched_h2394ed64__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_behavioral.clk)", 
                                                       "behavioral/tb_behavioral.v", 
                                                       173);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_behavioral__DOT__coin = 0U;
    vlSelf->tb_behavioral__DOT__selezione = 3U;
    co_await vlSelf->__VtrigSched_h2394ed64__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_behavioral.clk)", 
                                                       "behavioral/tb_behavioral.v", 
                                                       173);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_behavioral__DOT__coin = 0U;
    vlSelf->tb_behavioral__DOT__selezione = 5U;
    co_await vlSelf->__VtrigSched_h2394ed64__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_behavioral.clk)", 
                                                       "behavioral/tb_behavioral.v", 
                                                       173);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_behavioral__DOT__coin = 0U;
    vlSelf->tb_behavioral__DOT__selezione = 5U;
    co_await vlSelf->__VtrigSched_h2394ed64__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_behavioral.clk)", 
                                                       "behavioral/tb_behavioral.v", 
                                                       173);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_behavioral__DOT__coin = 0U;
    vlSelf->tb_behavioral__DOT__selezione = 5U;
    co_await vlSelf->__VtrigSched_h2394ed64__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_behavioral.clk)", 
                                                       "behavioral/tb_behavioral.v", 
                                                       173);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_behavioral__DOT__coin = 1U;
    vlSelf->tb_behavioral__DOT__selezione = 0U;
    co_await vlSelf->__VtrigSched_h2394ed64__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_behavioral.clk)", 
                                                       "behavioral/tb_behavioral.v", 
                                                       173);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_behavioral__DOT__coin = 0U;
    vlSelf->tb_behavioral__DOT__selezione = 2U;
    co_await vlSelf->__VtrigSched_h2394ed64__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_behavioral.clk)", 
                                                       "behavioral/tb_behavioral.v", 
                                                       173);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_behavioral__DOT__coin = 1U;
    vlSelf->tb_behavioral__DOT__selezione = 4U;
    co_await vlSelf->__VtrigSched_h2394ed64__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_behavioral.clk)", 
                                                       "behavioral/tb_behavioral.v", 
                                                       173);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_behavioral__DOT__coin = 1U;
    vlSelf->tb_behavioral__DOT__selezione = 2U;
    co_await vlSelf->__VtrigSched_h2394ed64__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_behavioral.clk)", 
                                                       "behavioral/tb_behavioral.v", 
                                                       173);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_behavioral__DOT__coin = 1U;
    vlSelf->tb_behavioral__DOT__selezione = 2U;
    co_await vlSelf->__VtrigSched_h2394ed64__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_behavioral.clk)", 
                                                       "behavioral/tb_behavioral.v", 
                                                       173);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_behavioral__DOT__coin = 1U;
    vlSelf->tb_behavioral__DOT__selezione = 2U;
    co_await vlSelf->__VtrigSched_h2394ed64__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_behavioral.clk)", 
                                                       "behavioral/tb_behavioral.v", 
                                                       173);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_behavioral__DOT__coin = 0U;
    vlSelf->tb_behavioral__DOT__selezione = 2U;
    co_await vlSelf->__VtrigSched_h2394ed64__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_behavioral.clk)", 
                                                       "behavioral/tb_behavioral.v", 
                                                       173);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_behavioral__DOT__coin = 0U;
    vlSelf->tb_behavioral__DOT__selezione = 0U;
    VL_WRITEF("--- CONFIGURAZIONE TERMINATA ---\n");
    co_await vlSelf->__VdlySched.delay(0x4e20ULL, nullptr, 
                                       "behavioral/tb_behavioral.v", 
                                       113);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    co_await vlSelf->__VtrigSched_h2394ed64__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_behavioral.clk)", 
                                                       "behavioral/tb_behavioral.v", 
                                                       173);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_behavioral__DOT__coin = 6U;
    co_await vlSelf->__VtrigSched_h2394ed64__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_behavioral.clk)", 
                                                       "behavioral/tb_behavioral.v", 
                                                       173);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_behavioral__DOT__coin = 0U;
    co_await vlSelf->__VdlySched.delay(0x2710ULL, nullptr, 
                                       "behavioral/tb_behavioral.v", 
                                       117);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    co_await vlSelf->__VtrigSched_h2394ed64__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_behavioral.clk)", 
                                                       "behavioral/tb_behavioral.v", 
                                                       173);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_behavioral__DOT__selezione = 5U;
    vlSelf->tb_behavioral__DOT__conferma = 1U;
    co_await vlSelf->__VtrigSched_h2394ed64__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_behavioral.clk)", 
                                                       "behavioral/tb_behavioral.v", 
                                                       173);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_behavioral__DOT__conferma = 0U;
    vlSelf->tb_behavioral__DOT__selezione = 0U;
    VL_WRITEF("Test 1: Acquisto P2 (0.5\342\202\254) con 0.5\342\202\254. Atteso: Prod2=1, Resto=0\n");
    co_await vlSelf->__VdlySched.delay(0x4e20ULL, nullptr, 
                                       "behavioral/tb_behavioral.v", 
                                       123);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    co_await vlSelf->__VtrigSched_h2394ed64__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_behavioral.clk)", 
                                                       "behavioral/tb_behavioral.v", 
                                                       173);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_behavioral__DOT__coin = 7U;
    co_await vlSelf->__VtrigSched_h2394ed64__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_behavioral.clk)", 
                                                       "behavioral/tb_behavioral.v", 
                                                       173);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_behavioral__DOT__coin = 0U;
    co_await vlSelf->__VtrigSched_h2394ed64__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_behavioral.clk)", 
                                                       "behavioral/tb_behavioral.v", 
                                                       173);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_behavioral__DOT__selezione = 4U;
    vlSelf->tb_behavioral__DOT__conferma = 1U;
    co_await vlSelf->__VtrigSched_h2394ed64__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_behavioral.clk)", 
                                                       "behavioral/tb_behavioral.v", 
                                                       173);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_behavioral__DOT__conferma = 0U;
    vlSelf->tb_behavioral__DOT__selezione = 0U;
    VL_WRITEF("Test 2: Acquisto P1 (0.3\342\202\254) con 1.0\342\202\254. Atteso: Resto=0.7 (1x0.5, 1x0.2)\n");
    co_await vlSelf->__VdlySched.delay(0x4e20ULL, nullptr, 
                                       "behavioral/tb_behavioral.v", 
                                       137);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    co_await vlSelf->__VtrigSched_h2394ed64__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_behavioral.clk)", 
                                                       "behavioral/tb_behavioral.v", 
                                                       173);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_behavioral__DOT__coin = 4U;
    co_await vlSelf->__VtrigSched_h2394ed64__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_behavioral.clk)", 
                                                       "behavioral/tb_behavioral.v", 
                                                       173);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_behavioral__DOT__coin = 0U;
    co_await vlSelf->__VtrigSched_h2394ed64__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_behavioral.clk)", 
                                                       "behavioral/tb_behavioral.v", 
                                                       173);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_behavioral__DOT__selezione = 7U;
    vlSelf->tb_behavioral__DOT__conferma = 1U;
    co_await vlSelf->__VtrigSched_h2394ed64__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_behavioral.clk)", 
                                                       "behavioral/tb_behavioral.v", 
                                                       173);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_behavioral__DOT__conferma = 0U;
    vlSelf->tb_behavioral__DOT__selezione = 0U;
    VL_WRITEF("Test 3: Credito insufficiente. Atteso: Errore=01, Resto mostra prezzo (12)\n");
    co_await vlSelf->__VdlySched.delay(0x4e20ULL, nullptr, 
                                       "behavioral/tb_behavioral.v", 
                                       153);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    co_await vlSelf->__VtrigSched_h2394ed64__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_behavioral.clk)", 
                                                       "behavioral/tb_behavioral.v", 
                                                       173);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_behavioral__DOT__coin = 6U;
    co_await vlSelf->__VtrigSched_h2394ed64__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_behavioral.clk)", 
                                                       "behavioral/tb_behavioral.v", 
                                                       173);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_behavioral__DOT__coin = 0U;
    co_await vlSelf->__VtrigSched_h2394ed64__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_behavioral.clk)", 
                                                       "behavioral/tb_behavioral.v", 
                                                       173);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_behavioral__DOT__annulla = 1U;
    co_await vlSelf->__VtrigSched_h2394ed64__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_behavioral.clk)", 
                                                       "behavioral/tb_behavioral.v", 
                                                       173);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_behavioral__DOT__annulla = 0U;
    VL_WRITEF("Test 4: Annulla. Atteso: Resto=5 (tutto il credito), Credito=0\n");
    co_await vlSelf->__VdlySched.delay(0x4e20ULL, nullptr, 
                                       "behavioral/tb_behavioral.v", 
                                       165);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    VL_FINISH_MT("behavioral/tb_behavioral.v", 167, "");
    vlSelf->__Vm_traceActivity[2U] = 1U;
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vtb_behavioral___024root___dump_triggers__act(Vtb_behavioral___024root* vlSelf);
#endif  // VL_DEBUG

void Vtb_behavioral___024root___eval_triggers__act(Vtb_behavioral___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtb_behavioral__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_behavioral___024root___eval_triggers__act\n"); );
    // Body
    vlSelf->__VactTriggered.set(0U, (((IData)(vlSelf->tb_behavioral__DOT__clk) 
                                      & (~ (IData)(vlSelf->__Vtrigprevexpr___TOP__tb_behavioral__DOT__clk__0))) 
                                     | ((~ (IData)(vlSelf->tb_behavioral__DOT__rst)) 
                                        & (IData)(vlSelf->__Vtrigprevexpr___TOP__tb_behavioral__DOT__rst__0))));
    vlSelf->__VactTriggered.set(1U, vlSelf->__VdlySched.awaitingCurrentTime());
    vlSelf->__VactTriggered.set(2U, ((~ (IData)(vlSelf->tb_behavioral__DOT__clk)) 
                                     & (IData)(vlSelf->__Vtrigprevexpr___TOP__tb_behavioral__DOT__clk__0)));
    vlSelf->__Vtrigprevexpr___TOP__tb_behavioral__DOT__clk__0 
        = vlSelf->tb_behavioral__DOT__clk;
    vlSelf->__Vtrigprevexpr___TOP__tb_behavioral__DOT__rst__0 
        = vlSelf->tb_behavioral__DOT__rst;
#ifdef VL_DEBUG
    if (VL_UNLIKELY(vlSymsp->_vm_contextp__->debug())) {
        Vtb_behavioral___024root___dump_triggers__act(vlSelf);
    }
#endif
}
