// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Tracing implementation internals
#include "verilated_vcd_c.h"
#include "Vtb_behavioral__Syms.h"


void Vtb_behavioral___024root__trace_chg_0_sub_0(Vtb_behavioral___024root* vlSelf, VerilatedVcd::Buffer* bufp);

void Vtb_behavioral___024root__trace_chg_0(void* voidSelf, VerilatedVcd::Buffer* bufp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_behavioral___024root__trace_chg_0\n"); );
    // Init
    Vtb_behavioral___024root* const __restrict vlSelf VL_ATTR_UNUSED = static_cast<Vtb_behavioral___024root*>(voidSelf);
    Vtb_behavioral__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    if (VL_UNLIKELY(!vlSymsp->__Vm_activity)) return;
    // Body
    Vtb_behavioral___024root__trace_chg_0_sub_0((&vlSymsp->TOP), bufp);
}

void Vtb_behavioral___024root__trace_chg_0_sub_0(Vtb_behavioral___024root* vlSelf, VerilatedVcd::Buffer* bufp) {
    if (false && vlSelf) {}  // Prevent unused
    Vtb_behavioral__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_behavioral___024root__trace_chg_0_sub_0\n"); );
    // Init
    uint32_t* const oldp VL_ATTR_UNUSED = bufp->oldp(vlSymsp->__Vm_baseCode + 1);
    // Body
    if (VL_UNLIKELY((vlSelf->__Vm_traceActivity[1U] 
                     | vlSelf->__Vm_traceActivity[2U]))) {
        bufp->chgBit(oldp+0,(vlSelf->tb_behavioral__DOT__rst));
        bufp->chgCData(oldp+1,(vlSelf->tb_behavioral__DOT__coin),3);
        bufp->chgCData(oldp+2,(vlSelf->tb_behavioral__DOT__selezione),3);
        bufp->chgBit(oldp+3,(vlSelf->tb_behavioral__DOT__conferma));
        bufp->chgBit(oldp+4,(vlSelf->tb_behavioral__DOT__annulla));
    }
    if (VL_UNLIKELY(vlSelf->__Vm_traceActivity[3U])) {
        bufp->chgCData(oldp+5,(vlSelf->tb_behavioral__DOT__credito),6);
        bufp->chgBit(oldp+6,(vlSelf->tb_behavioral__DOT__prodotto1));
        bufp->chgBit(oldp+7,(vlSelf->tb_behavioral__DOT__prodotto2));
        bufp->chgBit(oldp+8,(vlSelf->tb_behavioral__DOT__prodotto3));
        bufp->chgBit(oldp+9,(vlSelf->tb_behavioral__DOT__prodotto4));
        bufp->chgCData(oldp+10,(vlSelf->tb_behavioral__DOT__errore),2);
        bufp->chgCData(oldp+11,(vlSelf->tb_behavioral__DOT__resto),6);
        bufp->chgSData(oldp+12,(vlSelf->tb_behavioral__DOT__disponibile),10);
        bufp->chgCData(oldp+13,(vlSelf->tb_behavioral__DOT__coin_01),6);
        bufp->chgCData(oldp+14,(vlSelf->tb_behavioral__DOT__coin_02),6);
        bufp->chgCData(oldp+15,(vlSelf->tb_behavioral__DOT__coin_05),6);
        bufp->chgCData(oldp+16,(vlSelf->tb_behavioral__DOT__coin_10),6);
        bufp->chgCData(oldp+17,(vlSelf->tb_behavioral__DOT__dut__DOT__stato),2);
        bufp->chgCData(oldp+18,(vlSelf->tb_behavioral__DOT__dut__DOT__init_counter),4);
        bufp->chgCData(oldp+19,(vlSelf->tb_behavioral__DOT__dut__DOT__qty_p1),6);
        bufp->chgCData(oldp+20,(vlSelf->tb_behavioral__DOT__dut__DOT__qty_p2),6);
        bufp->chgCData(oldp+21,(vlSelf->tb_behavioral__DOT__dut__DOT__qty_p3),6);
        bufp->chgCData(oldp+22,(vlSelf->tb_behavioral__DOT__dut__DOT__qty_p4),6);
        bufp->chgCData(oldp+23,(vlSelf->tb_behavioral__DOT__dut__DOT__price_p1),6);
        bufp->chgCData(oldp+24,(vlSelf->tb_behavioral__DOT__dut__DOT__price_p2),6);
        bufp->chgCData(oldp+25,(vlSelf->tb_behavioral__DOT__dut__DOT__price_p3),6);
        bufp->chgCData(oldp+26,(vlSelf->tb_behavioral__DOT__dut__DOT__price_p4),6);
        bufp->chgCData(oldp+27,(vlSelf->tb_behavioral__DOT__dut__DOT__qty_c01),6);
        bufp->chgCData(oldp+28,(vlSelf->tb_behavioral__DOT__dut__DOT__qty_c02),6);
        bufp->chgCData(oldp+29,(vlSelf->tb_behavioral__DOT__dut__DOT__qty_c05),6);
        bufp->chgCData(oldp+30,(vlSelf->tb_behavioral__DOT__dut__DOT__qty_c10),6);
        bufp->chgCData(oldp+31,(vlSelf->tb_behavioral__DOT__dut__DOT__calc_resto),6);
        bufp->chgCData(oldp+32,(vlSelf->tb_behavioral__DOT__dut__DOT__calc_qty),6);
        bufp->chgCData(oldp+33,(vlSelf->tb_behavioral__DOT__dut__DOT__current_price),6);
    }
    bufp->chgBit(oldp+34,(vlSelf->tb_behavioral__DOT__clk));
}

void Vtb_behavioral___024root__trace_cleanup(void* voidSelf, VerilatedVcd* /*unused*/) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_behavioral___024root__trace_cleanup\n"); );
    // Init
    Vtb_behavioral___024root* const __restrict vlSelf VL_ATTR_UNUSED = static_cast<Vtb_behavioral___024root*>(voidSelf);
    Vtb_behavioral__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    // Body
    vlSymsp->__Vm_activity = false;
    vlSymsp->TOP.__Vm_traceActivity[0U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[1U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[2U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[3U] = 0U;
}
