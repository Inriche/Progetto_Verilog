// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Tracing implementation internals
#include "verilated_vcd_c.h"
#include "Vtestbench__Syms.h"


void Vtestbench___024root__trace_chg_0_sub_0(Vtestbench___024root* vlSelf, VerilatedVcd::Buffer* bufp);

void Vtestbench___024root__trace_chg_0(void* voidSelf, VerilatedVcd::Buffer* bufp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtestbench___024root__trace_chg_0\n"); );
    // Init
    Vtestbench___024root* const __restrict vlSelf VL_ATTR_UNUSED = static_cast<Vtestbench___024root*>(voidSelf);
    Vtestbench__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    if (VL_UNLIKELY(!vlSymsp->__Vm_activity)) return;
    // Body
    Vtestbench___024root__trace_chg_0_sub_0((&vlSymsp->TOP), bufp);
}

void Vtestbench___024root__trace_chg_0_sub_0(Vtestbench___024root* vlSelf, VerilatedVcd::Buffer* bufp) {
    if (false && vlSelf) {}  // Prevent unused
    Vtestbench__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtestbench___024root__trace_chg_0_sub_0\n"); );
    // Init
    uint32_t* const oldp VL_ATTR_UNUSED = bufp->oldp(vlSymsp->__Vm_baseCode + 1);
    // Body
    if (VL_UNLIKELY((vlSelf->__Vm_traceActivity[1U] 
                     | vlSelf->__Vm_traceActivity[2U]))) {
        bufp->chgBit(oldp+0,(vlSelf->testbench__DOT__rst));
        bufp->chgCData(oldp+1,(vlSelf->testbench__DOT__coin),3);
        bufp->chgCData(oldp+2,(vlSelf->testbench__DOT__selezione),3);
        bufp->chgBit(oldp+3,(vlSelf->testbench__DOT__conferma));
        bufp->chgBit(oldp+4,(vlSelf->testbench__DOT__annulla));
        bufp->chgCData(oldp+5,((3U & (IData)(vlSelf->testbench__DOT__selezione))),2);
        bufp->chgBit(oldp+6,((4U == (IData)(vlSelf->testbench__DOT__selezione))));
        bufp->chgBit(oldp+7,((5U == (IData)(vlSelf->testbench__DOT__selezione))));
        bufp->chgBit(oldp+8,((6U == (IData)(vlSelf->testbench__DOT__selezione))));
        bufp->chgBit(oldp+9,((7U == (IData)(vlSelf->testbench__DOT__selezione))));
    }
    if (VL_UNLIKELY((vlSelf->__Vm_traceActivity[3U] 
                     | vlSelf->__Vm_traceActivity[6U]))) {
        bufp->chgBit(oldp+10,(vlSelf->testbench__DOT__str_inst__DOT__do_cancel));
        bufp->chgBit(oldp+11,(vlSelf->testbench__DOT__str_inst__DOT__do_err));
        bufp->chgBit(oldp+12,(vlSelf->testbench__DOT__str_inst__DOT__do_ok));
        bufp->chgBit(oldp+13,(vlSelf->testbench__DOT__str_inst__DOT__c_prod1));
        bufp->chgBit(oldp+14,(vlSelf->testbench__DOT__str_inst__DOT__c_prod2));
        bufp->chgBit(oldp+15,(vlSelf->testbench__DOT__str_inst__DOT__c_prod3));
        bufp->chgBit(oldp+16,(vlSelf->testbench__DOT__str_inst__DOT__c_prod4));
        bufp->chgBit(oldp+17,(vlSelf->testbench__DOT__str_inst__DOT__is_credito_suff));
        bufp->chgBit(oldp+18,(vlSelf->testbench__DOT__str_inst__DOT__do_dec_p1));
        bufp->chgBit(oldp+19,(vlSelf->testbench__DOT__str_inst__DOT__do_dec_p2));
        bufp->chgBit(oldp+20,(vlSelf->testbench__DOT__str_inst__DOT__do_dec_p3));
        bufp->chgBit(oldp+21,(vlSelf->testbench__DOT__str_inst__DOT__do_dec_p4));
        bufp->chgBit(oldp+22,(vlSelf->testbench__DOT__str_inst__DOT__we_prod));
        bufp->chgBit(oldp+23,(vlSelf->testbench__DOT__str_inst__DOT__credito_insuff));
        bufp->chgBit(oldp+24,(vlSelf->testbench__DOT__str_inst__DOT__we_credito));
        bufp->chgCData(oldp+25,(vlSelf->testbench__DOT__str_inst__DOT__CTRL__DOT__next_stato),2);
    }
    if (VL_UNLIKELY(vlSelf->__Vm_traceActivity[4U])) {
        bufp->chgBit(oldp+26,(vlSelf->testbench__DOT__str_inst__DOT__mode_init));
        bufp->chgCData(oldp+27,(vlSelf->testbench__DOT__str_inst__DOT__init_counter_w),4);
        bufp->chgCData(oldp+28,(vlSelf->testbench__DOT__str_inst__DOT__sel_latched),3);
        bufp->chgCData(oldp+29,(vlSelf->testbench__DOT__str_inst__DOT__qty_p1_q),6);
        bufp->chgCData(oldp+30,(vlSelf->testbench__DOT__str_inst__DOT__qty_p2_q),6);
        bufp->chgCData(oldp+31,(vlSelf->testbench__DOT__str_inst__DOT__qty_p3_q),6);
        bufp->chgCData(oldp+32,(vlSelf->testbench__DOT__str_inst__DOT__qty_p4_q),6);
        bufp->chgCData(oldp+33,(vlSelf->testbench__DOT__str_inst__DOT__price_p1_q),6);
        bufp->chgCData(oldp+34,(vlSelf->testbench__DOT__str_inst__DOT__price_p2_q),6);
        bufp->chgCData(oldp+35,(vlSelf->testbench__DOT__str_inst__DOT__price_p3_q),6);
        bufp->chgCData(oldp+36,(vlSelf->testbench__DOT__str_inst__DOT__price_p4_q),6);
        bufp->chgCData(oldp+37,(vlSelf->testbench__DOT__str_inst__DOT__qty_c01_q),6);
        bufp->chgCData(oldp+38,(vlSelf->testbench__DOT__str_inst__DOT__qty_c02_q),6);
        bufp->chgCData(oldp+39,(vlSelf->testbench__DOT__str_inst__DOT__qty_c05_q),6);
        bufp->chgCData(oldp+40,(vlSelf->testbench__DOT__str_inst__DOT__qty_c10_q),6);
        bufp->chgCData(oldp+41,(vlSelf->testbench__DOT__str_inst__DOT__current_price_q),6);
        bufp->chgBit(oldp+42,(vlSelf->testbench__DOT__str_inst__DOT__init_qty_p1));
        bufp->chgBit(oldp+43,(vlSelf->testbench__DOT__str_inst__DOT__init_price_p1));
        bufp->chgBit(oldp+44,(vlSelf->testbench__DOT__str_inst__DOT__init_qty_p2));
        bufp->chgBit(oldp+45,(vlSelf->testbench__DOT__str_inst__DOT__init_price_p2));
        bufp->chgBit(oldp+46,(vlSelf->testbench__DOT__str_inst__DOT__init_qty_p3));
        bufp->chgBit(oldp+47,(vlSelf->testbench__DOT__str_inst__DOT__init_price_p3));
        bufp->chgBit(oldp+48,(vlSelf->testbench__DOT__str_inst__DOT__init_qty_p4));
        bufp->chgBit(oldp+49,(vlSelf->testbench__DOT__str_inst__DOT__init_price_p4));
        bufp->chgBit(oldp+50,(vlSelf->testbench__DOT__str_inst__DOT__init_c01));
        bufp->chgBit(oldp+51,(vlSelf->testbench__DOT__str_inst__DOT__init_c02));
        bufp->chgBit(oldp+52,(vlSelf->testbench__DOT__str_inst__DOT__init_c05));
        bufp->chgBit(oldp+53,(vlSelf->testbench__DOT__str_inst__DOT__init_c10));
        bufp->chgCData(oldp+54,((0x3fU & ((IData)(vlSelf->testbench__DOT__str_inst__DOT__qty_p1_q) 
                                          - (IData)(1U)))),6);
        bufp->chgCData(oldp+55,((0x3fU & ((IData)(vlSelf->testbench__DOT__str_inst__DOT__qty_p2_q) 
                                          - (IData)(1U)))),6);
        bufp->chgCData(oldp+56,((0x3fU & ((IData)(vlSelf->testbench__DOT__str_inst__DOT__qty_p3_q) 
                                          - (IData)(1U)))),6);
        bufp->chgCData(oldp+57,((0x3fU & ((IData)(vlSelf->testbench__DOT__str_inst__DOT__qty_p4_q) 
                                          - (IData)(1U)))),6);
        bufp->chgCData(oldp+58,(vlSelf->testbench__DOT__str_inst__DOT__CTRL__DOT__stato),2);
    }
    if (VL_UNLIKELY(vlSelf->__Vm_traceActivity[5U])) {
        bufp->chgCData(oldp+59,(vlSelf->testbench__DOT__credito_b),6);
        bufp->chgCData(oldp+60,(vlSelf->testbench__DOT__str_inst__DOT__credito_q),6);
        bufp->chgBit(oldp+61,(vlSelf->testbench__DOT__p1_b));
        bufp->chgBit(oldp+62,(vlSelf->testbench__DOT__p2_b));
        bufp->chgBit(oldp+63,(vlSelf->testbench__DOT__p3_b));
        bufp->chgBit(oldp+64,(vlSelf->testbench__DOT__p4_b));
        bufp->chgBit(oldp+65,(vlSelf->testbench__DOT__str_inst__DOT__prod1_q));
        bufp->chgBit(oldp+66,(vlSelf->testbench__DOT__str_inst__DOT__prod2_q));
        bufp->chgBit(oldp+67,(vlSelf->testbench__DOT__str_inst__DOT__prod3_q));
        bufp->chgBit(oldp+68,(vlSelf->testbench__DOT__str_inst__DOT__prod4_q));
        bufp->chgCData(oldp+69,(vlSelf->testbench__DOT__errore_b),2);
        bufp->chgCData(oldp+70,(vlSelf->testbench__DOT__str_inst__DOT__errore_q),2);
        bufp->chgCData(oldp+71,(vlSelf->testbench__DOT__resto_b),6);
        bufp->chgCData(oldp+72,(vlSelf->testbench__DOT__str_inst__DOT__resto_q),6);
        bufp->chgSData(oldp+73,(vlSelf->testbench__DOT__disp_b),10);
        bufp->chgSData(oldp+74,(vlSelf->testbench__DOT__str_inst__DOT__disponibile_q),10);
        bufp->chgCData(oldp+75,(vlSelf->testbench__DOT__c01_b),6);
        bufp->chgCData(oldp+76,(vlSelf->testbench__DOT__c02_b),6);
        bufp->chgCData(oldp+77,(vlSelf->testbench__DOT__c05_b),6);
        bufp->chgCData(oldp+78,(vlSelf->testbench__DOT__c10_b),6);
        bufp->chgCData(oldp+79,(vlSelf->testbench__DOT__str_inst__DOT__coin01_q),6);
        bufp->chgCData(oldp+80,(vlSelf->testbench__DOT__str_inst__DOT__coin02_q),6);
        bufp->chgCData(oldp+81,(vlSelf->testbench__DOT__str_inst__DOT__coin05_q),6);
        bufp->chgCData(oldp+82,(vlSelf->testbench__DOT__str_inst__DOT__coin10_q),6);
        bufp->chgCData(oldp+83,(vlSelf->testbench__DOT__beh_inst__DOT__stato),2);
        bufp->chgCData(oldp+84,(vlSelf->testbench__DOT__beh_inst__DOT__init_counter),4);
        bufp->chgCData(oldp+85,(vlSelf->testbench__DOT__beh_inst__DOT__qty_p1),6);
        bufp->chgCData(oldp+86,(vlSelf->testbench__DOT__beh_inst__DOT__qty_p2),6);
        bufp->chgCData(oldp+87,(vlSelf->testbench__DOT__beh_inst__DOT__qty_p3),6);
        bufp->chgCData(oldp+88,(vlSelf->testbench__DOT__beh_inst__DOT__qty_p4),6);
        bufp->chgCData(oldp+89,(vlSelf->testbench__DOT__beh_inst__DOT__price_p1),6);
        bufp->chgCData(oldp+90,(vlSelf->testbench__DOT__beh_inst__DOT__price_p2),6);
        bufp->chgCData(oldp+91,(vlSelf->testbench__DOT__beh_inst__DOT__price_p3),6);
        bufp->chgCData(oldp+92,(vlSelf->testbench__DOT__beh_inst__DOT__price_p4),6);
        bufp->chgCData(oldp+93,(vlSelf->testbench__DOT__beh_inst__DOT__qty_c01),6);
        bufp->chgCData(oldp+94,(vlSelf->testbench__DOT__beh_inst__DOT__qty_c02),6);
        bufp->chgCData(oldp+95,(vlSelf->testbench__DOT__beh_inst__DOT__qty_c05),6);
        bufp->chgCData(oldp+96,(vlSelf->testbench__DOT__beh_inst__DOT__qty_c10),6);
        bufp->chgCData(oldp+97,(vlSelf->testbench__DOT__beh_inst__DOT__calc_resto),6);
        bufp->chgCData(oldp+98,(vlSelf->testbench__DOT__beh_inst__DOT__calc_qty),6);
        bufp->chgCData(oldp+99,(vlSelf->testbench__DOT__beh_inst__DOT__current_price),6);
        bufp->chgBit(oldp+100,(vlSelf->testbench__DOT__str_inst__DOT__clear_outputs));
        bufp->chgBit(oldp+101,(vlSelf->testbench__DOT__str_inst__DOT__do_erogazione));
        bufp->chgCData(oldp+102,(vlSelf->testbench__DOT__str_inst__DOT__change6),6);
        bufp->chgSData(oldp+103,(vlSelf->testbench__DOT__str_inst__DOT__change6),10);
        bufp->chgSData(oldp+104,(vlSelf->testbench__DOT__str_inst__DOT__credito_q),10);
        bufp->chgSData(oldp+105,((0x3ffU & ((IData)(vlSelf->testbench__DOT__str_inst__DOT__disponibile_q) 
                                            - (IData)(vlSelf->testbench__DOT__str_inst__DOT__credito_q)))),10);
        bufp->chgSData(oldp+106,((0x3ffU & ((IData)(vlSelf->testbench__DOT__str_inst__DOT__disponibile_q) 
                                            - (IData)(vlSelf->testbench__DOT__str_inst__DOT__change6)))),10);
        bufp->chgCData(oldp+107,(vlSelf->testbench__DOT__str_inst__DOT__c10_calc),6);
        bufp->chgCData(oldp+108,(vlSelf->testbench__DOT__str_inst__DOT__c05_calc),6);
        bufp->chgCData(oldp+109,(vlSelf->testbench__DOT__str_inst__DOT__c02_calc),6);
        bufp->chgCData(oldp+110,(vlSelf->testbench__DOT__str_inst__DOT__c01_calc),6);
        bufp->chgCData(oldp+111,(vlSelf->testbench__DOT__str_inst__DOT__qc10_next),6);
        bufp->chgCData(oldp+112,(vlSelf->testbench__DOT__str_inst__DOT__qc05_next),6);
        bufp->chgCData(oldp+113,(vlSelf->testbench__DOT__str_inst__DOT__qc02_next),6);
        bufp->chgCData(oldp+114,(vlSelf->testbench__DOT__str_inst__DOT__qc01_next),6);
        bufp->chgCData(oldp+115,(((IData)(vlSelf->testbench__DOT__str_inst__DOT__clear_outputs)
                                   ? 0U : ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_erogazione)
                                            ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__c10_calc)
                                            : (IData)(vlSelf->testbench__DOT__str_inst__DOT__coin10_q)))),6);
        bufp->chgCData(oldp+116,(((IData)(vlSelf->testbench__DOT__str_inst__DOT__clear_outputs)
                                   ? 0U : ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_erogazione)
                                            ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__c05_calc)
                                            : (IData)(vlSelf->testbench__DOT__str_inst__DOT__coin05_q)))),6);
        bufp->chgCData(oldp+117,(((IData)(vlSelf->testbench__DOT__str_inst__DOT__clear_outputs)
                                   ? 0U : ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_erogazione)
                                            ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__c02_calc)
                                            : (IData)(vlSelf->testbench__DOT__str_inst__DOT__coin02_q)))),6);
        bufp->chgCData(oldp+118,(((IData)(vlSelf->testbench__DOT__str_inst__DOT__clear_outputs)
                                   ? 0U : ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_erogazione)
                                            ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__c01_calc)
                                            : (IData)(vlSelf->testbench__DOT__str_inst__DOT__coin01_q)))),6);
        bufp->chgBit(oldp+119,(vlSelf->testbench__DOT__str_inst__DOT__we_coin_out));
        bufp->chgCData(oldp+120,(vlSelf->testbench__DOT__str_inst__DOT__greedy_inst__DOT__calc_resto),6);
        bufp->chgCData(oldp+121,(vlSelf->testbench__DOT__str_inst__DOT__greedy_inst__DOT__calc_qty),6);
    }
    bufp->chgBit(oldp+122,(vlSelf->testbench__DOT__clk));
    bufp->chgIData(oldp+123,(vlSelf->testbench__DOT__cycle_count),32);
    bufp->chgIData(oldp+124,(vlSelf->testbench__DOT__mismatch_count),32);
    bufp->chgBit(oldp+125,(vlSelf->testbench__DOT__str_inst__DOT__do_add_coin));
    bufp->chgBit(oldp+126,((0U != (IData)(vlSelf->testbench__DOT__str_inst__DOT__sel_qty))));
    bufp->chgCData(oldp+127,(vlSelf->testbench__DOT__str_inst__DOT__init_data),6);
    bufp->chgCData(oldp+128,(vlSelf->testbench__DOT__str_inst__DOT__coin_value),6);
    bufp->chgCData(oldp+129,(vlSelf->testbench__DOT__str_inst__DOT__sel_price),6);
    bufp->chgCData(oldp+130,(vlSelf->testbench__DOT__str_inst__DOT__sel_qty),6);
    bufp->chgCData(oldp+131,((0x3fU & ((IData)(vlSelf->testbench__DOT__str_inst__DOT__coin_value) 
                                       + (IData)(vlSelf->testbench__DOT__str_inst__DOT__credito_q)))),6);
    bufp->chgSData(oldp+132,(vlSelf->testbench__DOT__str_inst__DOT__coin_value),10);
    bufp->chgSData(oldp+133,((0x3ffU & ((IData)(vlSelf->testbench__DOT__str_inst__DOT__disponibile_q) 
                                        + (IData)(vlSelf->testbench__DOT__str_inst__DOT__coin_value)))),10);
    bufp->chgCData(oldp+134,((0x3fU & ((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_qty_p1)
                                        ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_data)
                                        : ((IData)(vlSelf->testbench__DOT__str_inst__DOT__qty_p1_q) 
                                           - (IData)(vlSelf->testbench__DOT__str_inst__DOT__do_dec_p1))))),6);
    bufp->chgCData(oldp+135,((0x3fU & ((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_qty_p2)
                                        ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_data)
                                        : ((IData)(vlSelf->testbench__DOT__str_inst__DOT__qty_p2_q) 
                                           - (IData)(vlSelf->testbench__DOT__str_inst__DOT__do_dec_p2))))),6);
    bufp->chgCData(oldp+136,((0x3fU & ((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_qty_p3)
                                        ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_data)
                                        : ((IData)(vlSelf->testbench__DOT__str_inst__DOT__qty_p3_q) 
                                           - (IData)(vlSelf->testbench__DOT__str_inst__DOT__do_dec_p3))))),6);
    bufp->chgCData(oldp+137,((0x3fU & ((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_qty_p4)
                                        ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_data)
                                        : ((IData)(vlSelf->testbench__DOT__str_inst__DOT__qty_p4_q) 
                                           - (IData)(vlSelf->testbench__DOT__str_inst__DOT__do_dec_p4))))),6);
    bufp->chgBit(oldp+138,(((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_qty_p1) 
                            | (IData)(vlSelf->testbench__DOT__str_inst__DOT__do_dec_p1))));
    bufp->chgBit(oldp+139,(((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_qty_p2) 
                            | (IData)(vlSelf->testbench__DOT__str_inst__DOT__do_dec_p2))));
    bufp->chgBit(oldp+140,(((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_qty_p3) 
                            | (IData)(vlSelf->testbench__DOT__str_inst__DOT__do_dec_p3))));
    bufp->chgBit(oldp+141,(((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_qty_p4) 
                            | (IData)(vlSelf->testbench__DOT__str_inst__DOT__do_dec_p4))));
    bufp->chgCData(oldp+142,(((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_price_p1)
                               ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_data)
                               : (IData)(vlSelf->testbench__DOT__str_inst__DOT__price_p1_q))),6);
    bufp->chgCData(oldp+143,(((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_price_p2)
                               ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_data)
                               : (IData)(vlSelf->testbench__DOT__str_inst__DOT__price_p2_q))),6);
    bufp->chgCData(oldp+144,(((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_price_p3)
                               ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_data)
                               : (IData)(vlSelf->testbench__DOT__str_inst__DOT__price_p3_q))),6);
    bufp->chgCData(oldp+145,(((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_price_p4)
                               ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_data)
                               : (IData)(vlSelf->testbench__DOT__str_inst__DOT__price_p4_q))),6);
    bufp->chgCData(oldp+146,(((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_c01)
                               ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_data)
                               : ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_erogazione)
                                   ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__qc01_next)
                                   : (IData)(vlSelf->testbench__DOT__str_inst__DOT__qty_c01_q)))),6);
    bufp->chgCData(oldp+147,(((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_c02)
                               ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_data)
                               : ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_erogazione)
                                   ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__qc02_next)
                                   : (IData)(vlSelf->testbench__DOT__str_inst__DOT__qty_c02_q)))),6);
    bufp->chgCData(oldp+148,(((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_c05)
                               ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_data)
                               : ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_erogazione)
                                   ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__qc05_next)
                                   : (IData)(vlSelf->testbench__DOT__str_inst__DOT__qty_c05_q)))),6);
    bufp->chgCData(oldp+149,(((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_c10)
                               ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_data)
                               : ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_erogazione)
                                   ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__qc10_next)
                                   : (IData)(vlSelf->testbench__DOT__str_inst__DOT__qty_c10_q)))),6);
    bufp->chgBit(oldp+150,(((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_c01) 
                            | (IData)(vlSelf->testbench__DOT__str_inst__DOT__do_erogazione))));
    bufp->chgBit(oldp+151,(((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_c02) 
                            | (IData)(vlSelf->testbench__DOT__str_inst__DOT__do_erogazione))));
    bufp->chgBit(oldp+152,(((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_c05) 
                            | (IData)(vlSelf->testbench__DOT__str_inst__DOT__do_erogazione))));
    bufp->chgBit(oldp+153,(((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_c10) 
                            | (IData)(vlSelf->testbench__DOT__str_inst__DOT__do_erogazione))));
    bufp->chgCData(oldp+154,(((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_ok)
                               ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__sel_price)
                               : (IData)(vlSelf->testbench__DOT__str_inst__DOT__current_price_q))),6);
    bufp->chgBit(oldp+155,(((~ (IData)(vlSelf->testbench__DOT__str_inst__DOT__clear_outputs)) 
                            & ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_ok)
                                ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__c_prod1)
                                : (IData)(vlSelf->testbench__DOT__str_inst__DOT__prod1_q)))));
    bufp->chgBit(oldp+156,(((~ (IData)(vlSelf->testbench__DOT__str_inst__DOT__clear_outputs)) 
                            & ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_ok)
                                ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__c_prod2)
                                : (IData)(vlSelf->testbench__DOT__str_inst__DOT__prod2_q)))));
    bufp->chgBit(oldp+157,(((~ (IData)(vlSelf->testbench__DOT__str_inst__DOT__clear_outputs)) 
                            & ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_ok)
                                ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__c_prod3)
                                : (IData)(vlSelf->testbench__DOT__str_inst__DOT__prod3_q)))));
    bufp->chgBit(oldp+158,(((~ (IData)(vlSelf->testbench__DOT__str_inst__DOT__clear_outputs)) 
                            & ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_ok)
                                ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__c_prod4)
                                : (IData)(vlSelf->testbench__DOT__str_inst__DOT__prod4_q)))));
    bufp->chgCData(oldp+159,((((0U == (IData)(vlSelf->testbench__DOT__str_inst__DOT__sel_qty)) 
                               << 1U) | (IData)(vlSelf->testbench__DOT__str_inst__DOT__credito_insuff))),2);
    bufp->chgCData(oldp+160,(((IData)(vlSelf->testbench__DOT__str_inst__DOT__clear_outputs)
                               ? 0U : ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_err)
                                        ? (((0U == (IData)(vlSelf->testbench__DOT__str_inst__DOT__sel_qty)) 
                                            << 1U) 
                                           | (IData)(vlSelf->testbench__DOT__str_inst__DOT__credito_insuff))
                                        : (IData)(vlSelf->testbench__DOT__str_inst__DOT__errore_q)))),2);
    bufp->chgBit(oldp+161,(((IData)(vlSelf->testbench__DOT__str_inst__DOT__clear_outputs) 
                            | (IData)(vlSelf->testbench__DOT__str_inst__DOT__do_err))));
    bufp->chgCData(oldp+162,(((IData)(vlSelf->testbench__DOT__str_inst__DOT__clear_outputs)
                               ? 0U : ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_erogazione)
                                        ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__change6)
                                        : ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_cancel)
                                            ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__credito_q)
                                            : (((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_err) 
                                                & (IData)(vlSelf->testbench__DOT__str_inst__DOT__credito_insuff))
                                                ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__sel_price)
                                                : (IData)(vlSelf->testbench__DOT__str_inst__DOT__resto_q)))))),6);
    bufp->chgBit(oldp+163,(((IData)(vlSelf->testbench__DOT__str_inst__DOT__clear_outputs) 
                            | ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_cancel) 
                               | ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_erogazione) 
                                  | (IData)(vlSelf->testbench__DOT__str_inst__DOT__do_err))))));
    bufp->chgCData(oldp+164,(((IData)(vlSelf->testbench__DOT__str_inst__DOT____VdfgTmp_hf3f60487__0)
                               ? 0U : (0x3fU & ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_add_coin)
                                                 ? 
                                                ((IData)(vlSelf->testbench__DOT__str_inst__DOT__coin_value) 
                                                 + (IData)(vlSelf->testbench__DOT__str_inst__DOT__credito_q))
                                                 : (IData)(vlSelf->testbench__DOT__str_inst__DOT__credito_q))))),6);
    bufp->chgSData(oldp+165,((0x3ffU & ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_cancel)
                                         ? ((IData)(vlSelf->testbench__DOT__str_inst__DOT__disponibile_q) 
                                            - (IData)(vlSelf->testbench__DOT__str_inst__DOT__credito_q))
                                         : ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_erogazione)
                                             ? ((IData)(vlSelf->testbench__DOT__str_inst__DOT__disponibile_q) 
                                                - (IData)(vlSelf->testbench__DOT__str_inst__DOT__change6))
                                             : ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_add_coin)
                                                 ? 
                                                ((IData)(vlSelf->testbench__DOT__str_inst__DOT__disponibile_q) 
                                                 + (IData)(vlSelf->testbench__DOT__str_inst__DOT__coin_value))
                                                 : (IData)(vlSelf->testbench__DOT__str_inst__DOT__disponibile_q)))))),10);
}

void Vtestbench___024root__trace_cleanup(void* voidSelf, VerilatedVcd* /*unused*/) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtestbench___024root__trace_cleanup\n"); );
    // Init
    Vtestbench___024root* const __restrict vlSelf VL_ATTR_UNUSED = static_cast<Vtestbench___024root*>(voidSelf);
    Vtestbench__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    // Body
    vlSymsp->__Vm_activity = false;
    vlSymsp->TOP.__Vm_traceActivity[0U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[1U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[2U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[3U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[4U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[5U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[6U] = 0U;
}
