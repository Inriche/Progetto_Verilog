// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vtestbench.h for the primary calling header

#include "Vtestbench__pch.h"
#include "Vtestbench__Syms.h"
#include "Vtestbench___024root.h"

VL_INLINE_OPT VlCoroutine Vtestbench___024root___eval_initial__TOP__Vtiming__0(Vtestbench___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtestbench__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtestbench___024root___eval_initial__TOP__Vtiming__0\n"); );
    // Init
    VlWide<7>/*223:0*/ __Vtemp_1;
    // Body
    __Vtemp_1[0U] = 0x2e766364U;
    __Vtemp_1[1U] = 0x69736f6eU;
    __Vtemp_1[2U] = 0x6d706172U;
    __Vtemp_1[3U] = 0x655f636fU;
    __Vtemp_1[4U] = 0x7a696f6eU;
    __Vtemp_1[5U] = 0x6d756c61U;
    __Vtemp_1[6U] = 0x7369U;
    vlSymsp->_vm_contextp__->dumpfile(VL_CVT_PACK_STR_NW(7, __Vtemp_1));
    vlSymsp->_traceDumpOpen();
    vlSelf->testbench__DOT__clk = 0U;
    vlSelf->testbench__DOT__rst = 0U;
    vlSelf->testbench__DOT__coin = 0U;
    vlSelf->testbench__DOT__selezione = 0U;
    vlSelf->testbench__DOT__conferma = 0U;
    vlSelf->testbench__DOT__annulla = 0U;
    vlSelf->testbench__DOT__cycle_count = 0U;
    vlSelf->testbench__DOT__mismatch_count = 0U;
    co_await vlSelf->__VdlySched.delay(0x4e20ULL, nullptr, 
                                       "testbench.v", 
                                       112);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->testbench__DOT__rst = 1U;
    VL_WRITEF("--- INIZIO CONFRONTO BEHAVIORAL vs STRUCTURAL ---\n");
    co_await vlSelf->__VtrigSched_hf8270716__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge testbench.clk)", 
                                                       "testbench.v", 
                                                       169);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->testbench__DOT__coin = 0U;
    vlSelf->testbench__DOT__selezione = 5U;
    co_await vlSelf->__VtrigSched_hf8270716__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge testbench.clk)", 
                                                       "testbench.v", 
                                                       169);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->testbench__DOT__coin = 0U;
    vlSelf->testbench__DOT__selezione = 3U;
    co_await vlSelf->__VtrigSched_hf8270716__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge testbench.clk)", 
                                                       "testbench.v", 
                                                       169);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->testbench__DOT__coin = 0U;
    vlSelf->testbench__DOT__selezione = 5U;
    co_await vlSelf->__VtrigSched_hf8270716__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge testbench.clk)", 
                                                       "testbench.v", 
                                                       169);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->testbench__DOT__coin = 0U;
    vlSelf->testbench__DOT__selezione = 5U;
    co_await vlSelf->__VtrigSched_hf8270716__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge testbench.clk)", 
                                                       "testbench.v", 
                                                       169);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->testbench__DOT__coin = 0U;
    vlSelf->testbench__DOT__selezione = 5U;
    co_await vlSelf->__VtrigSched_hf8270716__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge testbench.clk)", 
                                                       "testbench.v", 
                                                       169);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->testbench__DOT__coin = 1U;
    vlSelf->testbench__DOT__selezione = 0U;
    co_await vlSelf->__VtrigSched_hf8270716__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge testbench.clk)", 
                                                       "testbench.v", 
                                                       169);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->testbench__DOT__coin = 0U;
    vlSelf->testbench__DOT__selezione = 2U;
    co_await vlSelf->__VtrigSched_hf8270716__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge testbench.clk)", 
                                                       "testbench.v", 
                                                       169);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->testbench__DOT__coin = 1U;
    vlSelf->testbench__DOT__selezione = 4U;
    co_await vlSelf->__VtrigSched_hf8270716__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge testbench.clk)", 
                                                       "testbench.v", 
                                                       169);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->testbench__DOT__coin = 1U;
    vlSelf->testbench__DOT__selezione = 2U;
    co_await vlSelf->__VtrigSched_hf8270716__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge testbench.clk)", 
                                                       "testbench.v", 
                                                       169);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->testbench__DOT__coin = 1U;
    vlSelf->testbench__DOT__selezione = 2U;
    co_await vlSelf->__VtrigSched_hf8270716__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge testbench.clk)", 
                                                       "testbench.v", 
                                                       169);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->testbench__DOT__coin = 1U;
    vlSelf->testbench__DOT__selezione = 2U;
    co_await vlSelf->__VtrigSched_hf8270716__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge testbench.clk)", 
                                                       "testbench.v", 
                                                       169);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->testbench__DOT__coin = 0U;
    vlSelf->testbench__DOT__selezione = 2U;
    co_await vlSelf->__VtrigSched_hf8270716__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge testbench.clk)", 
                                                       "testbench.v", 
                                                       169);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->testbench__DOT__coin = 0U;
    vlSelf->testbench__DOT__selezione = 0U;
    co_await vlSelf->__VdlySched.delay(0x4e20ULL, nullptr, 
                                       "testbench.v", 
                                       132);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    co_await vlSelf->__VtrigSched_hf8270716__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge testbench.clk)", 
                                                       "testbench.v", 
                                                       169);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->testbench__DOT__coin = 6U;
    co_await vlSelf->__VtrigSched_hf8270716__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge testbench.clk)", 
                                                       "testbench.v", 
                                                       169);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->testbench__DOT__coin = 0U;
    co_await vlSelf->__VdlySched.delay(0x2710ULL, nullptr, 
                                       "testbench.v", 
                                       135);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    co_await vlSelf->__VtrigSched_hf8270716__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge testbench.clk)", 
                                                       "testbench.v", 
                                                       169);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->testbench__DOT__selezione = 5U;
    vlSelf->testbench__DOT__conferma = 1U;
    co_await vlSelf->__VtrigSched_hf8270716__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge testbench.clk)", 
                                                       "testbench.v", 
                                                       169);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->testbench__DOT__conferma = 0U;
    vlSelf->testbench__DOT__selezione = 0U;
    co_await vlSelf->__VdlySched.delay(0xc350ULL, nullptr, 
                                       "testbench.v", 
                                       138);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    co_await vlSelf->__VtrigSched_hf8270716__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge testbench.clk)", 
                                                       "testbench.v", 
                                                       169);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->testbench__DOT__coin = 7U;
    co_await vlSelf->__VtrigSched_hf8270716__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge testbench.clk)", 
                                                       "testbench.v", 
                                                       169);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->testbench__DOT__coin = 0U;
    co_await vlSelf->__VtrigSched_hf8270716__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge testbench.clk)", 
                                                       "testbench.v", 
                                                       169);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->testbench__DOT__selezione = 4U;
    vlSelf->testbench__DOT__conferma = 1U;
    co_await vlSelf->__VtrigSched_hf8270716__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge testbench.clk)", 
                                                       "testbench.v", 
                                                       169);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->testbench__DOT__conferma = 0U;
    vlSelf->testbench__DOT__selezione = 0U;
    co_await vlSelf->__VdlySched.delay(0x186a0ULL, 
                                       nullptr, "testbench.v", 
                                       147);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    co_await vlSelf->__VtrigSched_hf8270716__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge testbench.clk)", 
                                                       "testbench.v", 
                                                       169);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->testbench__DOT__coin = 4U;
    co_await vlSelf->__VtrigSched_hf8270716__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge testbench.clk)", 
                                                       "testbench.v", 
                                                       169);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->testbench__DOT__coin = 0U;
    co_await vlSelf->__VtrigSched_hf8270716__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge testbench.clk)", 
                                                       "testbench.v", 
                                                       169);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->testbench__DOT__selezione = 7U;
    vlSelf->testbench__DOT__conferma = 1U;
    co_await vlSelf->__VtrigSched_hf8270716__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge testbench.clk)", 
                                                       "testbench.v", 
                                                       169);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->testbench__DOT__conferma = 0U;
    vlSelf->testbench__DOT__selezione = 0U;
    co_await vlSelf->__VdlySched.delay(0x9c40ULL, nullptr, 
                                       "testbench.v", 
                                       154);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    co_await vlSelf->__VtrigSched_hf8270716__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge testbench.clk)", 
                                                       "testbench.v", 
                                                       169);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->testbench__DOT__coin = 6U;
    co_await vlSelf->__VtrigSched_hf8270716__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge testbench.clk)", 
                                                       "testbench.v", 
                                                       169);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->testbench__DOT__coin = 0U;
    co_await vlSelf->__VtrigSched_hf8270716__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge testbench.clk)", 
                                                       "testbench.v", 
                                                       169);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->testbench__DOT__annulla = 1U;
    co_await vlSelf->__VtrigSched_hf8270716__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge testbench.clk)", 
                                                       "testbench.v", 
                                                       169);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->testbench__DOT__annulla = 0U;
    co_await vlSelf->__VdlySched.delay(0xc350ULL, nullptr, 
                                       "testbench.v", 
                                       161);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    VL_WRITEF("--- CONFRONTO TERMINATO: mismatch=%0d ---\n",
              32,vlSelf->testbench__DOT__mismatch_count);
    VL_FINISH_MT("testbench.v", 164, "");
    vlSelf->__Vm_traceActivity[2U] = 1U;
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vtestbench___024root___dump_triggers__act(Vtestbench___024root* vlSelf);
#endif  // VL_DEBUG

void Vtestbench___024root___eval_triggers__act(Vtestbench___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtestbench__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtestbench___024root___eval_triggers__act\n"); );
    // Body
    vlSelf->__VactTriggered.set(0U, ((IData)(vlSelf->testbench__DOT__clk) 
                                     & (~ (IData)(vlSelf->__Vtrigprevexpr___TOP__testbench__DOT__clk__0))));
    vlSelf->__VactTriggered.set(1U, ((~ (IData)(vlSelf->testbench__DOT__clk)) 
                                     & (IData)(vlSelf->__Vtrigprevexpr___TOP__testbench__DOT__clk__0)));
    vlSelf->__VactTriggered.set(2U, (((IData)(vlSelf->testbench__DOT__clk) 
                                      & (~ (IData)(vlSelf->__Vtrigprevexpr___TOP__testbench__DOT__clk__0))) 
                                     | ((~ (IData)(vlSelf->testbench__DOT__rst)) 
                                        & (IData)(vlSelf->__Vtrigprevexpr___TOP__testbench__DOT__rst__0))));
    vlSelf->__VactTriggered.set(3U, vlSelf->__VdlySched.awaitingCurrentTime());
    vlSelf->__Vtrigprevexpr___TOP__testbench__DOT__clk__0 
        = vlSelf->testbench__DOT__clk;
    vlSelf->__Vtrigprevexpr___TOP__testbench__DOT__rst__0 
        = vlSelf->testbench__DOT__rst;
#ifdef VL_DEBUG
    if (VL_UNLIKELY(vlSymsp->_vm_contextp__->debug())) {
        Vtestbench___024root___dump_triggers__act(vlSelf);
    }
#endif
}

VL_INLINE_OPT void Vtestbench___024root___nba_sequent__TOP__2(Vtestbench___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtestbench__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtestbench___024root___nba_sequent__TOP__2\n"); );
    // Init
    IData/*31:0*/ __Vtask_testbench__DOT__fail_mismatch__0__behavioral_value;
    __Vtask_testbench__DOT__fail_mismatch__0__behavioral_value = 0;
    IData/*31:0*/ __Vtask_testbench__DOT__fail_mismatch__0__structural_value;
    __Vtask_testbench__DOT__fail_mismatch__0__structural_value = 0;
    IData/*31:0*/ __Vtask_testbench__DOT__fail_mismatch__1__behavioral_value;
    __Vtask_testbench__DOT__fail_mismatch__1__behavioral_value = 0;
    IData/*31:0*/ __Vtask_testbench__DOT__fail_mismatch__1__structural_value;
    __Vtask_testbench__DOT__fail_mismatch__1__structural_value = 0;
    IData/*31:0*/ __Vtask_testbench__DOT__fail_mismatch__2__behavioral_value;
    __Vtask_testbench__DOT__fail_mismatch__2__behavioral_value = 0;
    IData/*31:0*/ __Vtask_testbench__DOT__fail_mismatch__2__structural_value;
    __Vtask_testbench__DOT__fail_mismatch__2__structural_value = 0;
    IData/*31:0*/ __Vtask_testbench__DOT__fail_mismatch__3__behavioral_value;
    __Vtask_testbench__DOT__fail_mismatch__3__behavioral_value = 0;
    IData/*31:0*/ __Vtask_testbench__DOT__fail_mismatch__3__structural_value;
    __Vtask_testbench__DOT__fail_mismatch__3__structural_value = 0;
    IData/*31:0*/ __Vtask_testbench__DOT__fail_mismatch__4__behavioral_value;
    __Vtask_testbench__DOT__fail_mismatch__4__behavioral_value = 0;
    IData/*31:0*/ __Vtask_testbench__DOT__fail_mismatch__4__structural_value;
    __Vtask_testbench__DOT__fail_mismatch__4__structural_value = 0;
    IData/*31:0*/ __Vtask_testbench__DOT__fail_mismatch__5__behavioral_value;
    __Vtask_testbench__DOT__fail_mismatch__5__behavioral_value = 0;
    IData/*31:0*/ __Vtask_testbench__DOT__fail_mismatch__5__structural_value;
    __Vtask_testbench__DOT__fail_mismatch__5__structural_value = 0;
    IData/*31:0*/ __Vtask_testbench__DOT__fail_mismatch__6__behavioral_value;
    __Vtask_testbench__DOT__fail_mismatch__6__behavioral_value = 0;
    IData/*31:0*/ __Vtask_testbench__DOT__fail_mismatch__6__structural_value;
    __Vtask_testbench__DOT__fail_mismatch__6__structural_value = 0;
    IData/*31:0*/ __Vtask_testbench__DOT__fail_mismatch__7__behavioral_value;
    __Vtask_testbench__DOT__fail_mismatch__7__behavioral_value = 0;
    IData/*31:0*/ __Vtask_testbench__DOT__fail_mismatch__7__structural_value;
    __Vtask_testbench__DOT__fail_mismatch__7__structural_value = 0;
    IData/*31:0*/ __Vtask_testbench__DOT__fail_mismatch__8__behavioral_value;
    __Vtask_testbench__DOT__fail_mismatch__8__behavioral_value = 0;
    IData/*31:0*/ __Vtask_testbench__DOT__fail_mismatch__8__structural_value;
    __Vtask_testbench__DOT__fail_mismatch__8__structural_value = 0;
    IData/*31:0*/ __Vtask_testbench__DOT__fail_mismatch__9__behavioral_value;
    __Vtask_testbench__DOT__fail_mismatch__9__behavioral_value = 0;
    IData/*31:0*/ __Vtask_testbench__DOT__fail_mismatch__9__structural_value;
    __Vtask_testbench__DOT__fail_mismatch__9__structural_value = 0;
    IData/*31:0*/ __Vtask_testbench__DOT__fail_mismatch__10__behavioral_value;
    __Vtask_testbench__DOT__fail_mismatch__10__behavioral_value = 0;
    IData/*31:0*/ __Vtask_testbench__DOT__fail_mismatch__10__structural_value;
    __Vtask_testbench__DOT__fail_mismatch__10__structural_value = 0;
    IData/*31:0*/ __Vtask_testbench__DOT__fail_mismatch__11__behavioral_value;
    __Vtask_testbench__DOT__fail_mismatch__11__behavioral_value = 0;
    IData/*31:0*/ __Vtask_testbench__DOT__fail_mismatch__11__structural_value;
    __Vtask_testbench__DOT__fail_mismatch__11__structural_value = 0;
    // Body
    if (vlSelf->testbench__DOT__rst) {
        if (VL_UNLIKELY(((IData)(vlSelf->testbench__DOT__credito_b) 
                         != (IData)(vlSelf->testbench__DOT__str_inst__DOT__credito_q)))) {
            __Vtask_testbench__DOT__fail_mismatch__0__structural_value 
                = vlSelf->testbench__DOT__str_inst__DOT__credito_q;
            __Vtask_testbench__DOT__fail_mismatch__0__behavioral_value 
                = vlSelf->testbench__DOT__credito_b;
            vlSelf->testbench__DOT__mismatch_count 
                = ((IData)(1U) + vlSelf->testbench__DOT__mismatch_count);
            VL_WRITEF("MISMATCH time=%0t cycle=%0d signal=credito behavioral=%0# structural=%0#\n[%0t] %%Fatal: testbench.v:76: Assertion failed in %Ntestbench.fail_mismatch: Comparison failed\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      32,vlSelf->testbench__DOT__cycle_count,
                      32,__Vtask_testbench__DOT__fail_mismatch__0__behavioral_value,
                      32,__Vtask_testbench__DOT__fail_mismatch__0__structural_value,
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name());
            VL_STOP_MT("testbench.v", 76, "");
        }
        if (VL_UNLIKELY(((IData)(vlSelf->testbench__DOT__resto_b) 
                         != (IData)(vlSelf->testbench__DOT__str_inst__DOT__resto_q)))) {
            __Vtask_testbench__DOT__fail_mismatch__1__structural_value 
                = vlSelf->testbench__DOT__str_inst__DOT__resto_q;
            vlSelf->testbench__DOT__mismatch_count 
                = ((IData)(1U) + vlSelf->testbench__DOT__mismatch_count);
            __Vtask_testbench__DOT__fail_mismatch__1__behavioral_value 
                = vlSelf->testbench__DOT__resto_b;
            VL_WRITEF("MISMATCH time=%0t cycle=%0d signal=resto behavioral=%0# structural=%0#\n[%0t] %%Fatal: testbench.v:76: Assertion failed in %Ntestbench.fail_mismatch: Comparison failed\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      32,vlSelf->testbench__DOT__cycle_count,
                      32,__Vtask_testbench__DOT__fail_mismatch__1__behavioral_value,
                      32,__Vtask_testbench__DOT__fail_mismatch__1__structural_value,
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name());
            VL_STOP_MT("testbench.v", 76, "");
        }
        if (VL_UNLIKELY(((IData)(vlSelf->testbench__DOT__errore_b) 
                         != (IData)(vlSelf->testbench__DOT__str_inst__DOT__errore_q)))) {
            __Vtask_testbench__DOT__fail_mismatch__2__structural_value 
                = vlSelf->testbench__DOT__str_inst__DOT__errore_q;
            vlSelf->testbench__DOT__mismatch_count 
                = ((IData)(1U) + vlSelf->testbench__DOT__mismatch_count);
            __Vtask_testbench__DOT__fail_mismatch__2__behavioral_value 
                = vlSelf->testbench__DOT__errore_b;
            VL_WRITEF("MISMATCH time=%0t cycle=%0d signal=errore behavioral=%0# structural=%0#\n[%0t] %%Fatal: testbench.v:76: Assertion failed in %Ntestbench.fail_mismatch: Comparison failed\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      32,vlSelf->testbench__DOT__cycle_count,
                      32,__Vtask_testbench__DOT__fail_mismatch__2__behavioral_value,
                      32,__Vtask_testbench__DOT__fail_mismatch__2__structural_value,
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name());
            VL_STOP_MT("testbench.v", 76, "");
        }
        if (VL_UNLIKELY(((IData)(vlSelf->testbench__DOT__disp_b) 
                         != (IData)(vlSelf->testbench__DOT__str_inst__DOT__disponibile_q)))) {
            __Vtask_testbench__DOT__fail_mismatch__3__structural_value 
                = vlSelf->testbench__DOT__str_inst__DOT__disponibile_q;
            vlSelf->testbench__DOT__mismatch_count 
                = ((IData)(1U) + vlSelf->testbench__DOT__mismatch_count);
            __Vtask_testbench__DOT__fail_mismatch__3__behavioral_value 
                = vlSelf->testbench__DOT__disp_b;
            VL_WRITEF("MISMATCH time=%0t cycle=%0d signal=disponibile behavioral=%0# structural=%0#\n[%0t] %%Fatal: testbench.v:76: Assertion failed in %Ntestbench.fail_mismatch: Comparison failed\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      32,vlSelf->testbench__DOT__cycle_count,
                      32,__Vtask_testbench__DOT__fail_mismatch__3__behavioral_value,
                      32,__Vtask_testbench__DOT__fail_mismatch__3__structural_value,
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name());
            VL_STOP_MT("testbench.v", 76, "");
        }
        if (VL_UNLIKELY(((IData)(vlSelf->testbench__DOT__p1_b) 
                         != (IData)(vlSelf->testbench__DOT__str_inst__DOT__prod1_q)))) {
            __Vtask_testbench__DOT__fail_mismatch__4__structural_value 
                = vlSelf->testbench__DOT__str_inst__DOT__prod1_q;
            vlSelf->testbench__DOT__mismatch_count 
                = ((IData)(1U) + vlSelf->testbench__DOT__mismatch_count);
            __Vtask_testbench__DOT__fail_mismatch__4__behavioral_value 
                = vlSelf->testbench__DOT__p1_b;
            VL_WRITEF("MISMATCH time=%0t cycle=%0d signal=prodotto1 behavioral=%0# structural=%0#\n[%0t] %%Fatal: testbench.v:76: Assertion failed in %Ntestbench.fail_mismatch: Comparison failed\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      32,vlSelf->testbench__DOT__cycle_count,
                      32,__Vtask_testbench__DOT__fail_mismatch__4__behavioral_value,
                      32,__Vtask_testbench__DOT__fail_mismatch__4__structural_value,
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name());
            VL_STOP_MT("testbench.v", 76, "");
        }
        if (VL_UNLIKELY(((IData)(vlSelf->testbench__DOT__p2_b) 
                         != (IData)(vlSelf->testbench__DOT__str_inst__DOT__prod2_q)))) {
            __Vtask_testbench__DOT__fail_mismatch__5__structural_value 
                = vlSelf->testbench__DOT__str_inst__DOT__prod2_q;
            vlSelf->testbench__DOT__mismatch_count 
                = ((IData)(1U) + vlSelf->testbench__DOT__mismatch_count);
            __Vtask_testbench__DOT__fail_mismatch__5__behavioral_value 
                = vlSelf->testbench__DOT__p2_b;
            VL_WRITEF("MISMATCH time=%0t cycle=%0d signal=prodotto2 behavioral=%0# structural=%0#\n[%0t] %%Fatal: testbench.v:76: Assertion failed in %Ntestbench.fail_mismatch: Comparison failed\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      32,vlSelf->testbench__DOT__cycle_count,
                      32,__Vtask_testbench__DOT__fail_mismatch__5__behavioral_value,
                      32,__Vtask_testbench__DOT__fail_mismatch__5__structural_value,
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name());
            VL_STOP_MT("testbench.v", 76, "");
        }
        if (VL_UNLIKELY(((IData)(vlSelf->testbench__DOT__p3_b) 
                         != (IData)(vlSelf->testbench__DOT__str_inst__DOT__prod3_q)))) {
            __Vtask_testbench__DOT__fail_mismatch__6__structural_value 
                = vlSelf->testbench__DOT__str_inst__DOT__prod3_q;
            vlSelf->testbench__DOT__mismatch_count 
                = ((IData)(1U) + vlSelf->testbench__DOT__mismatch_count);
            __Vtask_testbench__DOT__fail_mismatch__6__behavioral_value 
                = vlSelf->testbench__DOT__p3_b;
            VL_WRITEF("MISMATCH time=%0t cycle=%0d signal=prodotto3 behavioral=%0# structural=%0#\n[%0t] %%Fatal: testbench.v:76: Assertion failed in %Ntestbench.fail_mismatch: Comparison failed\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      32,vlSelf->testbench__DOT__cycle_count,
                      32,__Vtask_testbench__DOT__fail_mismatch__6__behavioral_value,
                      32,__Vtask_testbench__DOT__fail_mismatch__6__structural_value,
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name());
            VL_STOP_MT("testbench.v", 76, "");
        }
        if (VL_UNLIKELY(((IData)(vlSelf->testbench__DOT__p4_b) 
                         != (IData)(vlSelf->testbench__DOT__str_inst__DOT__prod4_q)))) {
            __Vtask_testbench__DOT__fail_mismatch__7__structural_value 
                = vlSelf->testbench__DOT__str_inst__DOT__prod4_q;
            vlSelf->testbench__DOT__mismatch_count 
                = ((IData)(1U) + vlSelf->testbench__DOT__mismatch_count);
            __Vtask_testbench__DOT__fail_mismatch__7__behavioral_value 
                = vlSelf->testbench__DOT__p4_b;
            VL_WRITEF("MISMATCH time=%0t cycle=%0d signal=prodotto4 behavioral=%0# structural=%0#\n[%0t] %%Fatal: testbench.v:76: Assertion failed in %Ntestbench.fail_mismatch: Comparison failed\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      32,vlSelf->testbench__DOT__cycle_count,
                      32,__Vtask_testbench__DOT__fail_mismatch__7__behavioral_value,
                      32,__Vtask_testbench__DOT__fail_mismatch__7__structural_value,
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name());
            VL_STOP_MT("testbench.v", 76, "");
        }
        if (VL_UNLIKELY(((IData)(vlSelf->testbench__DOT__c01_b) 
                         != (IData)(vlSelf->testbench__DOT__str_inst__DOT__coin01_q)))) {
            __Vtask_testbench__DOT__fail_mismatch__8__structural_value 
                = vlSelf->testbench__DOT__str_inst__DOT__coin01_q;
            vlSelf->testbench__DOT__mismatch_count 
                = ((IData)(1U) + vlSelf->testbench__DOT__mismatch_count);
            __Vtask_testbench__DOT__fail_mismatch__8__behavioral_value 
                = vlSelf->testbench__DOT__c01_b;
            VL_WRITEF("MISMATCH time=%0t cycle=%0d signal=coin_01 behavioral=%0# structural=%0#\n[%0t] %%Fatal: testbench.v:76: Assertion failed in %Ntestbench.fail_mismatch: Comparison failed\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      32,vlSelf->testbench__DOT__cycle_count,
                      32,__Vtask_testbench__DOT__fail_mismatch__8__behavioral_value,
                      32,__Vtask_testbench__DOT__fail_mismatch__8__structural_value,
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name());
            VL_STOP_MT("testbench.v", 76, "");
        }
        if (VL_UNLIKELY(((IData)(vlSelf->testbench__DOT__c02_b) 
                         != (IData)(vlSelf->testbench__DOT__str_inst__DOT__coin02_q)))) {
            __Vtask_testbench__DOT__fail_mismatch__9__structural_value 
                = vlSelf->testbench__DOT__str_inst__DOT__coin02_q;
            vlSelf->testbench__DOT__mismatch_count 
                = ((IData)(1U) + vlSelf->testbench__DOT__mismatch_count);
            __Vtask_testbench__DOT__fail_mismatch__9__behavioral_value 
                = vlSelf->testbench__DOT__c02_b;
            VL_WRITEF("MISMATCH time=%0t cycle=%0d signal=coin_02 behavioral=%0# structural=%0#\n[%0t] %%Fatal: testbench.v:76: Assertion failed in %Ntestbench.fail_mismatch: Comparison failed\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      32,vlSelf->testbench__DOT__cycle_count,
                      32,__Vtask_testbench__DOT__fail_mismatch__9__behavioral_value,
                      32,__Vtask_testbench__DOT__fail_mismatch__9__structural_value,
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name());
            VL_STOP_MT("testbench.v", 76, "");
        }
        if (VL_UNLIKELY(((IData)(vlSelf->testbench__DOT__c05_b) 
                         != (IData)(vlSelf->testbench__DOT__str_inst__DOT__coin05_q)))) {
            __Vtask_testbench__DOT__fail_mismatch__10__structural_value 
                = vlSelf->testbench__DOT__str_inst__DOT__coin05_q;
            vlSelf->testbench__DOT__mismatch_count 
                = ((IData)(1U) + vlSelf->testbench__DOT__mismatch_count);
            __Vtask_testbench__DOT__fail_mismatch__10__behavioral_value 
                = vlSelf->testbench__DOT__c05_b;
            VL_WRITEF("MISMATCH time=%0t cycle=%0d signal=coin_05 behavioral=%0# structural=%0#\n[%0t] %%Fatal: testbench.v:76: Assertion failed in %Ntestbench.fail_mismatch: Comparison failed\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      32,vlSelf->testbench__DOT__cycle_count,
                      32,__Vtask_testbench__DOT__fail_mismatch__10__behavioral_value,
                      32,__Vtask_testbench__DOT__fail_mismatch__10__structural_value,
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name());
            VL_STOP_MT("testbench.v", 76, "");
        }
        if (VL_UNLIKELY(((IData)(vlSelf->testbench__DOT__c10_b) 
                         != (IData)(vlSelf->testbench__DOT__str_inst__DOT__coin10_q)))) {
            __Vtask_testbench__DOT__fail_mismatch__11__structural_value 
                = vlSelf->testbench__DOT__str_inst__DOT__coin10_q;
            vlSelf->testbench__DOT__mismatch_count 
                = ((IData)(1U) + vlSelf->testbench__DOT__mismatch_count);
            __Vtask_testbench__DOT__fail_mismatch__11__behavioral_value 
                = vlSelf->testbench__DOT__c10_b;
            VL_WRITEF("MISMATCH time=%0t cycle=%0d signal=coin_10 behavioral=%0# structural=%0#\n[%0t] %%Fatal: testbench.v:76: Assertion failed in %Ntestbench.fail_mismatch: Comparison failed\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      32,vlSelf->testbench__DOT__cycle_count,
                      32,__Vtask_testbench__DOT__fail_mismatch__11__behavioral_value,
                      32,__Vtask_testbench__DOT__fail_mismatch__11__structural_value,
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name());
            VL_STOP_MT("testbench.v", 76, "");
        }
    }
}
