// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vtestbench.h for the primary calling header

#include "Vtestbench__pch.h"
#include "Vtestbench___024root.h"

VlCoroutine Vtestbench___024root___eval_initial__TOP__Vtiming__0(Vtestbench___024root* vlSelf);
VlCoroutine Vtestbench___024root___eval_initial__TOP__Vtiming__1(Vtestbench___024root* vlSelf);

void Vtestbench___024root___eval_initial(Vtestbench___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtestbench__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtestbench___024root___eval_initial\n"); );
    // Body
    vlSelf->__Vm_traceActivity[1U] = 1U;
    Vtestbench___024root___eval_initial__TOP__Vtiming__0(vlSelf);
    Vtestbench___024root___eval_initial__TOP__Vtiming__1(vlSelf);
    vlSelf->__Vtrigprevexpr___TOP__testbench__DOT__clk__0 
        = vlSelf->testbench__DOT__clk;
    vlSelf->__Vtrigprevexpr___TOP__testbench__DOT__rst__0 
        = vlSelf->testbench__DOT__rst;
}

VL_INLINE_OPT VlCoroutine Vtestbench___024root___eval_initial__TOP__Vtiming__1(Vtestbench___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtestbench__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtestbench___024root___eval_initial__TOP__Vtiming__1\n"); );
    // Body
    while (1U) {
        co_await vlSelf->__VdlySched.delay(0x1388ULL, 
                                           nullptr, 
                                           "testbench.v", 
                                           59);
        vlSelf->testbench__DOT__clk = (1U & (~ (IData)(vlSelf->testbench__DOT__clk)));
    }
}

extern const VlUnpacked<CData/*5:0*/, 8> Vtestbench__ConstPool__TABLE_h98991338_0;

VL_INLINE_OPT void Vtestbench___024root___act_comb__TOP__0(Vtestbench___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtestbench__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtestbench___024root___act_comb__TOP__0\n"); );
    // Init
    CData/*2:0*/ __Vtableidx1;
    __Vtableidx1 = 0;
    // Body
    __Vtableidx1 = vlSelf->testbench__DOT__coin;
    vlSelf->testbench__DOT__str_inst__DOT__coin_value 
        = Vtestbench__ConstPool__TABLE_h98991338_0[__Vtableidx1];
    vlSelf->testbench__DOT__str_inst__DOT__do_add_coin = 0U;
    vlSelf->testbench__DOT__str_inst__DOT__do_cancel = 0U;
    vlSelf->testbench__DOT__str_inst__DOT__init_data 
        = (((IData)(vlSelf->testbench__DOT__coin) << 3U) 
           | (IData)(vlSelf->testbench__DOT__selezione));
    if ((2U & (IData)(vlSelf->testbench__DOT__selezione))) {
        if ((1U & (IData)(vlSelf->testbench__DOT__selezione))) {
            vlSelf->testbench__DOT__str_inst__DOT__sel_qty 
                = vlSelf->testbench__DOT__str_inst__DOT__qty_p4_q;
            vlSelf->testbench__DOT__str_inst__DOT__sel_price 
                = vlSelf->testbench__DOT__str_inst__DOT__price_p4_q;
        } else {
            vlSelf->testbench__DOT__str_inst__DOT__sel_qty 
                = vlSelf->testbench__DOT__str_inst__DOT__qty_p3_q;
            vlSelf->testbench__DOT__str_inst__DOT__sel_price 
                = vlSelf->testbench__DOT__str_inst__DOT__price_p3_q;
        }
    } else if ((1U & (IData)(vlSelf->testbench__DOT__selezione))) {
        vlSelf->testbench__DOT__str_inst__DOT__sel_qty 
            = vlSelf->testbench__DOT__str_inst__DOT__qty_p2_q;
        vlSelf->testbench__DOT__str_inst__DOT__sel_price 
            = vlSelf->testbench__DOT__str_inst__DOT__price_p2_q;
    } else {
        vlSelf->testbench__DOT__str_inst__DOT__sel_qty 
            = vlSelf->testbench__DOT__str_inst__DOT__qty_p1_q;
        vlSelf->testbench__DOT__str_inst__DOT__sel_price 
            = vlSelf->testbench__DOT__str_inst__DOT__price_p1_q;
    }
    if ((2U & (IData)(vlSelf->testbench__DOT__str_inst__DOT__CTRL__DOT__stato))) {
        if ((1U & (~ (IData)(vlSelf->testbench__DOT__str_inst__DOT__CTRL__DOT__stato)))) {
            if ((0U != (IData)(vlSelf->testbench__DOT__coin))) {
                vlSelf->testbench__DOT__str_inst__DOT__do_add_coin = 1U;
            }
            if ((0U == (IData)(vlSelf->testbench__DOT__coin))) {
                if (vlSelf->testbench__DOT__annulla) {
                    vlSelf->testbench__DOT__str_inst__DOT__do_cancel = 1U;
                }
            }
        }
    } else if ((1U & (IData)(vlSelf->testbench__DOT__str_inst__DOT__CTRL__DOT__stato))) {
        if ((0U != (IData)(vlSelf->testbench__DOT__coin))) {
            vlSelf->testbench__DOT__str_inst__DOT__do_add_coin = 1U;
        }
    }
    vlSelf->testbench__DOT__str_inst__DOT__disponibile_d 
        = (0x3ffU & ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_cancel)
                      ? ((IData)(vlSelf->testbench__DOT__str_inst__DOT__disponibile_q) 
                         - (IData)(vlSelf->testbench__DOT__str_inst__DOT__credito_q))
                      : ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_erogazione)
                          ? ((IData)(vlSelf->testbench__DOT__str_inst__DOT__disponibile_q) 
                             - (IData)(vlSelf->testbench__DOT__str_inst__DOT__change6))
                          : ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_add_coin)
                              ? ((IData)(vlSelf->testbench__DOT__str_inst__DOT__disponibile_q) 
                                 + (IData)(vlSelf->testbench__DOT__str_inst__DOT__coin_value))
                              : (IData)(vlSelf->testbench__DOT__str_inst__DOT__disponibile_q)))));
    vlSelf->testbench__DOT__str_inst__DOT____VdfgTmp_hf3f60487__0 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_cancel) 
           | (IData)(vlSelf->testbench__DOT__str_inst__DOT__do_erogazione));
    vlSelf->testbench__DOT__str_inst__DOT__price_p1_d 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_price_p1)
            ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_data)
            : (IData)(vlSelf->testbench__DOT__str_inst__DOT__price_p1_q));
    vlSelf->testbench__DOT__str_inst__DOT__price_p2_d 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_price_p2)
            ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_data)
            : (IData)(vlSelf->testbench__DOT__str_inst__DOT__price_p2_q));
    vlSelf->testbench__DOT__str_inst__DOT__price_p3_d 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_price_p3)
            ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_data)
            : (IData)(vlSelf->testbench__DOT__str_inst__DOT__price_p3_q));
    vlSelf->testbench__DOT__str_inst__DOT__price_p4_d 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_price_p4)
            ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_data)
            : (IData)(vlSelf->testbench__DOT__str_inst__DOT__price_p4_q));
    vlSelf->testbench__DOT__str_inst__DOT__qty_c01_d 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_c01)
            ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_data)
            : ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_erogazione)
                ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__qc01_next)
                : (IData)(vlSelf->testbench__DOT__str_inst__DOT__qty_c01_q)));
    vlSelf->testbench__DOT__str_inst__DOT__qty_c02_d 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_c02)
            ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_data)
            : ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_erogazione)
                ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__qc02_next)
                : (IData)(vlSelf->testbench__DOT__str_inst__DOT__qty_c02_q)));
    vlSelf->testbench__DOT__str_inst__DOT__qty_c05_d 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_c05)
            ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_data)
            : ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_erogazione)
                ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__qc05_next)
                : (IData)(vlSelf->testbench__DOT__str_inst__DOT__qty_c05_q)));
    vlSelf->testbench__DOT__str_inst__DOT__qty_c10_d 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_c10)
            ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_data)
            : ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_erogazione)
                ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__qc10_next)
                : (IData)(vlSelf->testbench__DOT__str_inst__DOT__qty_c10_q)));
    vlSelf->testbench__DOT__str_inst__DOT__credito_insuff 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__credito_q) 
           < (IData)(vlSelf->testbench__DOT__str_inst__DOT__sel_price));
    vlSelf->testbench__DOT__str_inst__DOT__is_credito_suff 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__credito_q) 
           >= (IData)(vlSelf->testbench__DOT__str_inst__DOT__sel_price));
    vlSelf->testbench__DOT__str_inst__DOT__we_credito 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_add_coin) 
           | (IData)(vlSelf->testbench__DOT__str_inst__DOT____VdfgTmp_hf3f60487__0));
    vlSelf->testbench__DOT__str_inst__DOT__credito_d 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT____VdfgTmp_hf3f60487__0)
            ? 0U : (0x3fU & ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_add_coin)
                              ? ((IData)(vlSelf->testbench__DOT__str_inst__DOT__coin_value) 
                                 + (IData)(vlSelf->testbench__DOT__str_inst__DOT__credito_q))
                              : (IData)(vlSelf->testbench__DOT__str_inst__DOT__credito_q))));
    vlSelf->testbench__DOT__str_inst__DOT__c_prod4 = 0U;
    vlSelf->testbench__DOT__str_inst__DOT__c_prod3 = 0U;
    vlSelf->testbench__DOT__str_inst__DOT__c_prod2 = 0U;
    vlSelf->testbench__DOT__str_inst__DOT__c_prod1 = 0U;
    vlSelf->testbench__DOT__str_inst__DOT__do_err = 0U;
    vlSelf->testbench__DOT__str_inst__DOT__do_ok = 0U;
    if ((2U & (IData)(vlSelf->testbench__DOT__str_inst__DOT__CTRL__DOT__stato))) {
        vlSelf->testbench__DOT__str_inst__DOT__CTRL__DOT__next_stato 
            = ((1U & (IData)(vlSelf->testbench__DOT__str_inst__DOT__CTRL__DOT__stato))
                ? 1U : ((0U != (IData)(vlSelf->testbench__DOT__coin))
                         ? 2U : ((IData)(vlSelf->testbench__DOT__annulla)
                                  ? 1U : ((IData)(vlSelf->testbench__DOT__conferma)
                                           ? (((IData)(vlSelf->testbench__DOT__str_inst__DOT__is_credito_suff) 
                                               & (0U 
                                                  != (IData)(vlSelf->testbench__DOT__str_inst__DOT__sel_qty)))
                                               ? 3U
                                               : 1U)
                                           : 2U))));
        if ((1U & (~ (IData)(vlSelf->testbench__DOT__str_inst__DOT__CTRL__DOT__stato)))) {
            if ((0U == (IData)(vlSelf->testbench__DOT__coin))) {
                if ((1U & (~ (IData)(vlSelf->testbench__DOT__annulla)))) {
                    if (vlSelf->testbench__DOT__conferma) {
                        if (((IData)(vlSelf->testbench__DOT__str_inst__DOT__is_credito_suff) 
                             & (0U != (IData)(vlSelf->testbench__DOT__str_inst__DOT__sel_qty)))) {
                            if ((4U & (IData)(vlSelf->testbench__DOT__selezione))) {
                                if ((2U & (IData)(vlSelf->testbench__DOT__selezione))) {
                                    if ((1U & (IData)(vlSelf->testbench__DOT__selezione))) {
                                        vlSelf->testbench__DOT__str_inst__DOT__c_prod4 = 1U;
                                    }
                                    if ((1U & (~ (IData)(vlSelf->testbench__DOT__selezione)))) {
                                        vlSelf->testbench__DOT__str_inst__DOT__c_prod3 = 1U;
                                    }
                                }
                                if ((1U & (~ ((IData)(vlSelf->testbench__DOT__selezione) 
                                              >> 1U)))) {
                                    if ((1U & (IData)(vlSelf->testbench__DOT__selezione))) {
                                        vlSelf->testbench__DOT__str_inst__DOT__c_prod2 = 1U;
                                    }
                                    if ((1U & (~ (IData)(vlSelf->testbench__DOT__selezione)))) {
                                        vlSelf->testbench__DOT__str_inst__DOT__c_prod1 = 1U;
                                    }
                                }
                            }
                            vlSelf->testbench__DOT__str_inst__DOT__do_ok = 1U;
                        }
                        if ((1U & (~ ((IData)(vlSelf->testbench__DOT__str_inst__DOT__is_credito_suff) 
                                      & (0U != (IData)(vlSelf->testbench__DOT__str_inst__DOT__sel_qty)))))) {
                            vlSelf->testbench__DOT__str_inst__DOT__do_err = 1U;
                        }
                    }
                }
            }
        }
    } else {
        vlSelf->testbench__DOT__str_inst__DOT__CTRL__DOT__next_stato 
            = ((1U & (IData)(vlSelf->testbench__DOT__str_inst__DOT__CTRL__DOT__stato))
                ? ((0U != (IData)(vlSelf->testbench__DOT__coin))
                    ? 2U : 1U) : ((0xbU == (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_counter_w))
                                   ? 1U : 0U));
    }
    if (vlSelf->testbench__DOT__str_inst__DOT__clear_outputs) {
        vlSelf->testbench__DOT__str_inst__DOT__errore_d = 0U;
        vlSelf->testbench__DOT__str_inst__DOT__resto_d = 0U;
    } else {
        vlSelf->testbench__DOT__str_inst__DOT__errore_d 
            = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_err)
                ? (((0U == (IData)(vlSelf->testbench__DOT__str_inst__DOT__sel_qty)) 
                    << 1U) | (IData)(vlSelf->testbench__DOT__str_inst__DOT__credito_insuff))
                : (IData)(vlSelf->testbench__DOT__str_inst__DOT__errore_q));
        vlSelf->testbench__DOT__str_inst__DOT__resto_d 
            = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_erogazione)
                ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__change6)
                : ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_cancel)
                    ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__credito_q)
                    : (((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_err) 
                        & (IData)(vlSelf->testbench__DOT__str_inst__DOT__credito_insuff))
                        ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__sel_price)
                        : (IData)(vlSelf->testbench__DOT__str_inst__DOT__resto_q))));
    }
    vlSelf->testbench__DOT__str_inst__DOT__we_prod 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__clear_outputs) 
           | (IData)(vlSelf->testbench__DOT__str_inst__DOT__do_ok));
    vlSelf->testbench__DOT__str_inst__DOT__current_price_d 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_ok)
            ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__sel_price)
            : (IData)(vlSelf->testbench__DOT__str_inst__DOT__current_price_q));
    vlSelf->testbench__DOT__str_inst__DOT__prod1_d 
        = ((~ (IData)(vlSelf->testbench__DOT__str_inst__DOT__clear_outputs)) 
           & ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_ok)
               ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__c_prod1)
               : (IData)(vlSelf->testbench__DOT__str_inst__DOT__prod1_q)));
    vlSelf->testbench__DOT__str_inst__DOT__prod2_d 
        = ((~ (IData)(vlSelf->testbench__DOT__str_inst__DOT__clear_outputs)) 
           & ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_ok)
               ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__c_prod2)
               : (IData)(vlSelf->testbench__DOT__str_inst__DOT__prod2_q)));
    vlSelf->testbench__DOT__str_inst__DOT__prod3_d 
        = ((~ (IData)(vlSelf->testbench__DOT__str_inst__DOT__clear_outputs)) 
           & ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_ok)
               ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__c_prod3)
               : (IData)(vlSelf->testbench__DOT__str_inst__DOT__prod3_q)));
    vlSelf->testbench__DOT__str_inst__DOT__prod4_d 
        = ((~ (IData)(vlSelf->testbench__DOT__str_inst__DOT__clear_outputs)) 
           & ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_ok)
               ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__c_prod4)
               : (IData)(vlSelf->testbench__DOT__str_inst__DOT__prod4_q)));
    vlSelf->testbench__DOT__str_inst__DOT__do_dec_p1 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_ok) 
           & (4U == (IData)(vlSelf->testbench__DOT__selezione)));
    vlSelf->testbench__DOT__str_inst__DOT__do_dec_p2 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_ok) 
           & (5U == (IData)(vlSelf->testbench__DOT__selezione)));
    vlSelf->testbench__DOT__str_inst__DOT__do_dec_p3 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_ok) 
           & (6U == (IData)(vlSelf->testbench__DOT__selezione)));
    vlSelf->testbench__DOT__str_inst__DOT__do_dec_p4 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_ok) 
           & (7U == (IData)(vlSelf->testbench__DOT__selezione)));
    vlSelf->testbench__DOT__str_inst__DOT__qty_p1_d 
        = (0x3fU & ((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_qty_p1)
                     ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_data)
                     : ((IData)(vlSelf->testbench__DOT__str_inst__DOT__qty_p1_q) 
                        - (IData)(vlSelf->testbench__DOT__str_inst__DOT__do_dec_p1))));
    vlSelf->testbench__DOT__str_inst__DOT__qty_p2_d 
        = (0x3fU & ((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_qty_p2)
                     ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_data)
                     : ((IData)(vlSelf->testbench__DOT__str_inst__DOT__qty_p2_q) 
                        - (IData)(vlSelf->testbench__DOT__str_inst__DOT__do_dec_p2))));
    vlSelf->testbench__DOT__str_inst__DOT__qty_p3_d 
        = (0x3fU & ((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_qty_p3)
                     ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_data)
                     : ((IData)(vlSelf->testbench__DOT__str_inst__DOT__qty_p3_q) 
                        - (IData)(vlSelf->testbench__DOT__str_inst__DOT__do_dec_p3))));
    vlSelf->testbench__DOT__str_inst__DOT__qty_p4_d 
        = (0x3fU & ((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_qty_p4)
                     ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_data)
                     : ((IData)(vlSelf->testbench__DOT__str_inst__DOT__qty_p4_q) 
                        - (IData)(vlSelf->testbench__DOT__str_inst__DOT__do_dec_p4))));
}

void Vtestbench___024root___eval_act(Vtestbench___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtestbench__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtestbench___024root___eval_act\n"); );
    // Body
    if ((0xaULL & vlSelf->__VactTriggered.word(0U))) {
        Vtestbench___024root___act_comb__TOP__0(vlSelf);
        vlSelf->__Vm_traceActivity[3U] = 1U;
    }
}

VL_INLINE_OPT void Vtestbench___024root___nba_sequent__TOP__0(Vtestbench___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtestbench__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtestbench___024root___nba_sequent__TOP__0\n"); );
    // Body
    vlSelf->testbench__DOT__cycle_count = ((IData)(vlSelf->testbench__DOT__rst)
                                            ? ((IData)(1U) 
                                               + vlSelf->testbench__DOT__cycle_count)
                                            : 0U);
}

VL_INLINE_OPT void Vtestbench___024root___nba_sequent__TOP__1(Vtestbench___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtestbench__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtestbench___024root___nba_sequent__TOP__1\n"); );
    // Body
    vlSelf->__Vdly__testbench__DOT__beh_inst__DOT__init_counter 
        = vlSelf->testbench__DOT__beh_inst__DOT__init_counter;
    vlSelf->__Vdly__testbench__DOT__credito_b = vlSelf->testbench__DOT__credito_b;
    vlSelf->__Vdly__testbench__DOT__disp_b = vlSelf->testbench__DOT__disp_b;
    vlSelf->__Vdly__testbench__DOT__beh_inst__DOT__stato 
        = vlSelf->testbench__DOT__beh_inst__DOT__stato;
    if (vlSelf->testbench__DOT__rst) {
        if ((0U == (IData)(vlSelf->testbench__DOT__str_inst__DOT__CTRL__DOT__stato))) {
            vlSelf->testbench__DOT__str_inst__DOT__init_counter_w 
                = ((0xbU > (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_counter_w))
                    ? (0xfU & ((IData)(1U) + (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_counter_w)))
                    : 0U);
        }
        if (vlSelf->testbench__DOT__conferma) {
            vlSelf->testbench__DOT__str_inst__DOT__sel_latched 
                = vlSelf->testbench__DOT__selezione;
        }
        if (vlSelf->testbench__DOT__str_inst__DOT__do_ok) {
            vlSelf->testbench__DOT__str_inst__DOT__current_price_q 
                = vlSelf->testbench__DOT__str_inst__DOT__current_price_d;
        }
        if (((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_c10) 
             | (IData)(vlSelf->testbench__DOT__str_inst__DOT__do_erogazione))) {
            vlSelf->testbench__DOT__str_inst__DOT__qty_c10_q 
                = vlSelf->testbench__DOT__str_inst__DOT__qty_c10_d;
        }
        if (((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_c05) 
             | (IData)(vlSelf->testbench__DOT__str_inst__DOT__do_erogazione))) {
            vlSelf->testbench__DOT__str_inst__DOT__qty_c05_q 
                = vlSelf->testbench__DOT__str_inst__DOT__qty_c05_d;
        }
        if (((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_c02) 
             | (IData)(vlSelf->testbench__DOT__str_inst__DOT__do_erogazione))) {
            vlSelf->testbench__DOT__str_inst__DOT__qty_c02_q 
                = vlSelf->testbench__DOT__str_inst__DOT__qty_c02_d;
        }
        if (((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_c01) 
             | (IData)(vlSelf->testbench__DOT__str_inst__DOT__do_erogazione))) {
            vlSelf->testbench__DOT__str_inst__DOT__qty_c01_q 
                = vlSelf->testbench__DOT__str_inst__DOT__qty_c01_d;
        }
        if (((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_qty_p4) 
             | (IData)(vlSelf->testbench__DOT__str_inst__DOT__do_dec_p4))) {
            vlSelf->testbench__DOT__str_inst__DOT__qty_p4_q 
                = vlSelf->testbench__DOT__str_inst__DOT__qty_p4_d;
        }
        if (((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_qty_p3) 
             | (IData)(vlSelf->testbench__DOT__str_inst__DOT__do_dec_p3))) {
            vlSelf->testbench__DOT__str_inst__DOT__qty_p3_q 
                = vlSelf->testbench__DOT__str_inst__DOT__qty_p3_d;
        }
        if (((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_qty_p2) 
             | (IData)(vlSelf->testbench__DOT__str_inst__DOT__do_dec_p2))) {
            vlSelf->testbench__DOT__str_inst__DOT__qty_p2_q 
                = vlSelf->testbench__DOT__str_inst__DOT__qty_p2_d;
        }
        if (((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_qty_p1) 
             | (IData)(vlSelf->testbench__DOT__str_inst__DOT__do_dec_p1))) {
            vlSelf->testbench__DOT__str_inst__DOT__qty_p1_q 
                = vlSelf->testbench__DOT__str_inst__DOT__qty_p1_d;
        }
        if (vlSelf->testbench__DOT__str_inst__DOT__init_price_p4) {
            vlSelf->testbench__DOT__str_inst__DOT__price_p4_q 
                = vlSelf->testbench__DOT__str_inst__DOT__price_p4_d;
        }
        if (vlSelf->testbench__DOT__str_inst__DOT__init_price_p3) {
            vlSelf->testbench__DOT__str_inst__DOT__price_p3_q 
                = vlSelf->testbench__DOT__str_inst__DOT__price_p3_d;
        }
        if (vlSelf->testbench__DOT__str_inst__DOT__init_price_p2) {
            vlSelf->testbench__DOT__str_inst__DOT__price_p2_q 
                = vlSelf->testbench__DOT__str_inst__DOT__price_p2_d;
        }
        if (vlSelf->testbench__DOT__str_inst__DOT__init_price_p1) {
            vlSelf->testbench__DOT__str_inst__DOT__price_p1_q 
                = vlSelf->testbench__DOT__str_inst__DOT__price_p1_d;
        }
        vlSelf->testbench__DOT__str_inst__DOT__CTRL__DOT__stato 
            = vlSelf->testbench__DOT__str_inst__DOT__CTRL__DOT__next_stato;
    } else {
        vlSelf->testbench__DOT__str_inst__DOT__init_counter_w = 0U;
        vlSelf->testbench__DOT__str_inst__DOT__sel_latched = 0U;
        vlSelf->testbench__DOT__str_inst__DOT__current_price_q = 0U;
        vlSelf->testbench__DOT__str_inst__DOT__qty_c10_q = 0U;
        vlSelf->testbench__DOT__str_inst__DOT__qty_c05_q = 0U;
        vlSelf->testbench__DOT__str_inst__DOT__qty_c02_q = 0U;
        vlSelf->testbench__DOT__str_inst__DOT__qty_c01_q = 0U;
        vlSelf->testbench__DOT__str_inst__DOT__qty_p4_q = 0U;
        vlSelf->testbench__DOT__str_inst__DOT__qty_p3_q = 0U;
        vlSelf->testbench__DOT__str_inst__DOT__qty_p2_q = 0U;
        vlSelf->testbench__DOT__str_inst__DOT__qty_p1_q = 0U;
        vlSelf->testbench__DOT__str_inst__DOT__price_p4_q = 0U;
        vlSelf->testbench__DOT__str_inst__DOT__price_p3_q = 0U;
        vlSelf->testbench__DOT__str_inst__DOT__price_p2_q = 0U;
        vlSelf->testbench__DOT__str_inst__DOT__price_p1_q = 0U;
        vlSelf->testbench__DOT__str_inst__DOT__CTRL__DOT__stato = 0U;
    }
    vlSelf->testbench__DOT__str_inst__DOT__mode_init = 0U;
    if ((1U & (~ ((IData)(vlSelf->testbench__DOT__str_inst__DOT__CTRL__DOT__stato) 
                  >> 1U)))) {
        if ((1U & (~ (IData)(vlSelf->testbench__DOT__str_inst__DOT__CTRL__DOT__stato)))) {
            vlSelf->testbench__DOT__str_inst__DOT__mode_init = 1U;
        }
    }
    vlSelf->testbench__DOT__str_inst__DOT__init_price_p1 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__mode_init) 
           & (1U == (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_counter_w)));
    vlSelf->testbench__DOT__str_inst__DOT__init_price_p2 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__mode_init) 
           & (3U == (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_counter_w)));
    vlSelf->testbench__DOT__str_inst__DOT__init_price_p3 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__mode_init) 
           & (5U == (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_counter_w)));
    vlSelf->testbench__DOT__str_inst__DOT__init_price_p4 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__mode_init) 
           & (7U == (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_counter_w)));
    vlSelf->testbench__DOT__str_inst__DOT__init_qty_p1 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__mode_init) 
           & (0U == (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_counter_w)));
    vlSelf->testbench__DOT__str_inst__DOT__init_qty_p2 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__mode_init) 
           & (2U == (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_counter_w)));
    vlSelf->testbench__DOT__str_inst__DOT__init_qty_p3 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__mode_init) 
           & (4U == (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_counter_w)));
    vlSelf->testbench__DOT__str_inst__DOT__init_qty_p4 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__mode_init) 
           & (6U == (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_counter_w)));
    vlSelf->testbench__DOT__str_inst__DOT__init_c01 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__mode_init) 
           & (8U == (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_counter_w)));
    vlSelf->testbench__DOT__str_inst__DOT__init_c02 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__mode_init) 
           & (9U == (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_counter_w)));
    vlSelf->testbench__DOT__str_inst__DOT__init_c05 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__mode_init) 
           & (0xaU == (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_counter_w)));
    vlSelf->testbench__DOT__str_inst__DOT__init_c10 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__mode_init) 
           & (0xbU == (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_counter_w)));
}

VL_INLINE_OPT void Vtestbench___024root___nba_comb__TOP__0(Vtestbench___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtestbench__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtestbench___024root___nba_comb__TOP__0\n"); );
    // Init
    CData/*2:0*/ __Vtableidx1;
    __Vtableidx1 = 0;
    // Body
    __Vtableidx1 = vlSelf->testbench__DOT__coin;
    vlSelf->testbench__DOT__str_inst__DOT__coin_value 
        = Vtestbench__ConstPool__TABLE_h98991338_0[__Vtableidx1];
    vlSelf->testbench__DOT__str_inst__DOT__init_data 
        = (((IData)(vlSelf->testbench__DOT__coin) << 3U) 
           | (IData)(vlSelf->testbench__DOT__selezione));
}

VL_INLINE_OPT void Vtestbench___024root___nba_comb__TOP__1(Vtestbench___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtestbench__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtestbench___024root___nba_comb__TOP__1\n"); );
    // Body
    if ((2U & (IData)(vlSelf->testbench__DOT__selezione))) {
        if ((1U & (IData)(vlSelf->testbench__DOT__selezione))) {
            vlSelf->testbench__DOT__str_inst__DOT__sel_qty 
                = vlSelf->testbench__DOT__str_inst__DOT__qty_p4_q;
            vlSelf->testbench__DOT__str_inst__DOT__sel_price 
                = vlSelf->testbench__DOT__str_inst__DOT__price_p4_q;
        } else {
            vlSelf->testbench__DOT__str_inst__DOT__sel_qty 
                = vlSelf->testbench__DOT__str_inst__DOT__qty_p3_q;
            vlSelf->testbench__DOT__str_inst__DOT__sel_price 
                = vlSelf->testbench__DOT__str_inst__DOT__price_p3_q;
        }
    } else if ((1U & (IData)(vlSelf->testbench__DOT__selezione))) {
        vlSelf->testbench__DOT__str_inst__DOT__sel_qty 
            = vlSelf->testbench__DOT__str_inst__DOT__qty_p2_q;
        vlSelf->testbench__DOT__str_inst__DOT__sel_price 
            = vlSelf->testbench__DOT__str_inst__DOT__price_p2_q;
    } else {
        vlSelf->testbench__DOT__str_inst__DOT__sel_qty 
            = vlSelf->testbench__DOT__str_inst__DOT__qty_p1_q;
        vlSelf->testbench__DOT__str_inst__DOT__sel_price 
            = vlSelf->testbench__DOT__str_inst__DOT__price_p1_q;
    }
    vlSelf->testbench__DOT__str_inst__DOT__do_add_coin = 0U;
    if ((2U & (IData)(vlSelf->testbench__DOT__str_inst__DOT__CTRL__DOT__stato))) {
        if ((1U & (~ (IData)(vlSelf->testbench__DOT__str_inst__DOT__CTRL__DOT__stato)))) {
            if ((0U != (IData)(vlSelf->testbench__DOT__coin))) {
                vlSelf->testbench__DOT__str_inst__DOT__do_add_coin = 1U;
            }
        }
    } else if ((1U & (IData)(vlSelf->testbench__DOT__str_inst__DOT__CTRL__DOT__stato))) {
        if ((0U != (IData)(vlSelf->testbench__DOT__coin))) {
            vlSelf->testbench__DOT__str_inst__DOT__do_add_coin = 1U;
        }
    }
    vlSelf->testbench__DOT__str_inst__DOT__price_p1_d 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_price_p1)
            ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_data)
            : (IData)(vlSelf->testbench__DOT__str_inst__DOT__price_p1_q));
    vlSelf->testbench__DOT__str_inst__DOT__price_p2_d 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_price_p2)
            ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_data)
            : (IData)(vlSelf->testbench__DOT__str_inst__DOT__price_p2_q));
    vlSelf->testbench__DOT__str_inst__DOT__price_p3_d 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_price_p3)
            ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_data)
            : (IData)(vlSelf->testbench__DOT__str_inst__DOT__price_p3_q));
    vlSelf->testbench__DOT__str_inst__DOT__price_p4_d 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_price_p4)
            ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_data)
            : (IData)(vlSelf->testbench__DOT__str_inst__DOT__price_p4_q));
}

VL_INLINE_OPT void Vtestbench___024root___nba_sequent__TOP__3(Vtestbench___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtestbench__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtestbench___024root___nba_sequent__TOP__3\n"); );
    // Body
    if (vlSelf->testbench__DOT__rst) {
        if (vlSelf->testbench__DOT__str_inst__DOT__we_prod) {
            vlSelf->testbench__DOT__str_inst__DOT__prod1_q 
                = vlSelf->testbench__DOT__str_inst__DOT__prod1_d;
            vlSelf->testbench__DOT__str_inst__DOT__prod2_q 
                = vlSelf->testbench__DOT__str_inst__DOT__prod2_d;
            vlSelf->testbench__DOT__str_inst__DOT__prod3_q 
                = vlSelf->testbench__DOT__str_inst__DOT__prod3_d;
            vlSelf->testbench__DOT__str_inst__DOT__prod4_q 
                = vlSelf->testbench__DOT__str_inst__DOT__prod4_d;
        }
        if (vlSelf->testbench__DOT__str_inst__DOT__we_coin_out) {
            vlSelf->testbench__DOT__str_inst__DOT__coin01_q 
                = vlSelf->testbench__DOT__str_inst__DOT__coin01_d;
            vlSelf->testbench__DOT__str_inst__DOT__coin02_q 
                = vlSelf->testbench__DOT__str_inst__DOT__coin02_d;
            vlSelf->testbench__DOT__str_inst__DOT__coin05_q 
                = vlSelf->testbench__DOT__str_inst__DOT__coin05_d;
            vlSelf->testbench__DOT__str_inst__DOT__coin10_q 
                = vlSelf->testbench__DOT__str_inst__DOT__coin10_d;
        }
        if (vlSelf->testbench__DOT__str_inst__DOT__we_credito) {
            vlSelf->testbench__DOT__str_inst__DOT__disponibile_q 
                = vlSelf->testbench__DOT__str_inst__DOT__disponibile_d;
            vlSelf->testbench__DOT__str_inst__DOT__credito_q 
                = vlSelf->testbench__DOT__str_inst__DOT__credito_d;
        }
        if (((IData)(vlSelf->testbench__DOT__str_inst__DOT__clear_outputs) 
             | (IData)(vlSelf->testbench__DOT__str_inst__DOT__do_err))) {
            vlSelf->testbench__DOT__str_inst__DOT__errore_q 
                = vlSelf->testbench__DOT__str_inst__DOT__errore_d;
        }
        if ((2U & (IData)(vlSelf->testbench__DOT__beh_inst__DOT__stato))) {
            if ((1U & (IData)(vlSelf->testbench__DOT__beh_inst__DOT__stato))) {
                vlSelf->testbench__DOT__beh_inst__DOT__calc_resto 
                    = (0x3fU & ((IData)(vlSelf->testbench__DOT__credito_b) 
                                - (IData)(vlSelf->testbench__DOT__beh_inst__DOT__current_price)));
                vlSelf->testbench__DOT__resto_b = vlSelf->testbench__DOT__beh_inst__DOT__calc_resto;
                vlSelf->__Vdly__testbench__DOT__beh_inst__DOT__stato = 1U;
                vlSelf->testbench__DOT__beh_inst__DOT__calc_qty 
                    = (0x3fU & VL_DIV_III(32, (IData)(vlSelf->testbench__DOT__beh_inst__DOT__calc_resto), (IData)(0xaU)));
                if (((IData)(vlSelf->testbench__DOT__beh_inst__DOT__calc_qty) 
                     > (IData)(vlSelf->testbench__DOT__beh_inst__DOT__qty_c10))) {
                    vlSelf->testbench__DOT__beh_inst__DOT__calc_qty 
                        = vlSelf->testbench__DOT__beh_inst__DOT__qty_c10;
                }
                vlSelf->testbench__DOT__c10_b = vlSelf->testbench__DOT__beh_inst__DOT__calc_qty;
                vlSelf->testbench__DOT__beh_inst__DOT__qty_c10 
                    = (0x3fU & ((IData)(vlSelf->testbench__DOT__beh_inst__DOT__qty_c10) 
                                - (IData)(vlSelf->testbench__DOT__beh_inst__DOT__calc_qty)));
                vlSelf->testbench__DOT__beh_inst__DOT__calc_resto 
                    = (0x3fU & ((IData)(vlSelf->testbench__DOT__beh_inst__DOT__calc_resto) 
                                - ((IData)(0xaU) * (IData)(vlSelf->testbench__DOT__beh_inst__DOT__calc_qty))));
                vlSelf->testbench__DOT__beh_inst__DOT__calc_qty 
                    = (0x3fU & VL_DIV_III(32, (IData)(vlSelf->testbench__DOT__beh_inst__DOT__calc_resto), (IData)(5U)));
                if (((IData)(vlSelf->testbench__DOT__beh_inst__DOT__calc_qty) 
                     > (IData)(vlSelf->testbench__DOT__beh_inst__DOT__qty_c05))) {
                    vlSelf->testbench__DOT__beh_inst__DOT__calc_qty 
                        = vlSelf->testbench__DOT__beh_inst__DOT__qty_c05;
                }
                vlSelf->testbench__DOT__c05_b = vlSelf->testbench__DOT__beh_inst__DOT__calc_qty;
                vlSelf->testbench__DOT__beh_inst__DOT__qty_c05 
                    = (0x3fU & ((IData)(vlSelf->testbench__DOT__beh_inst__DOT__qty_c05) 
                                - (IData)(vlSelf->testbench__DOT__beh_inst__DOT__calc_qty)));
                vlSelf->testbench__DOT__beh_inst__DOT__calc_resto 
                    = (0x3fU & ((IData)(vlSelf->testbench__DOT__beh_inst__DOT__calc_resto) 
                                - ((IData)(5U) * (IData)(vlSelf->testbench__DOT__beh_inst__DOT__calc_qty))));
                vlSelf->testbench__DOT__beh_inst__DOT__calc_qty 
                    = (0x3fU & ((IData)(vlSelf->testbench__DOT__beh_inst__DOT__calc_resto) 
                                >> 1U));
                if (((IData)(vlSelf->testbench__DOT__beh_inst__DOT__calc_qty) 
                     > (IData)(vlSelf->testbench__DOT__beh_inst__DOT__qty_c02))) {
                    vlSelf->testbench__DOT__beh_inst__DOT__calc_qty 
                        = vlSelf->testbench__DOT__beh_inst__DOT__qty_c02;
                }
                vlSelf->testbench__DOT__c02_b = vlSelf->testbench__DOT__beh_inst__DOT__calc_qty;
                vlSelf->testbench__DOT__beh_inst__DOT__qty_c02 
                    = (0x3fU & ((IData)(vlSelf->testbench__DOT__beh_inst__DOT__qty_c02) 
                                - (IData)(vlSelf->testbench__DOT__beh_inst__DOT__calc_qty)));
                vlSelf->testbench__DOT__beh_inst__DOT__calc_resto 
                    = (0x3fU & ((IData)(vlSelf->testbench__DOT__beh_inst__DOT__calc_resto) 
                                - VL_SHIFTL_III(6,6,32, (IData)(vlSelf->testbench__DOT__beh_inst__DOT__calc_qty), 1U)));
                vlSelf->testbench__DOT__beh_inst__DOT__calc_qty 
                    = vlSelf->testbench__DOT__beh_inst__DOT__calc_resto;
                if (((IData)(vlSelf->testbench__DOT__beh_inst__DOT__calc_qty) 
                     > (IData)(vlSelf->testbench__DOT__beh_inst__DOT__qty_c01))) {
                    vlSelf->testbench__DOT__beh_inst__DOT__calc_qty 
                        = vlSelf->testbench__DOT__beh_inst__DOT__qty_c01;
                }
                vlSelf->testbench__DOT__c01_b = vlSelf->testbench__DOT__beh_inst__DOT__calc_qty;
                vlSelf->testbench__DOT__beh_inst__DOT__qty_c01 
                    = (0x3fU & ((IData)(vlSelf->testbench__DOT__beh_inst__DOT__qty_c01) 
                                - (IData)(vlSelf->testbench__DOT__beh_inst__DOT__calc_qty)));
                vlSelf->__Vdly__testbench__DOT__disp_b 
                    = (0x3ffU & ((IData)(vlSelf->testbench__DOT__disp_b) 
                                 - (0x3fU & ((IData)(vlSelf->testbench__DOT__credito_b) 
                                             - (IData)(vlSelf->testbench__DOT__beh_inst__DOT__current_price)))));
                vlSelf->__Vdly__testbench__DOT__credito_b = 0U;
            } else if ((0U != (IData)(vlSelf->testbench__DOT__coin))) {
                if ((4U & (IData)(vlSelf->testbench__DOT__coin))) {
                    if ((2U & (IData)(vlSelf->testbench__DOT__coin))) {
                        if ((1U & (IData)(vlSelf->testbench__DOT__coin))) {
                            vlSelf->__Vdly__testbench__DOT__credito_b 
                                = (0x3fU & ((IData)(0xaU) 
                                            + (IData)(vlSelf->testbench__DOT__credito_b)));
                            vlSelf->__Vdly__testbench__DOT__disp_b 
                                = (0x3ffU & ((IData)(0xaU) 
                                             + (IData)(vlSelf->testbench__DOT__disp_b)));
                        } else {
                            vlSelf->__Vdly__testbench__DOT__credito_b 
                                = (0x3fU & ((IData)(5U) 
                                            + (IData)(vlSelf->testbench__DOT__credito_b)));
                            vlSelf->__Vdly__testbench__DOT__disp_b 
                                = (0x3ffU & ((IData)(5U) 
                                             + (IData)(vlSelf->testbench__DOT__disp_b)));
                        }
                    } else if ((1U & (IData)(vlSelf->testbench__DOT__coin))) {
                        vlSelf->__Vdly__testbench__DOT__credito_b 
                            = (0x3fU & ((IData)(2U) 
                                        + (IData)(vlSelf->testbench__DOT__credito_b)));
                        vlSelf->__Vdly__testbench__DOT__disp_b 
                            = (0x3ffU & ((IData)(2U) 
                                         + (IData)(vlSelf->testbench__DOT__disp_b)));
                    } else {
                        vlSelf->__Vdly__testbench__DOT__credito_b 
                            = (0x3fU & ((IData)(1U) 
                                        + (IData)(vlSelf->testbench__DOT__credito_b)));
                        vlSelf->__Vdly__testbench__DOT__disp_b 
                            = (0x3ffU & ((IData)(1U) 
                                         + (IData)(vlSelf->testbench__DOT__disp_b)));
                    }
                }
            } else if (vlSelf->testbench__DOT__annulla) {
                vlSelf->testbench__DOT__resto_b = vlSelf->testbench__DOT__credito_b;
                vlSelf->__Vdly__testbench__DOT__beh_inst__DOT__stato = 1U;
                vlSelf->__Vdly__testbench__DOT__disp_b 
                    = (0x3ffU & ((IData)(vlSelf->testbench__DOT__disp_b) 
                                 - (IData)(vlSelf->testbench__DOT__credito_b)));
                vlSelf->__Vdly__testbench__DOT__credito_b = 0U;
            } else if (vlSelf->testbench__DOT__conferma) {
                if ((4U & (IData)(vlSelf->testbench__DOT__selezione))) {
                    if ((2U & (IData)(vlSelf->testbench__DOT__selezione))) {
                        if ((1U & (IData)(vlSelf->testbench__DOT__selezione))) {
                            if ((((IData)(vlSelf->testbench__DOT__credito_b) 
                                  < (IData)(vlSelf->testbench__DOT__beh_inst__DOT__price_p4)) 
                                 | (0U == (IData)(vlSelf->testbench__DOT__beh_inst__DOT__qty_p4)))) {
                                vlSelf->testbench__DOT__errore_b 
                                    = (((0U == (IData)(vlSelf->testbench__DOT__beh_inst__DOT__qty_p4)) 
                                        << 1U) | ((IData)(vlSelf->testbench__DOT__credito_b) 
                                                  < (IData)(vlSelf->testbench__DOT__beh_inst__DOT__price_p4)));
                                vlSelf->__Vdly__testbench__DOT__beh_inst__DOT__stato = 1U;
                                if (((IData)(vlSelf->testbench__DOT__credito_b) 
                                     < (IData)(vlSelf->testbench__DOT__beh_inst__DOT__price_p4))) {
                                    vlSelf->testbench__DOT__resto_b 
                                        = vlSelf->testbench__DOT__beh_inst__DOT__price_p4;
                                }
                            } else {
                                vlSelf->testbench__DOT__beh_inst__DOT__current_price 
                                    = vlSelf->testbench__DOT__beh_inst__DOT__price_p4;
                                vlSelf->testbench__DOT__beh_inst__DOT__qty_p4 
                                    = (0x3fU & ((IData)(vlSelf->testbench__DOT__beh_inst__DOT__qty_p4) 
                                                - (IData)(1U)));
                                vlSelf->testbench__DOT__p4_b = 1U;
                                vlSelf->__Vdly__testbench__DOT__beh_inst__DOT__stato = 3U;
                            }
                        } else if ((((IData)(vlSelf->testbench__DOT__credito_b) 
                                     < (IData)(vlSelf->testbench__DOT__beh_inst__DOT__price_p3)) 
                                    | (0U == (IData)(vlSelf->testbench__DOT__beh_inst__DOT__qty_p3)))) {
                            vlSelf->testbench__DOT__errore_b 
                                = (((0U == (IData)(vlSelf->testbench__DOT__beh_inst__DOT__qty_p3)) 
                                    << 1U) | ((IData)(vlSelf->testbench__DOT__credito_b) 
                                              < (IData)(vlSelf->testbench__DOT__beh_inst__DOT__price_p3)));
                            vlSelf->__Vdly__testbench__DOT__beh_inst__DOT__stato = 1U;
                            if (((IData)(vlSelf->testbench__DOT__credito_b) 
                                 < (IData)(vlSelf->testbench__DOT__beh_inst__DOT__price_p3))) {
                                vlSelf->testbench__DOT__resto_b 
                                    = vlSelf->testbench__DOT__beh_inst__DOT__price_p3;
                            }
                        } else {
                            vlSelf->testbench__DOT__beh_inst__DOT__current_price 
                                = vlSelf->testbench__DOT__beh_inst__DOT__price_p3;
                            vlSelf->testbench__DOT__beh_inst__DOT__qty_p3 
                                = (0x3fU & ((IData)(vlSelf->testbench__DOT__beh_inst__DOT__qty_p3) 
                                            - (IData)(1U)));
                            vlSelf->testbench__DOT__p3_b = 1U;
                            vlSelf->__Vdly__testbench__DOT__beh_inst__DOT__stato = 3U;
                        }
                    } else if ((1U & (IData)(vlSelf->testbench__DOT__selezione))) {
                        if ((((IData)(vlSelf->testbench__DOT__credito_b) 
                              < (IData)(vlSelf->testbench__DOT__beh_inst__DOT__price_p2)) 
                             | (0U == (IData)(vlSelf->testbench__DOT__beh_inst__DOT__qty_p2)))) {
                            vlSelf->testbench__DOT__errore_b 
                                = (((0U == (IData)(vlSelf->testbench__DOT__beh_inst__DOT__qty_p2)) 
                                    << 1U) | ((IData)(vlSelf->testbench__DOT__credito_b) 
                                              < (IData)(vlSelf->testbench__DOT__beh_inst__DOT__price_p2)));
                            vlSelf->__Vdly__testbench__DOT__beh_inst__DOT__stato = 1U;
                            if (((IData)(vlSelf->testbench__DOT__credito_b) 
                                 < (IData)(vlSelf->testbench__DOT__beh_inst__DOT__price_p2))) {
                                vlSelf->testbench__DOT__resto_b 
                                    = vlSelf->testbench__DOT__beh_inst__DOT__price_p2;
                            }
                        } else {
                            vlSelf->testbench__DOT__beh_inst__DOT__current_price 
                                = vlSelf->testbench__DOT__beh_inst__DOT__price_p2;
                            vlSelf->testbench__DOT__beh_inst__DOT__qty_p2 
                                = (0x3fU & ((IData)(vlSelf->testbench__DOT__beh_inst__DOT__qty_p2) 
                                            - (IData)(1U)));
                            vlSelf->testbench__DOT__p2_b = 1U;
                            vlSelf->__Vdly__testbench__DOT__beh_inst__DOT__stato = 3U;
                        }
                    } else if ((((IData)(vlSelf->testbench__DOT__credito_b) 
                                 < (IData)(vlSelf->testbench__DOT__beh_inst__DOT__price_p1)) 
                                | (0U == (IData)(vlSelf->testbench__DOT__beh_inst__DOT__qty_p1)))) {
                        vlSelf->testbench__DOT__errore_b 
                            = (((0U == (IData)(vlSelf->testbench__DOT__beh_inst__DOT__qty_p1)) 
                                << 1U) | ((IData)(vlSelf->testbench__DOT__credito_b) 
                                          < (IData)(vlSelf->testbench__DOT__beh_inst__DOT__price_p1)));
                        vlSelf->__Vdly__testbench__DOT__beh_inst__DOT__stato = 1U;
                        if (((IData)(vlSelf->testbench__DOT__credito_b) 
                             < (IData)(vlSelf->testbench__DOT__beh_inst__DOT__price_p1))) {
                            vlSelf->testbench__DOT__resto_b 
                                = vlSelf->testbench__DOT__beh_inst__DOT__price_p1;
                        }
                    } else {
                        vlSelf->testbench__DOT__beh_inst__DOT__current_price 
                            = vlSelf->testbench__DOT__beh_inst__DOT__price_p1;
                        vlSelf->testbench__DOT__beh_inst__DOT__qty_p1 
                            = (0x3fU & ((IData)(vlSelf->testbench__DOT__beh_inst__DOT__qty_p1) 
                                        - (IData)(1U)));
                        vlSelf->testbench__DOT__p1_b = 1U;
                        vlSelf->__Vdly__testbench__DOT__beh_inst__DOT__stato = 3U;
                    }
                } else {
                    vlSelf->__Vdly__testbench__DOT__beh_inst__DOT__stato = 1U;
                }
            }
        } else if ((1U & (IData)(vlSelf->testbench__DOT__beh_inst__DOT__stato))) {
            vlSelf->testbench__DOT__p1_b = 0U;
            vlSelf->testbench__DOT__p2_b = 0U;
            vlSelf->testbench__DOT__p3_b = 0U;
            vlSelf->testbench__DOT__p4_b = 0U;
            vlSelf->testbench__DOT__errore_b = 0U;
            vlSelf->testbench__DOT__resto_b = 0U;
            vlSelf->testbench__DOT__c01_b = 0U;
            vlSelf->testbench__DOT__c02_b = 0U;
            vlSelf->testbench__DOT__c05_b = 0U;
            vlSelf->testbench__DOT__c10_b = 0U;
            if ((0U != (IData)(vlSelf->testbench__DOT__coin))) {
                if ((4U & (IData)(vlSelf->testbench__DOT__coin))) {
                    if ((2U & (IData)(vlSelf->testbench__DOT__coin))) {
                        if ((1U & (IData)(vlSelf->testbench__DOT__coin))) {
                            vlSelf->__Vdly__testbench__DOT__credito_b 
                                = (0x3fU & ((IData)(0xaU) 
                                            + (IData)(vlSelf->testbench__DOT__credito_b)));
                            vlSelf->__Vdly__testbench__DOT__disp_b 
                                = (0x3ffU & ((IData)(0xaU) 
                                             + (IData)(vlSelf->testbench__DOT__disp_b)));
                        } else {
                            vlSelf->__Vdly__testbench__DOT__credito_b 
                                = (0x3fU & ((IData)(5U) 
                                            + (IData)(vlSelf->testbench__DOT__credito_b)));
                            vlSelf->__Vdly__testbench__DOT__disp_b 
                                = (0x3ffU & ((IData)(5U) 
                                             + (IData)(vlSelf->testbench__DOT__disp_b)));
                        }
                    } else if ((1U & (IData)(vlSelf->testbench__DOT__coin))) {
                        vlSelf->__Vdly__testbench__DOT__credito_b 
                            = (0x3fU & ((IData)(2U) 
                                        + (IData)(vlSelf->testbench__DOT__credito_b)));
                        vlSelf->__Vdly__testbench__DOT__disp_b 
                            = (0x3ffU & ((IData)(2U) 
                                         + (IData)(vlSelf->testbench__DOT__disp_b)));
                    } else {
                        vlSelf->__Vdly__testbench__DOT__credito_b 
                            = (0x3fU & ((IData)(1U) 
                                        + (IData)(vlSelf->testbench__DOT__credito_b)));
                        vlSelf->__Vdly__testbench__DOT__disp_b 
                            = (0x3ffU & ((IData)(1U) 
                                         + (IData)(vlSelf->testbench__DOT__disp_b)));
                    }
                }
                vlSelf->__Vdly__testbench__DOT__beh_inst__DOT__stato = 2U;
            }
        } else {
            if ((8U & (IData)(vlSelf->testbench__DOT__beh_inst__DOT__init_counter))) {
                if ((1U & (~ ((IData)(vlSelf->testbench__DOT__beh_inst__DOT__init_counter) 
                              >> 2U)))) {
                    if ((2U & (IData)(vlSelf->testbench__DOT__beh_inst__DOT__init_counter))) {
                        if ((1U & (IData)(vlSelf->testbench__DOT__beh_inst__DOT__init_counter))) {
                            vlSelf->testbench__DOT__beh_inst__DOT__qty_c10 
                                = (((IData)(vlSelf->testbench__DOT__coin) 
                                    << 3U) | (IData)(vlSelf->testbench__DOT__selezione));
                            vlSelf->__Vdly__testbench__DOT__beh_inst__DOT__stato = 1U;
                            vlSelf->__Vdly__testbench__DOT__beh_inst__DOT__init_counter = 0U;
                        } else {
                            vlSelf->testbench__DOT__beh_inst__DOT__qty_c05 
                                = (((IData)(vlSelf->testbench__DOT__coin) 
                                    << 3U) | (IData)(vlSelf->testbench__DOT__selezione));
                        }
                    } else if ((1U & (IData)(vlSelf->testbench__DOT__beh_inst__DOT__init_counter))) {
                        vlSelf->testbench__DOT__beh_inst__DOT__qty_c02 
                            = (((IData)(vlSelf->testbench__DOT__coin) 
                                << 3U) | (IData)(vlSelf->testbench__DOT__selezione));
                    } else {
                        vlSelf->testbench__DOT__beh_inst__DOT__qty_c01 
                            = (((IData)(vlSelf->testbench__DOT__coin) 
                                << 3U) | (IData)(vlSelf->testbench__DOT__selezione));
                    }
                }
            } else if ((4U & (IData)(vlSelf->testbench__DOT__beh_inst__DOT__init_counter))) {
                if ((2U & (IData)(vlSelf->testbench__DOT__beh_inst__DOT__init_counter))) {
                    if ((1U & (IData)(vlSelf->testbench__DOT__beh_inst__DOT__init_counter))) {
                        vlSelf->testbench__DOT__beh_inst__DOT__price_p4 
                            = (((IData)(vlSelf->testbench__DOT__coin) 
                                << 3U) | (IData)(vlSelf->testbench__DOT__selezione));
                    } else {
                        vlSelf->testbench__DOT__beh_inst__DOT__qty_p4 
                            = (((IData)(vlSelf->testbench__DOT__coin) 
                                << 3U) | (IData)(vlSelf->testbench__DOT__selezione));
                    }
                } else if ((1U & (IData)(vlSelf->testbench__DOT__beh_inst__DOT__init_counter))) {
                    vlSelf->testbench__DOT__beh_inst__DOT__price_p3 
                        = (((IData)(vlSelf->testbench__DOT__coin) 
                            << 3U) | (IData)(vlSelf->testbench__DOT__selezione));
                } else {
                    vlSelf->testbench__DOT__beh_inst__DOT__qty_p3 
                        = (((IData)(vlSelf->testbench__DOT__coin) 
                            << 3U) | (IData)(vlSelf->testbench__DOT__selezione));
                }
            } else if ((2U & (IData)(vlSelf->testbench__DOT__beh_inst__DOT__init_counter))) {
                if ((1U & (IData)(vlSelf->testbench__DOT__beh_inst__DOT__init_counter))) {
                    vlSelf->testbench__DOT__beh_inst__DOT__price_p2 
                        = (((IData)(vlSelf->testbench__DOT__coin) 
                            << 3U) | (IData)(vlSelf->testbench__DOT__selezione));
                } else {
                    vlSelf->testbench__DOT__beh_inst__DOT__qty_p2 
                        = (((IData)(vlSelf->testbench__DOT__coin) 
                            << 3U) | (IData)(vlSelf->testbench__DOT__selezione));
                }
            } else if ((1U & (IData)(vlSelf->testbench__DOT__beh_inst__DOT__init_counter))) {
                vlSelf->testbench__DOT__beh_inst__DOT__price_p1 
                    = (((IData)(vlSelf->testbench__DOT__coin) 
                        << 3U) | (IData)(vlSelf->testbench__DOT__selezione));
            } else {
                vlSelf->testbench__DOT__beh_inst__DOT__qty_p1 
                    = (((IData)(vlSelf->testbench__DOT__coin) 
                        << 3U) | (IData)(vlSelf->testbench__DOT__selezione));
            }
            if ((0xbU > (IData)(vlSelf->testbench__DOT__beh_inst__DOT__init_counter))) {
                vlSelf->__Vdly__testbench__DOT__beh_inst__DOT__init_counter 
                    = (0xfU & ((IData)(1U) + (IData)(vlSelf->testbench__DOT__beh_inst__DOT__init_counter)));
            }
        }
        if (((IData)(vlSelf->testbench__DOT__str_inst__DOT__clear_outputs) 
             | ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_cancel) 
                | ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_erogazione) 
                   | (IData)(vlSelf->testbench__DOT__str_inst__DOT__do_err))))) {
            vlSelf->testbench__DOT__str_inst__DOT__resto_q 
                = vlSelf->testbench__DOT__str_inst__DOT__resto_d;
        }
    } else {
        vlSelf->testbench__DOT__str_inst__DOT__prod1_q = 0U;
        vlSelf->testbench__DOT__str_inst__DOT__prod2_q = 0U;
        vlSelf->testbench__DOT__str_inst__DOT__prod3_q = 0U;
        vlSelf->testbench__DOT__str_inst__DOT__prod4_q = 0U;
        vlSelf->testbench__DOT__str_inst__DOT__coin01_q = 0U;
        vlSelf->testbench__DOT__str_inst__DOT__coin02_q = 0U;
        vlSelf->testbench__DOT__str_inst__DOT__coin05_q = 0U;
        vlSelf->testbench__DOT__str_inst__DOT__coin10_q = 0U;
        vlSelf->testbench__DOT__str_inst__DOT__disponibile_q = 0U;
        vlSelf->testbench__DOT__str_inst__DOT__errore_q = 0U;
        vlSelf->__Vdly__testbench__DOT__beh_inst__DOT__stato = 0U;
        vlSelf->__Vdly__testbench__DOT__beh_inst__DOT__init_counter = 0U;
        vlSelf->__Vdly__testbench__DOT__credito_b = 0U;
        vlSelf->__Vdly__testbench__DOT__disp_b = 0U;
        vlSelf->testbench__DOT__errore_b = 0U;
        vlSelf->testbench__DOT__resto_b = 0U;
        vlSelf->testbench__DOT__p1_b = 0U;
        vlSelf->testbench__DOT__p2_b = 0U;
        vlSelf->testbench__DOT__p3_b = 0U;
        vlSelf->testbench__DOT__p4_b = 0U;
        vlSelf->testbench__DOT__c01_b = 0U;
        vlSelf->testbench__DOT__c02_b = 0U;
        vlSelf->testbench__DOT__c05_b = 0U;
        vlSelf->testbench__DOT__c10_b = 0U;
        vlSelf->testbench__DOT__str_inst__DOT__resto_q = 0U;
        vlSelf->testbench__DOT__str_inst__DOT__credito_q = 0U;
    }
    vlSelf->testbench__DOT__beh_inst__DOT__stato = vlSelf->__Vdly__testbench__DOT__beh_inst__DOT__stato;
    vlSelf->testbench__DOT__disp_b = vlSelf->__Vdly__testbench__DOT__disp_b;
    vlSelf->testbench__DOT__credito_b = vlSelf->__Vdly__testbench__DOT__credito_b;
    vlSelf->testbench__DOT__beh_inst__DOT__init_counter 
        = vlSelf->__Vdly__testbench__DOT__beh_inst__DOT__init_counter;
    vlSelf->testbench__DOT__str_inst__DOT__clear_outputs = 0U;
    if ((1U & (~ ((IData)(vlSelf->testbench__DOT__str_inst__DOT__CTRL__DOT__stato) 
                  >> 1U)))) {
        if ((1U & (IData)(vlSelf->testbench__DOT__str_inst__DOT__CTRL__DOT__stato))) {
            vlSelf->testbench__DOT__str_inst__DOT__clear_outputs = 1U;
        }
    }
    vlSelf->testbench__DOT__str_inst__DOT__do_erogazione = 0U;
    if ((2U & (IData)(vlSelf->testbench__DOT__str_inst__DOT__CTRL__DOT__stato))) {
        if ((1U & (IData)(vlSelf->testbench__DOT__str_inst__DOT__CTRL__DOT__stato))) {
            vlSelf->testbench__DOT__str_inst__DOT__do_erogazione = 1U;
        }
    }
    vlSelf->testbench__DOT__str_inst__DOT__we_coin_out 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__clear_outputs) 
           | (IData)(vlSelf->testbench__DOT__str_inst__DOT__do_erogazione));
    vlSelf->testbench__DOT__str_inst__DOT__change6 
        = (0x3fU & ((IData)(vlSelf->testbench__DOT__str_inst__DOT__credito_q) 
                    - (IData)(vlSelf->testbench__DOT__str_inst__DOT__current_price_q)));
    vlSelf->testbench__DOT__str_inst__DOT__c10_calc = 0U;
    vlSelf->testbench__DOT__str_inst__DOT__c05_calc = 0U;
    vlSelf->testbench__DOT__str_inst__DOT__c02_calc = 0U;
    vlSelf->testbench__DOT__str_inst__DOT__c01_calc = 0U;
    vlSelf->testbench__DOT__str_inst__DOT__qc10_next 
        = vlSelf->testbench__DOT__str_inst__DOT__qty_c10_q;
    vlSelf->testbench__DOT__str_inst__DOT__qc05_next 
        = vlSelf->testbench__DOT__str_inst__DOT__qty_c05_q;
    vlSelf->testbench__DOT__str_inst__DOT__qc02_next 
        = vlSelf->testbench__DOT__str_inst__DOT__qty_c02_q;
    vlSelf->testbench__DOT__str_inst__DOT__qc01_next 
        = vlSelf->testbench__DOT__str_inst__DOT__qty_c01_q;
    vlSelf->testbench__DOT__str_inst__DOT__greedy_inst__DOT__calc_resto = 0U;
    vlSelf->testbench__DOT__str_inst__DOT__greedy_inst__DOT__calc_qty = 0U;
    if (vlSelf->testbench__DOT__str_inst__DOT__do_erogazione) {
        vlSelf->testbench__DOT__str_inst__DOT__greedy_inst__DOT__calc_resto 
            = vlSelf->testbench__DOT__str_inst__DOT__change6;
        vlSelf->testbench__DOT__str_inst__DOT__greedy_inst__DOT__calc_qty 
            = (0x3fU & VL_DIV_III(6, (IData)(vlSelf->testbench__DOT__str_inst__DOT__greedy_inst__DOT__calc_resto), (IData)(0xaU)));
        if (((IData)(vlSelf->testbench__DOT__str_inst__DOT__greedy_inst__DOT__calc_qty) 
             > (IData)(vlSelf->testbench__DOT__str_inst__DOT__qty_c10_q))) {
            vlSelf->testbench__DOT__str_inst__DOT__greedy_inst__DOT__calc_qty 
                = vlSelf->testbench__DOT__str_inst__DOT__qty_c10_q;
        }
        vlSelf->testbench__DOT__str_inst__DOT__c10_calc 
            = vlSelf->testbench__DOT__str_inst__DOT__greedy_inst__DOT__calc_qty;
        vlSelf->testbench__DOT__str_inst__DOT__qc10_next 
            = (0x3fU & ((IData)(vlSelf->testbench__DOT__str_inst__DOT__qty_c10_q) 
                        - (IData)(vlSelf->testbench__DOT__str_inst__DOT__c10_calc)));
        vlSelf->testbench__DOT__str_inst__DOT__greedy_inst__DOT__calc_resto 
            = (0x3fU & ((IData)(vlSelf->testbench__DOT__str_inst__DOT__greedy_inst__DOT__calc_resto) 
                        - ((IData)(0xaU) * (IData)(vlSelf->testbench__DOT__str_inst__DOT__greedy_inst__DOT__calc_qty))));
        vlSelf->testbench__DOT__str_inst__DOT__greedy_inst__DOT__calc_qty 
            = (0x3fU & VL_DIV_III(6, (IData)(vlSelf->testbench__DOT__str_inst__DOT__greedy_inst__DOT__calc_resto), (IData)(5U)));
        if (((IData)(vlSelf->testbench__DOT__str_inst__DOT__greedy_inst__DOT__calc_qty) 
             > (IData)(vlSelf->testbench__DOT__str_inst__DOT__qty_c05_q))) {
            vlSelf->testbench__DOT__str_inst__DOT__greedy_inst__DOT__calc_qty 
                = vlSelf->testbench__DOT__str_inst__DOT__qty_c05_q;
        }
        vlSelf->testbench__DOT__str_inst__DOT__c05_calc 
            = vlSelf->testbench__DOT__str_inst__DOT__greedy_inst__DOT__calc_qty;
        vlSelf->testbench__DOT__str_inst__DOT__qc05_next 
            = (0x3fU & ((IData)(vlSelf->testbench__DOT__str_inst__DOT__qty_c05_q) 
                        - (IData)(vlSelf->testbench__DOT__str_inst__DOT__c05_calc)));
        vlSelf->testbench__DOT__str_inst__DOT__greedy_inst__DOT__calc_resto 
            = (0x3fU & ((IData)(vlSelf->testbench__DOT__str_inst__DOT__greedy_inst__DOT__calc_resto) 
                        - ((IData)(5U) * (IData)(vlSelf->testbench__DOT__str_inst__DOT__greedy_inst__DOT__calc_qty))));
        vlSelf->testbench__DOT__str_inst__DOT__greedy_inst__DOT__calc_qty 
            = (0x3fU & VL_SHIFTR_III(6,6,32, (IData)(vlSelf->testbench__DOT__str_inst__DOT__greedy_inst__DOT__calc_resto), 1U));
        if (((IData)(vlSelf->testbench__DOT__str_inst__DOT__greedy_inst__DOT__calc_qty) 
             > (IData)(vlSelf->testbench__DOT__str_inst__DOT__qty_c02_q))) {
            vlSelf->testbench__DOT__str_inst__DOT__greedy_inst__DOT__calc_qty 
                = vlSelf->testbench__DOT__str_inst__DOT__qty_c02_q;
        }
        vlSelf->testbench__DOT__str_inst__DOT__c02_calc 
            = vlSelf->testbench__DOT__str_inst__DOT__greedy_inst__DOT__calc_qty;
        vlSelf->testbench__DOT__str_inst__DOT__qc02_next 
            = (0x3fU & ((IData)(vlSelf->testbench__DOT__str_inst__DOT__qty_c02_q) 
                        - (IData)(vlSelf->testbench__DOT__str_inst__DOT__c02_calc)));
        vlSelf->testbench__DOT__str_inst__DOT__greedy_inst__DOT__calc_resto 
            = (0x3fU & ((IData)(vlSelf->testbench__DOT__str_inst__DOT__greedy_inst__DOT__calc_resto) 
                        - VL_SHIFTL_III(6,6,32, (IData)(vlSelf->testbench__DOT__str_inst__DOT__greedy_inst__DOT__calc_qty), 1U)));
        vlSelf->testbench__DOT__str_inst__DOT__greedy_inst__DOT__calc_qty 
            = vlSelf->testbench__DOT__str_inst__DOT__greedy_inst__DOT__calc_resto;
        if (((IData)(vlSelf->testbench__DOT__str_inst__DOT__greedy_inst__DOT__calc_qty) 
             > (IData)(vlSelf->testbench__DOT__str_inst__DOT__qty_c01_q))) {
            vlSelf->testbench__DOT__str_inst__DOT__greedy_inst__DOT__calc_qty 
                = vlSelf->testbench__DOT__str_inst__DOT__qty_c01_q;
        }
        vlSelf->testbench__DOT__str_inst__DOT__c01_calc 
            = vlSelf->testbench__DOT__str_inst__DOT__greedy_inst__DOT__calc_qty;
        vlSelf->testbench__DOT__str_inst__DOT__qc01_next 
            = (0x3fU & ((IData)(vlSelf->testbench__DOT__str_inst__DOT__qty_c01_q) 
                        - (IData)(vlSelf->testbench__DOT__str_inst__DOT__c01_calc)));
    }
    if (vlSelf->testbench__DOT__str_inst__DOT__clear_outputs) {
        vlSelf->testbench__DOT__str_inst__DOT__coin10_d = 0U;
        vlSelf->testbench__DOT__str_inst__DOT__coin05_d = 0U;
        vlSelf->testbench__DOT__str_inst__DOT__coin02_d = 0U;
        vlSelf->testbench__DOT__str_inst__DOT__coin01_d = 0U;
    } else if (vlSelf->testbench__DOT__str_inst__DOT__do_erogazione) {
        vlSelf->testbench__DOT__str_inst__DOT__coin10_d 
            = vlSelf->testbench__DOT__str_inst__DOT__c10_calc;
        vlSelf->testbench__DOT__str_inst__DOT__coin05_d 
            = vlSelf->testbench__DOT__str_inst__DOT__c05_calc;
        vlSelf->testbench__DOT__str_inst__DOT__coin02_d 
            = vlSelf->testbench__DOT__str_inst__DOT__c02_calc;
        vlSelf->testbench__DOT__str_inst__DOT__coin01_d 
            = vlSelf->testbench__DOT__str_inst__DOT__c01_calc;
    } else {
        vlSelf->testbench__DOT__str_inst__DOT__coin10_d 
            = vlSelf->testbench__DOT__str_inst__DOT__coin10_q;
        vlSelf->testbench__DOT__str_inst__DOT__coin05_d 
            = vlSelf->testbench__DOT__str_inst__DOT__coin05_q;
        vlSelf->testbench__DOT__str_inst__DOT__coin02_d 
            = vlSelf->testbench__DOT__str_inst__DOT__coin02_q;
        vlSelf->testbench__DOT__str_inst__DOT__coin01_d 
            = vlSelf->testbench__DOT__str_inst__DOT__coin01_q;
    }
}

VL_INLINE_OPT void Vtestbench___024root___nba_comb__TOP__2(Vtestbench___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtestbench__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtestbench___024root___nba_comb__TOP__2\n"); );
    // Body
    vlSelf->testbench__DOT__str_inst__DOT__do_cancel = 0U;
    vlSelf->testbench__DOT__str_inst__DOT__credito_insuff 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__credito_q) 
           < (IData)(vlSelf->testbench__DOT__str_inst__DOT__sel_price));
    vlSelf->testbench__DOT__str_inst__DOT__is_credito_suff 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__credito_q) 
           >= (IData)(vlSelf->testbench__DOT__str_inst__DOT__sel_price));
    vlSelf->testbench__DOT__str_inst__DOT__qty_c10_d 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_c10)
            ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_data)
            : ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_erogazione)
                ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__qc10_next)
                : (IData)(vlSelf->testbench__DOT__str_inst__DOT__qty_c10_q)));
    vlSelf->testbench__DOT__str_inst__DOT__qty_c05_d 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_c05)
            ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_data)
            : ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_erogazione)
                ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__qc05_next)
                : (IData)(vlSelf->testbench__DOT__str_inst__DOT__qty_c05_q)));
    vlSelf->testbench__DOT__str_inst__DOT__qty_c02_d 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_c02)
            ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_data)
            : ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_erogazione)
                ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__qc02_next)
                : (IData)(vlSelf->testbench__DOT__str_inst__DOT__qty_c02_q)));
    vlSelf->testbench__DOT__str_inst__DOT__qty_c01_d 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_c01)
            ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_data)
            : ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_erogazione)
                ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__qc01_next)
                : (IData)(vlSelf->testbench__DOT__str_inst__DOT__qty_c01_q)));
    if ((2U & (IData)(vlSelf->testbench__DOT__str_inst__DOT__CTRL__DOT__stato))) {
        if ((1U & (~ (IData)(vlSelf->testbench__DOT__str_inst__DOT__CTRL__DOT__stato)))) {
            if ((0U == (IData)(vlSelf->testbench__DOT__coin))) {
                if (vlSelf->testbench__DOT__annulla) {
                    vlSelf->testbench__DOT__str_inst__DOT__do_cancel = 1U;
                }
            }
        }
    }
    vlSelf->testbench__DOT__str_inst__DOT__disponibile_d 
        = (0x3ffU & ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_cancel)
                      ? ((IData)(vlSelf->testbench__DOT__str_inst__DOT__disponibile_q) 
                         - (IData)(vlSelf->testbench__DOT__str_inst__DOT__credito_q))
                      : ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_erogazione)
                          ? ((IData)(vlSelf->testbench__DOT__str_inst__DOT__disponibile_q) 
                             - (IData)(vlSelf->testbench__DOT__str_inst__DOT__change6))
                          : ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_add_coin)
                              ? ((IData)(vlSelf->testbench__DOT__str_inst__DOT__disponibile_q) 
                                 + (IData)(vlSelf->testbench__DOT__str_inst__DOT__coin_value))
                              : (IData)(vlSelf->testbench__DOT__str_inst__DOT__disponibile_q)))));
    vlSelf->testbench__DOT__str_inst__DOT____VdfgTmp_hf3f60487__0 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_cancel) 
           | (IData)(vlSelf->testbench__DOT__str_inst__DOT__do_erogazione));
    vlSelf->testbench__DOT__str_inst__DOT__c_prod4 = 0U;
    vlSelf->testbench__DOT__str_inst__DOT__c_prod3 = 0U;
    vlSelf->testbench__DOT__str_inst__DOT__c_prod2 = 0U;
    vlSelf->testbench__DOT__str_inst__DOT__c_prod1 = 0U;
    vlSelf->testbench__DOT__str_inst__DOT__do_err = 0U;
    vlSelf->testbench__DOT__str_inst__DOT__do_ok = 0U;
    if ((2U & (IData)(vlSelf->testbench__DOT__str_inst__DOT__CTRL__DOT__stato))) {
        vlSelf->testbench__DOT__str_inst__DOT__CTRL__DOT__next_stato 
            = ((1U & (IData)(vlSelf->testbench__DOT__str_inst__DOT__CTRL__DOT__stato))
                ? 1U : ((0U != (IData)(vlSelf->testbench__DOT__coin))
                         ? 2U : ((IData)(vlSelf->testbench__DOT__annulla)
                                  ? 1U : ((IData)(vlSelf->testbench__DOT__conferma)
                                           ? (((IData)(vlSelf->testbench__DOT__str_inst__DOT__is_credito_suff) 
                                               & (0U 
                                                  != (IData)(vlSelf->testbench__DOT__str_inst__DOT__sel_qty)))
                                               ? 3U
                                               : 1U)
                                           : 2U))));
        if ((1U & (~ (IData)(vlSelf->testbench__DOT__str_inst__DOT__CTRL__DOT__stato)))) {
            if ((0U == (IData)(vlSelf->testbench__DOT__coin))) {
                if ((1U & (~ (IData)(vlSelf->testbench__DOT__annulla)))) {
                    if (vlSelf->testbench__DOT__conferma) {
                        if (((IData)(vlSelf->testbench__DOT__str_inst__DOT__is_credito_suff) 
                             & (0U != (IData)(vlSelf->testbench__DOT__str_inst__DOT__sel_qty)))) {
                            if ((4U & (IData)(vlSelf->testbench__DOT__selezione))) {
                                if ((2U & (IData)(vlSelf->testbench__DOT__selezione))) {
                                    if ((1U & (IData)(vlSelf->testbench__DOT__selezione))) {
                                        vlSelf->testbench__DOT__str_inst__DOT__c_prod4 = 1U;
                                    }
                                    if ((1U & (~ (IData)(vlSelf->testbench__DOT__selezione)))) {
                                        vlSelf->testbench__DOT__str_inst__DOT__c_prod3 = 1U;
                                    }
                                }
                                if ((1U & (~ ((IData)(vlSelf->testbench__DOT__selezione) 
                                              >> 1U)))) {
                                    if ((1U & (IData)(vlSelf->testbench__DOT__selezione))) {
                                        vlSelf->testbench__DOT__str_inst__DOT__c_prod2 = 1U;
                                    }
                                    if ((1U & (~ (IData)(vlSelf->testbench__DOT__selezione)))) {
                                        vlSelf->testbench__DOT__str_inst__DOT__c_prod1 = 1U;
                                    }
                                }
                            }
                            vlSelf->testbench__DOT__str_inst__DOT__do_ok = 1U;
                        }
                        if ((1U & (~ ((IData)(vlSelf->testbench__DOT__str_inst__DOT__is_credito_suff) 
                                      & (0U != (IData)(vlSelf->testbench__DOT__str_inst__DOT__sel_qty)))))) {
                            vlSelf->testbench__DOT__str_inst__DOT__do_err = 1U;
                        }
                    }
                }
            }
        }
    } else {
        vlSelf->testbench__DOT__str_inst__DOT__CTRL__DOT__next_stato 
            = ((1U & (IData)(vlSelf->testbench__DOT__str_inst__DOT__CTRL__DOT__stato))
                ? ((0U != (IData)(vlSelf->testbench__DOT__coin))
                    ? 2U : 1U) : ((0xbU == (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_counter_w))
                                   ? 1U : 0U));
    }
    vlSelf->testbench__DOT__str_inst__DOT__we_credito 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_add_coin) 
           | (IData)(vlSelf->testbench__DOT__str_inst__DOT____VdfgTmp_hf3f60487__0));
    vlSelf->testbench__DOT__str_inst__DOT__credito_d 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT____VdfgTmp_hf3f60487__0)
            ? 0U : (0x3fU & ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_add_coin)
                              ? ((IData)(vlSelf->testbench__DOT__str_inst__DOT__coin_value) 
                                 + (IData)(vlSelf->testbench__DOT__str_inst__DOT__credito_q))
                              : (IData)(vlSelf->testbench__DOT__str_inst__DOT__credito_q))));
    if (vlSelf->testbench__DOT__str_inst__DOT__clear_outputs) {
        vlSelf->testbench__DOT__str_inst__DOT__errore_d = 0U;
        vlSelf->testbench__DOT__str_inst__DOT__resto_d = 0U;
    } else {
        vlSelf->testbench__DOT__str_inst__DOT__errore_d 
            = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_err)
                ? (((0U == (IData)(vlSelf->testbench__DOT__str_inst__DOT__sel_qty)) 
                    << 1U) | (IData)(vlSelf->testbench__DOT__str_inst__DOT__credito_insuff))
                : (IData)(vlSelf->testbench__DOT__str_inst__DOT__errore_q));
        vlSelf->testbench__DOT__str_inst__DOT__resto_d 
            = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_erogazione)
                ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__change6)
                : ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_cancel)
                    ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__credito_q)
                    : (((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_err) 
                        & (IData)(vlSelf->testbench__DOT__str_inst__DOT__credito_insuff))
                        ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__sel_price)
                        : (IData)(vlSelf->testbench__DOT__str_inst__DOT__resto_q))));
    }
    vlSelf->testbench__DOT__str_inst__DOT__we_prod 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__clear_outputs) 
           | (IData)(vlSelf->testbench__DOT__str_inst__DOT__do_ok));
    vlSelf->testbench__DOT__str_inst__DOT__current_price_d 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_ok)
            ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__sel_price)
            : (IData)(vlSelf->testbench__DOT__str_inst__DOT__current_price_q));
    vlSelf->testbench__DOT__str_inst__DOT__prod1_d 
        = ((~ (IData)(vlSelf->testbench__DOT__str_inst__DOT__clear_outputs)) 
           & ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_ok)
               ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__c_prod1)
               : (IData)(vlSelf->testbench__DOT__str_inst__DOT__prod1_q)));
    vlSelf->testbench__DOT__str_inst__DOT__prod2_d 
        = ((~ (IData)(vlSelf->testbench__DOT__str_inst__DOT__clear_outputs)) 
           & ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_ok)
               ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__c_prod2)
               : (IData)(vlSelf->testbench__DOT__str_inst__DOT__prod2_q)));
    vlSelf->testbench__DOT__str_inst__DOT__prod3_d 
        = ((~ (IData)(vlSelf->testbench__DOT__str_inst__DOT__clear_outputs)) 
           & ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_ok)
               ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__c_prod3)
               : (IData)(vlSelf->testbench__DOT__str_inst__DOT__prod3_q)));
    vlSelf->testbench__DOT__str_inst__DOT__prod4_d 
        = ((~ (IData)(vlSelf->testbench__DOT__str_inst__DOT__clear_outputs)) 
           & ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_ok)
               ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__c_prod4)
               : (IData)(vlSelf->testbench__DOT__str_inst__DOT__prod4_q)));
    vlSelf->testbench__DOT__str_inst__DOT__do_dec_p1 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_ok) 
           & (4U == (IData)(vlSelf->testbench__DOT__selezione)));
    vlSelf->testbench__DOT__str_inst__DOT__do_dec_p2 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_ok) 
           & (5U == (IData)(vlSelf->testbench__DOT__selezione)));
    vlSelf->testbench__DOT__str_inst__DOT__do_dec_p3 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_ok) 
           & (6U == (IData)(vlSelf->testbench__DOT__selezione)));
    vlSelf->testbench__DOT__str_inst__DOT__do_dec_p4 
        = ((IData)(vlSelf->testbench__DOT__str_inst__DOT__do_ok) 
           & (7U == (IData)(vlSelf->testbench__DOT__selezione)));
    vlSelf->testbench__DOT__str_inst__DOT__qty_p1_d 
        = (0x3fU & ((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_qty_p1)
                     ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_data)
                     : ((IData)(vlSelf->testbench__DOT__str_inst__DOT__qty_p1_q) 
                        - (IData)(vlSelf->testbench__DOT__str_inst__DOT__do_dec_p1))));
    vlSelf->testbench__DOT__str_inst__DOT__qty_p2_d 
        = (0x3fU & ((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_qty_p2)
                     ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_data)
                     : ((IData)(vlSelf->testbench__DOT__str_inst__DOT__qty_p2_q) 
                        - (IData)(vlSelf->testbench__DOT__str_inst__DOT__do_dec_p2))));
    vlSelf->testbench__DOT__str_inst__DOT__qty_p3_d 
        = (0x3fU & ((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_qty_p3)
                     ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_data)
                     : ((IData)(vlSelf->testbench__DOT__str_inst__DOT__qty_p3_q) 
                        - (IData)(vlSelf->testbench__DOT__str_inst__DOT__do_dec_p3))));
    vlSelf->testbench__DOT__str_inst__DOT__qty_p4_d 
        = (0x3fU & ((IData)(vlSelf->testbench__DOT__str_inst__DOT__init_qty_p4)
                     ? (IData)(vlSelf->testbench__DOT__str_inst__DOT__init_data)
                     : ((IData)(vlSelf->testbench__DOT__str_inst__DOT__qty_p4_q) 
                        - (IData)(vlSelf->testbench__DOT__str_inst__DOT__do_dec_p4))));
}

void Vtestbench___024root___nba_sequent__TOP__2(Vtestbench___024root* vlSelf);

void Vtestbench___024root___eval_nba(Vtestbench___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtestbench__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtestbench___024root___eval_nba\n"); );
    // Body
    if ((1ULL & vlSelf->__VnbaTriggered.word(0U))) {
        Vtestbench___024root___nba_sequent__TOP__0(vlSelf);
    }
    if ((4ULL & vlSelf->__VnbaTriggered.word(0U))) {
        Vtestbench___024root___nba_sequent__TOP__1(vlSelf);
        vlSelf->__Vm_traceActivity[4U] = 1U;
    }
    if ((0xaULL & vlSelf->__VnbaTriggered.word(0U))) {
        Vtestbench___024root___nba_comb__TOP__0(vlSelf);
    }
    if ((2ULL & vlSelf->__VnbaTriggered.word(0U))) {
        Vtestbench___024root___nba_sequent__TOP__2(vlSelf);
    }
    if ((0xeULL & vlSelf->__VnbaTriggered.word(0U))) {
        Vtestbench___024root___nba_comb__TOP__1(vlSelf);
    }
    if ((4ULL & vlSelf->__VnbaTriggered.word(0U))) {
        Vtestbench___024root___nba_sequent__TOP__3(vlSelf);
        vlSelf->__Vm_traceActivity[5U] = 1U;
    }
    if ((0xeULL & vlSelf->__VnbaTriggered.word(0U))) {
        Vtestbench___024root___nba_comb__TOP__2(vlSelf);
        vlSelf->__Vm_traceActivity[6U] = 1U;
    }
}

void Vtestbench___024root___timing_resume(Vtestbench___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtestbench__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtestbench___024root___timing_resume\n"); );
    // Body
    if ((2ULL & vlSelf->__VactTriggered.word(0U))) {
        vlSelf->__VtrigSched_hf8270716__0.resume("@(negedge testbench.clk)");
    }
    if ((8ULL & vlSelf->__VactTriggered.word(0U))) {
        vlSelf->__VdlySched.resume();
    }
}

void Vtestbench___024root___timing_commit(Vtestbench___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtestbench__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtestbench___024root___timing_commit\n"); );
    // Body
    if ((! (2ULL & vlSelf->__VactTriggered.word(0U)))) {
        vlSelf->__VtrigSched_hf8270716__0.commit("@(negedge testbench.clk)");
    }
}

void Vtestbench___024root___eval_triggers__act(Vtestbench___024root* vlSelf);

bool Vtestbench___024root___eval_phase__act(Vtestbench___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtestbench__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtestbench___024root___eval_phase__act\n"); );
    // Init
    VlTriggerVec<4> __VpreTriggered;
    CData/*0:0*/ __VactExecute;
    // Body
    Vtestbench___024root___eval_triggers__act(vlSelf);
    Vtestbench___024root___timing_commit(vlSelf);
    __VactExecute = vlSelf->__VactTriggered.any();
    if (__VactExecute) {
        __VpreTriggered.andNot(vlSelf->__VactTriggered, vlSelf->__VnbaTriggered);
        vlSelf->__VnbaTriggered.thisOr(vlSelf->__VactTriggered);
        Vtestbench___024root___timing_resume(vlSelf);
        Vtestbench___024root___eval_act(vlSelf);
    }
    return (__VactExecute);
}

bool Vtestbench___024root___eval_phase__nba(Vtestbench___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtestbench__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtestbench___024root___eval_phase__nba\n"); );
    // Init
    CData/*0:0*/ __VnbaExecute;
    // Body
    __VnbaExecute = vlSelf->__VnbaTriggered.any();
    if (__VnbaExecute) {
        Vtestbench___024root___eval_nba(vlSelf);
        vlSelf->__VnbaTriggered.clear();
    }
    return (__VnbaExecute);
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vtestbench___024root___dump_triggers__nba(Vtestbench___024root* vlSelf);
#endif  // VL_DEBUG
#ifdef VL_DEBUG
VL_ATTR_COLD void Vtestbench___024root___dump_triggers__act(Vtestbench___024root* vlSelf);
#endif  // VL_DEBUG

void Vtestbench___024root___eval(Vtestbench___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtestbench__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtestbench___024root___eval\n"); );
    // Init
    IData/*31:0*/ __VnbaIterCount;
    CData/*0:0*/ __VnbaContinue;
    // Body
    __VnbaIterCount = 0U;
    __VnbaContinue = 1U;
    while (__VnbaContinue) {
        if (VL_UNLIKELY((0x64U < __VnbaIterCount))) {
#ifdef VL_DEBUG
            Vtestbench___024root___dump_triggers__nba(vlSelf);
#endif
            VL_FATAL_MT("testbench.v", 3, "", "NBA region did not converge.");
        }
        __VnbaIterCount = ((IData)(1U) + __VnbaIterCount);
        __VnbaContinue = 0U;
        vlSelf->__VactIterCount = 0U;
        vlSelf->__VactContinue = 1U;
        while (vlSelf->__VactContinue) {
            if (VL_UNLIKELY((0x64U < vlSelf->__VactIterCount))) {
#ifdef VL_DEBUG
                Vtestbench___024root___dump_triggers__act(vlSelf);
#endif
                VL_FATAL_MT("testbench.v", 3, "", "Active region did not converge.");
            }
            vlSelf->__VactIterCount = ((IData)(1U) 
                                       + vlSelf->__VactIterCount);
            vlSelf->__VactContinue = 0U;
            if (Vtestbench___024root___eval_phase__act(vlSelf)) {
                vlSelf->__VactContinue = 1U;
            }
        }
        if (Vtestbench___024root___eval_phase__nba(vlSelf)) {
            __VnbaContinue = 1U;
        }
    }
}

#ifdef VL_DEBUG
void Vtestbench___024root___eval_debug_assertions(Vtestbench___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtestbench__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtestbench___024root___eval_debug_assertions\n"); );
}
#endif  // VL_DEBUG
