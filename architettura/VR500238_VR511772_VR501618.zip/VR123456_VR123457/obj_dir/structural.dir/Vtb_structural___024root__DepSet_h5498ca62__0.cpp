// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vtb_structural.h for the primary calling header

#include "Vtb_structural__pch.h"
#include "Vtb_structural__Syms.h"
#include "Vtb_structural___024root.h"

VL_INLINE_OPT VlCoroutine Vtb_structural___024root___eval_initial__TOP__Vtiming__0(Vtb_structural___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtb_structural__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_structural___024root___eval_initial__TOP__Vtiming__0\n"); );
    // Init
    VlWide<7>/*223:0*/ __Vtemp_1;
    // Body
    __Vtemp_1[0U] = 0x2e766364U;
    __Vtemp_1[1U] = 0x7572616cU;
    __Vtemp_1[2U] = 0x72756374U;
    __Vtemp_1[3U] = 0x655f7374U;
    __Vtemp_1[4U] = 0x7a696f6eU;
    __Vtemp_1[5U] = 0x6d756c61U;
    __Vtemp_1[6U] = 0x7369U;
    vlSymsp->_vm_contextp__->dumpfile(VL_CVT_PACK_STR_NW(7, __Vtemp_1));
    vlSymsp->_traceDumpOpen();
    vlSelf->tb_structural__DOT__clk = 0U;
    vlSelf->tb_structural__DOT__rst = 0U;
    vlSelf->tb_structural__DOT__coin = 0U;
    vlSelf->tb_structural__DOT__selezione = 0U;
    vlSelf->tb_structural__DOT__conferma = 0U;
    vlSelf->tb_structural__DOT__annulla = 0U;
    co_await vlSelf->__VdlySched.delay(0x4e20ULL, nullptr, 
                                       "structural/tb_structural.v", 
                                       68);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_structural__DOT__rst = 1U;
    co_await vlSelf->__VtrigSched_hd70e940e__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_structural.clk)", 
                                                       "structural/tb_structural.v", 
                                                       163);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_structural__DOT__coin = 0U;
    vlSelf->tb_structural__DOT__selezione = 5U;
    co_await vlSelf->__VtrigSched_hd70e940e__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_structural.clk)", 
                                                       "structural/tb_structural.v", 
                                                       163);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_structural__DOT__coin = 0U;
    vlSelf->tb_structural__DOT__selezione = 3U;
    co_await vlSelf->__VtrigSched_hd70e940e__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_structural.clk)", 
                                                       "structural/tb_structural.v", 
                                                       163);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_structural__DOT__coin = 0U;
    vlSelf->tb_structural__DOT__selezione = 5U;
    co_await vlSelf->__VtrigSched_hd70e940e__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_structural.clk)", 
                                                       "structural/tb_structural.v", 
                                                       163);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_structural__DOT__coin = 0U;
    vlSelf->tb_structural__DOT__selezione = 5U;
    co_await vlSelf->__VtrigSched_hd70e940e__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_structural.clk)", 
                                                       "structural/tb_structural.v", 
                                                       163);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_structural__DOT__coin = 0U;
    vlSelf->tb_structural__DOT__selezione = 5U;
    co_await vlSelf->__VtrigSched_hd70e940e__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_structural.clk)", 
                                                       "structural/tb_structural.v", 
                                                       163);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_structural__DOT__coin = 1U;
    vlSelf->tb_structural__DOT__selezione = 0U;
    co_await vlSelf->__VtrigSched_hd70e940e__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_structural.clk)", 
                                                       "structural/tb_structural.v", 
                                                       163);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_structural__DOT__coin = 0U;
    vlSelf->tb_structural__DOT__selezione = 2U;
    co_await vlSelf->__VtrigSched_hd70e940e__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_structural.clk)", 
                                                       "structural/tb_structural.v", 
                                                       163);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_structural__DOT__coin = 1U;
    vlSelf->tb_structural__DOT__selezione = 4U;
    co_await vlSelf->__VtrigSched_hd70e940e__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_structural.clk)", 
                                                       "structural/tb_structural.v", 
                                                       163);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_structural__DOT__coin = 1U;
    vlSelf->tb_structural__DOT__selezione = 2U;
    co_await vlSelf->__VtrigSched_hd70e940e__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_structural.clk)", 
                                                       "structural/tb_structural.v", 
                                                       163);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_structural__DOT__coin = 1U;
    vlSelf->tb_structural__DOT__selezione = 2U;
    co_await vlSelf->__VtrigSched_hd70e940e__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_structural.clk)", 
                                                       "structural/tb_structural.v", 
                                                       163);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_structural__DOT__coin = 1U;
    vlSelf->tb_structural__DOT__selezione = 2U;
    co_await vlSelf->__VtrigSched_hd70e940e__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_structural.clk)", 
                                                       "structural/tb_structural.v", 
                                                       163);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_structural__DOT__coin = 0U;
    vlSelf->tb_structural__DOT__selezione = 2U;
    co_await vlSelf->__VtrigSched_hd70e940e__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_structural.clk)", 
                                                       "structural/tb_structural.v", 
                                                       163);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_structural__DOT__coin = 0U;
    vlSelf->tb_structural__DOT__selezione = 0U;
    VL_WRITEF("--- CONFIGURAZIONE TERMINATA (STRUCTURAL) ---\n");
    co_await vlSelf->__VdlySched.delay(0x4e20ULL, nullptr, 
                                       "structural/tb_structural.v", 
                                       105);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    co_await vlSelf->__VtrigSched_hd70e940e__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_structural.clk)", 
                                                       "structural/tb_structural.v", 
                                                       163);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_structural__DOT__coin = 6U;
    co_await vlSelf->__VtrigSched_hd70e940e__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_structural.clk)", 
                                                       "structural/tb_structural.v", 
                                                       163);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_structural__DOT__coin = 0U;
    co_await vlSelf->__VdlySched.delay(0x2710ULL, nullptr, 
                                       "structural/tb_structural.v", 
                                       109);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    co_await vlSelf->__VtrigSched_hd70e940e__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_structural.clk)", 
                                                       "structural/tb_structural.v", 
                                                       163);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_structural__DOT__selezione = 5U;
    vlSelf->tb_structural__DOT__conferma = 1U;
    co_await vlSelf->__VtrigSched_hd70e940e__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_structural.clk)", 
                                                       "structural/tb_structural.v", 
                                                       163);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_structural__DOT__conferma = 0U;
    vlSelf->tb_structural__DOT__selezione = 0U;
    VL_WRITEF("Test 1: Acquisto P2. Atteso: Prod2=1\n");
    co_await vlSelf->__VdlySched.delay(0xc350ULL, nullptr, 
                                       "structural/tb_structural.v", 
                                       117);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    co_await vlSelf->__VtrigSched_hd70e940e__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_structural.clk)", 
                                                       "structural/tb_structural.v", 
                                                       163);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_structural__DOT__coin = 7U;
    co_await vlSelf->__VtrigSched_hd70e940e__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_structural.clk)", 
                                                       "structural/tb_structural.v", 
                                                       163);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_structural__DOT__coin = 0U;
    co_await vlSelf->__VtrigSched_hd70e940e__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_structural.clk)", 
                                                       "structural/tb_structural.v", 
                                                       163);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_structural__DOT__selezione = 4U;
    vlSelf->tb_structural__DOT__conferma = 1U;
    co_await vlSelf->__VtrigSched_hd70e940e__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_structural.clk)", 
                                                       "structural/tb_structural.v", 
                                                       163);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_structural__DOT__conferma = 0U;
    vlSelf->tb_structural__DOT__selezione = 0U;
    VL_WRITEF("Test 2: Acquisto P1 (0.3\342\202\254) con 1.0\342\202\254. Atteso: Resto=0.7\n");
    co_await vlSelf->__VdlySched.delay(0x186a0ULL, 
                                       nullptr, "structural/tb_structural.v", 
                                       132);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    co_await vlSelf->__VtrigSched_hd70e940e__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_structural.clk)", 
                                                       "structural/tb_structural.v", 
                                                       163);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_structural__DOT__coin = 4U;
    co_await vlSelf->__VtrigSched_hd70e940e__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_structural.clk)", 
                                                       "structural/tb_structural.v", 
                                                       163);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_structural__DOT__coin = 0U;
    co_await vlSelf->__VtrigSched_hd70e940e__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_structural.clk)", 
                                                       "structural/tb_structural.v", 
                                                       163);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_structural__DOT__selezione = 7U;
    vlSelf->tb_structural__DOT__conferma = 1U;
    co_await vlSelf->__VtrigSched_hd70e940e__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_structural.clk)", 
                                                       "structural/tb_structural.v", 
                                                       163);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_structural__DOT__conferma = 0U;
    vlSelf->tb_structural__DOT__selezione = 0U;
    VL_WRITEF("Test 3: Credito insufficiente. Atteso: Errore=01\n");
    co_await vlSelf->__VdlySched.delay(0x9c40ULL, nullptr, 
                                       "structural/tb_structural.v", 
                                       144);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    co_await vlSelf->__VtrigSched_hd70e940e__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_structural.clk)", 
                                                       "structural/tb_structural.v", 
                                                       163);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_structural__DOT__coin = 6U;
    co_await vlSelf->__VtrigSched_hd70e940e__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_structural.clk)", 
                                                       "structural/tb_structural.v", 
                                                       163);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_structural__DOT__coin = 0U;
    co_await vlSelf->__VtrigSched_hd70e940e__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_structural.clk)", 
                                                       "structural/tb_structural.v", 
                                                       163);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_structural__DOT__annulla = 1U;
    co_await vlSelf->__VtrigSched_hd70e940e__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge tb_structural.clk)", 
                                                       "structural/tb_structural.v", 
                                                       163);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    vlSelf->tb_structural__DOT__annulla = 0U;
    VL_WRITEF("Test 4: Annulla. Atteso: Restituzione totale\n");
    co_await vlSelf->__VdlySched.delay(0x186a0ULL, 
                                       nullptr, "structural/tb_structural.v", 
                                       156);
    vlSelf->__Vm_traceActivity[2U] = 1U;
    VL_FINISH_MT("structural/tb_structural.v", 158, "");
    vlSelf->__Vm_traceActivity[2U] = 1U;
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vtb_structural___024root___dump_triggers__act(Vtb_structural___024root* vlSelf);
#endif  // VL_DEBUG

void Vtb_structural___024root___eval_triggers__act(Vtb_structural___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtb_structural__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_structural___024root___eval_triggers__act\n"); );
    // Body
    vlSelf->__VactTriggered.set(0U, (((IData)(vlSelf->tb_structural__DOT__clk) 
                                      & (~ (IData)(vlSelf->__Vtrigprevexpr___TOP__tb_structural__DOT__clk__0))) 
                                     | ((~ (IData)(vlSelf->tb_structural__DOT__rst)) 
                                        & (IData)(vlSelf->__Vtrigprevexpr___TOP__tb_structural__DOT__rst__0))));
    vlSelf->__VactTriggered.set(1U, vlSelf->__VdlySched.awaitingCurrentTime());
    vlSelf->__VactTriggered.set(2U, ((~ (IData)(vlSelf->tb_structural__DOT__clk)) 
                                     & (IData)(vlSelf->__Vtrigprevexpr___TOP__tb_structural__DOT__clk__0)));
    vlSelf->__Vtrigprevexpr___TOP__tb_structural__DOT__clk__0 
        = vlSelf->tb_structural__DOT__clk;
    vlSelf->__Vtrigprevexpr___TOP__tb_structural__DOT__rst__0 
        = vlSelf->tb_structural__DOT__rst;
#ifdef VL_DEBUG
    if (VL_UNLIKELY(vlSymsp->_vm_contextp__->debug())) {
        Vtb_structural___024root___dump_triggers__act(vlSelf);
    }
#endif
}
