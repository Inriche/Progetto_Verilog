// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Tracing declarations
#include "verilated_vcd_c.h"


void Vtb_structural___024root__traceDeclTypesSub0(VerilatedVcd* tracep) {
}

void Vtb_structural___024root__trace_decl_types(VerilatedVcd* tracep) {
    Vtb_structural___024root__traceDeclTypesSub0(tracep);
}
