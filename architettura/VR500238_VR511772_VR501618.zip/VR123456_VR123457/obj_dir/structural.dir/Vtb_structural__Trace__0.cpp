// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Tracing implementation internals
#include "verilated_vcd_c.h"
#include "Vtb_structural__Syms.h"


void Vtb_structural___024root__trace_chg_0_sub_0(Vtb_structural___024root* vlSelf, VerilatedVcd::Buffer* bufp);

void Vtb_structural___024root__trace_chg_0(void* voidSelf, VerilatedVcd::Buffer* bufp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_structural___024root__trace_chg_0\n"); );
    // Init
    Vtb_structural___024root* const __restrict vlSelf VL_ATTR_UNUSED = static_cast<Vtb_structural___024root*>(voidSelf);
    Vtb_structural__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    if (VL_UNLIKELY(!vlSymsp->__Vm_activity)) return;
    // Body
    Vtb_structural___024root__trace_chg_0_sub_0((&vlSymsp->TOP), bufp);
}

void Vtb_structural___024root__trace_chg_0_sub_0(Vtb_structural___024root* vlSelf, VerilatedVcd::Buffer* bufp) {
    if (false && vlSelf) {}  // Prevent unused
    Vtb_structural__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_structural___024root__trace_chg_0_sub_0\n"); );
    // Init
    uint32_t* const oldp VL_ATTR_UNUSED = bufp->oldp(vlSymsp->__Vm_baseCode + 1);
    // Body
    if (VL_UNLIKELY((vlSelf->__Vm_traceActivity[1U] 
                     | vlSelf->__Vm_traceActivity[2U]))) {
        bufp->chgBit(oldp+0,(vlSelf->tb_structural__DOT__rst));
        bufp->chgCData(oldp+1,(vlSelf->tb_structural__DOT__coin),3);
        bufp->chgCData(oldp+2,(vlSelf->tb_structural__DOT__selezione),3);
        bufp->chgBit(oldp+3,(vlSelf->tb_structural__DOT__conferma));
        bufp->chgBit(oldp+4,(vlSelf->tb_structural__DOT__annulla));
        bufp->chgCData(oldp+5,((3U & (IData)(vlSelf->tb_structural__DOT__selezione))),2);
        bufp->chgBit(oldp+6,((4U == (IData)(vlSelf->tb_structural__DOT__selezione))));
        bufp->chgBit(oldp+7,((5U == (IData)(vlSelf->tb_structural__DOT__selezione))));
        bufp->chgBit(oldp+8,((6U == (IData)(vlSelf->tb_structural__DOT__selezione))));
        bufp->chgBit(oldp+9,((7U == (IData)(vlSelf->tb_structural__DOT__selezione))));
    }
    if (VL_UNLIKELY(((vlSelf->__Vm_traceActivity[3U] 
                      | vlSelf->__Vm_traceActivity[4U]) 
                     | vlSelf->__Vm_traceActivity[5U]))) {
        bufp->chgCData(oldp+10,((0x3fU & ((IData)(vlSelf->tb_structural__DOT__dut__DOT__coin_value) 
                                          + (IData)(vlSelf->tb_structural__DOT__dut__DOT__credito_q)))),6);
        bufp->chgSData(oldp+11,((0x3ffU & ((IData)(vlSelf->tb_structural__DOT__dut__DOT__disponibile_q) 
                                           + (IData)(vlSelf->tb_structural__DOT__dut__DOT__coin_value)))),10);
        bufp->chgCData(oldp+12,(((IData)(vlSelf->tb_structural__DOT__dut__DOT__init_price_p1)
                                  ? (IData)(vlSelf->tb_structural__DOT__dut__DOT__init_data)
                                  : (IData)(vlSelf->tb_structural__DOT__dut__DOT__price_p1_q))),6);
        bufp->chgCData(oldp+13,(((IData)(vlSelf->tb_structural__DOT__dut__DOT__init_price_p2)
                                  ? (IData)(vlSelf->tb_structural__DOT__dut__DOT__init_data)
                                  : (IData)(vlSelf->tb_structural__DOT__dut__DOT__price_p2_q))),6);
        bufp->chgCData(oldp+14,(((IData)(vlSelf->tb_structural__DOT__dut__DOT__init_price_p3)
                                  ? (IData)(vlSelf->tb_structural__DOT__dut__DOT__init_data)
                                  : (IData)(vlSelf->tb_structural__DOT__dut__DOT__price_p3_q))),6);
        bufp->chgCData(oldp+15,(((IData)(vlSelf->tb_structural__DOT__dut__DOT__init_price_p4)
                                  ? (IData)(vlSelf->tb_structural__DOT__dut__DOT__init_data)
                                  : (IData)(vlSelf->tb_structural__DOT__dut__DOT__price_p4_q))),6);
        bufp->chgCData(oldp+16,(((IData)(vlSelf->tb_structural__DOT__dut__DOT__init_c01)
                                  ? (IData)(vlSelf->tb_structural__DOT__dut__DOT__init_data)
                                  : ((IData)(vlSelf->tb_structural__DOT__dut__DOT__do_erogazione)
                                      ? (IData)(vlSelf->tb_structural__DOT__dut__DOT__qc01_next)
                                      : (IData)(vlSelf->tb_structural__DOT__dut__DOT__qty_c01_q)))),6);
        bufp->chgCData(oldp+17,(((IData)(vlSelf->tb_structural__DOT__dut__DOT__init_c02)
                                  ? (IData)(vlSelf->tb_structural__DOT__dut__DOT__init_data)
                                  : ((IData)(vlSelf->tb_structural__DOT__dut__DOT__do_erogazione)
                                      ? (IData)(vlSelf->tb_structural__DOT__dut__DOT__qc02_next)
                                      : (IData)(vlSelf->tb_structural__DOT__dut__DOT__qty_c02_q)))),6);
        bufp->chgCData(oldp+18,(((IData)(vlSelf->tb_structural__DOT__dut__DOT__init_c05)
                                  ? (IData)(vlSelf->tb_structural__DOT__dut__DOT__init_data)
                                  : ((IData)(vlSelf->tb_structural__DOT__dut__DOT__do_erogazione)
                                      ? (IData)(vlSelf->tb_structural__DOT__dut__DOT__qc05_next)
                                      : (IData)(vlSelf->tb_structural__DOT__dut__DOT__qty_c05_q)))),6);
        bufp->chgCData(oldp+19,(((IData)(vlSelf->tb_structural__DOT__dut__DOT__init_c10)
                                  ? (IData)(vlSelf->tb_structural__DOT__dut__DOT__init_data)
                                  : ((IData)(vlSelf->tb_structural__DOT__dut__DOT__do_erogazione)
                                      ? (IData)(vlSelf->tb_structural__DOT__dut__DOT__qc10_next)
                                      : (IData)(vlSelf->tb_structural__DOT__dut__DOT__qty_c10_q)))),6);
    }
    if (VL_UNLIKELY(((vlSelf->__Vm_traceActivity[3U] 
                      | vlSelf->__Vm_traceActivity[4U]) 
                     | vlSelf->__Vm_traceActivity[6U]))) {
        bufp->chgBit(oldp+20,(((IData)(vlSelf->tb_structural__DOT__dut__DOT__init_qty_p1) 
                               | (IData)(vlSelf->tb_structural__DOT__dut__DOT__do_dec_p1))));
        bufp->chgBit(oldp+21,(((IData)(vlSelf->tb_structural__DOT__dut__DOT__init_qty_p2) 
                               | (IData)(vlSelf->tb_structural__DOT__dut__DOT__do_dec_p2))));
        bufp->chgBit(oldp+22,(((IData)(vlSelf->tb_structural__DOT__dut__DOT__init_qty_p3) 
                               | (IData)(vlSelf->tb_structural__DOT__dut__DOT__do_dec_p3))));
        bufp->chgBit(oldp+23,(((IData)(vlSelf->tb_structural__DOT__dut__DOT__init_qty_p4) 
                               | (IData)(vlSelf->tb_structural__DOT__dut__DOT__do_dec_p4))));
        bufp->chgCData(oldp+24,(((IData)(vlSelf->tb_structural__DOT__dut__DOT__do_ok)
                                  ? (IData)(vlSelf->tb_structural__DOT__dut__DOT__sel_price)
                                  : (IData)(vlSelf->tb_structural__DOT__dut__DOT__current_price_q))),6);
        bufp->chgBit(oldp+25,(((~ (IData)(vlSelf->tb_structural__DOT__dut__DOT__clear_outputs)) 
                               & ((IData)(vlSelf->tb_structural__DOT__dut__DOT__do_ok)
                                   ? (IData)(vlSelf->tb_structural__DOT__dut__DOT__c_prod1)
                                   : (IData)(vlSelf->tb_structural__DOT__dut__DOT__prod1_q)))));
        bufp->chgBit(oldp+26,(((~ (IData)(vlSelf->tb_structural__DOT__dut__DOT__clear_outputs)) 
                               & ((IData)(vlSelf->tb_structural__DOT__dut__DOT__do_ok)
                                   ? (IData)(vlSelf->tb_structural__DOT__dut__DOT__c_prod2)
                                   : (IData)(vlSelf->tb_structural__DOT__dut__DOT__prod2_q)))));
        bufp->chgBit(oldp+27,(((~ (IData)(vlSelf->tb_structural__DOT__dut__DOT__clear_outputs)) 
                               & ((IData)(vlSelf->tb_structural__DOT__dut__DOT__do_ok)
                                   ? (IData)(vlSelf->tb_structural__DOT__dut__DOT__c_prod3)
                                   : (IData)(vlSelf->tb_structural__DOT__dut__DOT__prod3_q)))));
        bufp->chgBit(oldp+28,(((~ (IData)(vlSelf->tb_structural__DOT__dut__DOT__clear_outputs)) 
                               & ((IData)(vlSelf->tb_structural__DOT__dut__DOT__do_ok)
                                   ? (IData)(vlSelf->tb_structural__DOT__dut__DOT__c_prod4)
                                   : (IData)(vlSelf->tb_structural__DOT__dut__DOT__prod4_q)))));
        bufp->chgCData(oldp+29,(((IData)(vlSelf->tb_structural__DOT__dut__DOT__clear_outputs)
                                  ? 0U : ((IData)(vlSelf->tb_structural__DOT__dut__DOT__do_err)
                                           ? (((0U 
                                                == (IData)(vlSelf->tb_structural__DOT__dut__DOT__sel_qty)) 
                                               << 1U) 
                                              | (IData)(vlSelf->tb_structural__DOT__dut__DOT__credito_insuff))
                                           : (IData)(vlSelf->tb_structural__DOT__dut__DOT__errore_q)))),2);
        bufp->chgBit(oldp+30,(((IData)(vlSelf->tb_structural__DOT__dut__DOT__clear_outputs) 
                               | (IData)(vlSelf->tb_structural__DOT__dut__DOT__do_err))));
        bufp->chgCData(oldp+31,(((IData)(vlSelf->tb_structural__DOT__dut__DOT__clear_outputs)
                                  ? 0U : ((IData)(vlSelf->tb_structural__DOT__dut__DOT__do_erogazione)
                                           ? (IData)(vlSelf->tb_structural__DOT__dut__DOT__change6)
                                           : ((IData)(vlSelf->tb_structural__DOT__dut__DOT__do_cancel)
                                               ? (IData)(vlSelf->tb_structural__DOT__dut__DOT__credito_q)
                                               : (((IData)(vlSelf->tb_structural__DOT__dut__DOT__do_err) 
                                                   & (IData)(vlSelf->tb_structural__DOT__dut__DOT__credito_insuff))
                                                   ? (IData)(vlSelf->tb_structural__DOT__dut__DOT__sel_price)
                                                   : (IData)(vlSelf->tb_structural__DOT__dut__DOT__resto_q)))))),6);
        bufp->chgBit(oldp+32,(((IData)(vlSelf->tb_structural__DOT__dut__DOT__clear_outputs) 
                               | ((IData)(vlSelf->tb_structural__DOT__dut__DOT__do_cancel) 
                                  | ((IData)(vlSelf->tb_structural__DOT__dut__DOT__do_erogazione) 
                                     | (IData)(vlSelf->tb_structural__DOT__dut__DOT__do_err))))));
    }
    if (VL_UNLIKELY((vlSelf->__Vm_traceActivity[3U] 
                     | vlSelf->__Vm_traceActivity[6U]))) {
        bufp->chgBit(oldp+33,(vlSelf->tb_structural__DOT__dut__DOT__do_add_coin));
        bufp->chgBit(oldp+34,(vlSelf->tb_structural__DOT__dut__DOT__do_cancel));
        bufp->chgBit(oldp+35,(vlSelf->tb_structural__DOT__dut__DOT__do_err));
        bufp->chgBit(oldp+36,(vlSelf->tb_structural__DOT__dut__DOT__do_ok));
        bufp->chgBit(oldp+37,(vlSelf->tb_structural__DOT__dut__DOT__c_prod1));
        bufp->chgBit(oldp+38,(vlSelf->tb_structural__DOT__dut__DOT__c_prod2));
        bufp->chgBit(oldp+39,(vlSelf->tb_structural__DOT__dut__DOT__c_prod3));
        bufp->chgBit(oldp+40,(vlSelf->tb_structural__DOT__dut__DOT__c_prod4));
        bufp->chgBit(oldp+41,(vlSelf->tb_structural__DOT__dut__DOT__is_credito_suff));
        bufp->chgBit(oldp+42,((0U != (IData)(vlSelf->tb_structural__DOT__dut__DOT__sel_qty))));
        bufp->chgCData(oldp+43,(vlSelf->tb_structural__DOT__dut__DOT__sel_price),6);
        bufp->chgCData(oldp+44,(vlSelf->tb_structural__DOT__dut__DOT__sel_qty),6);
        bufp->chgBit(oldp+45,(vlSelf->tb_structural__DOT__dut__DOT__do_dec_p1));
        bufp->chgBit(oldp+46,(vlSelf->tb_structural__DOT__dut__DOT__do_dec_p2));
        bufp->chgBit(oldp+47,(vlSelf->tb_structural__DOT__dut__DOT__do_dec_p3));
        bufp->chgBit(oldp+48,(vlSelf->tb_structural__DOT__dut__DOT__do_dec_p4));
        bufp->chgBit(oldp+49,(vlSelf->tb_structural__DOT__dut__DOT__we_prod));
        bufp->chgCData(oldp+50,((((0U == (IData)(vlSelf->tb_structural__DOT__dut__DOT__sel_qty)) 
                                  << 1U) | (IData)(vlSelf->tb_structural__DOT__dut__DOT__credito_insuff))),2);
        bufp->chgBit(oldp+51,(vlSelf->tb_structural__DOT__dut__DOT__credito_insuff));
        bufp->chgBit(oldp+52,(vlSelf->tb_structural__DOT__dut__DOT__we_credito));
        bufp->chgCData(oldp+53,(vlSelf->tb_structural__DOT__dut__DOT__CTRL__DOT__next_stato),2);
    }
    if (VL_UNLIKELY(vlSelf->__Vm_traceActivity[4U])) {
        bufp->chgCData(oldp+54,(vlSelf->tb_structural__DOT__dut__DOT__credito_q),6);
        bufp->chgBit(oldp+55,(vlSelf->tb_structural__DOT__dut__DOT__prod1_q));
        bufp->chgBit(oldp+56,(vlSelf->tb_structural__DOT__dut__DOT__prod2_q));
        bufp->chgBit(oldp+57,(vlSelf->tb_structural__DOT__dut__DOT__prod3_q));
        bufp->chgBit(oldp+58,(vlSelf->tb_structural__DOT__dut__DOT__prod4_q));
        bufp->chgCData(oldp+59,(vlSelf->tb_structural__DOT__dut__DOT__errore_q),2);
        bufp->chgCData(oldp+60,(vlSelf->tb_structural__DOT__dut__DOT__resto_q),6);
        bufp->chgSData(oldp+61,(vlSelf->tb_structural__DOT__dut__DOT__disponibile_q),10);
        bufp->chgCData(oldp+62,(vlSelf->tb_structural__DOT__dut__DOT__coin01_q),6);
        bufp->chgCData(oldp+63,(vlSelf->tb_structural__DOT__dut__DOT__coin02_q),6);
        bufp->chgCData(oldp+64,(vlSelf->tb_structural__DOT__dut__DOT__coin05_q),6);
        bufp->chgCData(oldp+65,(vlSelf->tb_structural__DOT__dut__DOT__coin10_q),6);
        bufp->chgBit(oldp+66,(vlSelf->tb_structural__DOT__dut__DOT__mode_init));
        bufp->chgCData(oldp+67,(vlSelf->tb_structural__DOT__dut__DOT__init_counter_w),4);
        bufp->chgBit(oldp+68,(vlSelf->tb_structural__DOT__dut__DOT__clear_outputs));
        bufp->chgBit(oldp+69,(vlSelf->tb_structural__DOT__dut__DOT__do_erogazione));
        bufp->chgCData(oldp+70,(vlSelf->tb_structural__DOT__dut__DOT__sel_latched),3);
        bufp->chgCData(oldp+71,(vlSelf->tb_structural__DOT__dut__DOT__qty_p1_q),6);
        bufp->chgCData(oldp+72,(vlSelf->tb_structural__DOT__dut__DOT__qty_p2_q),6);
        bufp->chgCData(oldp+73,(vlSelf->tb_structural__DOT__dut__DOT__qty_p3_q),6);
        bufp->chgCData(oldp+74,(vlSelf->tb_structural__DOT__dut__DOT__qty_p4_q),6);
        bufp->chgCData(oldp+75,(vlSelf->tb_structural__DOT__dut__DOT__price_p1_q),6);
        bufp->chgCData(oldp+76,(vlSelf->tb_structural__DOT__dut__DOT__price_p2_q),6);
        bufp->chgCData(oldp+77,(vlSelf->tb_structural__DOT__dut__DOT__price_p3_q),6);
        bufp->chgCData(oldp+78,(vlSelf->tb_structural__DOT__dut__DOT__price_p4_q),6);
        bufp->chgCData(oldp+79,(vlSelf->tb_structural__DOT__dut__DOT__qty_c01_q),6);
        bufp->chgCData(oldp+80,(vlSelf->tb_structural__DOT__dut__DOT__qty_c02_q),6);
        bufp->chgCData(oldp+81,(vlSelf->tb_structural__DOT__dut__DOT__qty_c05_q),6);
        bufp->chgCData(oldp+82,(vlSelf->tb_structural__DOT__dut__DOT__qty_c10_q),6);
        bufp->chgCData(oldp+83,(vlSelf->tb_structural__DOT__dut__DOT__current_price_q),6);
        bufp->chgCData(oldp+84,(vlSelf->tb_structural__DOT__dut__DOT__change6),6);
        bufp->chgSData(oldp+85,(vlSelf->tb_structural__DOT__dut__DOT__change6),10);
        bufp->chgSData(oldp+86,(vlSelf->tb_structural__DOT__dut__DOT__credito_q),10);
        bufp->chgSData(oldp+87,((0x3ffU & ((IData)(vlSelf->tb_structural__DOT__dut__DOT__disponibile_q) 
                                           - (IData)(vlSelf->tb_structural__DOT__dut__DOT__credito_q)))),10);
        bufp->chgSData(oldp+88,((0x3ffU & ((IData)(vlSelf->tb_structural__DOT__dut__DOT__disponibile_q) 
                                           - (IData)(vlSelf->tb_structural__DOT__dut__DOT__change6)))),10);
        bufp->chgCData(oldp+89,(vlSelf->tb_structural__DOT__dut__DOT__c10_calc),6);
        bufp->chgCData(oldp+90,(vlSelf->tb_structural__DOT__dut__DOT__c05_calc),6);
        bufp->chgCData(oldp+91,(vlSelf->tb_structural__DOT__dut__DOT__c02_calc),6);
        bufp->chgCData(oldp+92,(vlSelf->tb_structural__DOT__dut__DOT__c01_calc),6);
        bufp->chgCData(oldp+93,(vlSelf->tb_structural__DOT__dut__DOT__qc10_next),6);
        bufp->chgCData(oldp+94,(vlSelf->tb_structural__DOT__dut__DOT__qc05_next),6);
        bufp->chgCData(oldp+95,(vlSelf->tb_structural__DOT__dut__DOT__qc02_next),6);
        bufp->chgCData(oldp+96,(vlSelf->tb_structural__DOT__dut__DOT__qc01_next),6);
        bufp->chgBit(oldp+97,(vlSelf->tb_structural__DOT__dut__DOT__init_qty_p1));
        bufp->chgBit(oldp+98,(vlSelf->tb_structural__DOT__dut__DOT__init_price_p1));
        bufp->chgBit(oldp+99,(vlSelf->tb_structural__DOT__dut__DOT__init_qty_p2));
        bufp->chgBit(oldp+100,(vlSelf->tb_structural__DOT__dut__DOT__init_price_p2));
        bufp->chgBit(oldp+101,(vlSelf->tb_structural__DOT__dut__DOT__init_qty_p3));
        bufp->chgBit(oldp+102,(vlSelf->tb_structural__DOT__dut__DOT__init_price_p3));
        bufp->chgBit(oldp+103,(vlSelf->tb_structural__DOT__dut__DOT__init_qty_p4));
        bufp->chgBit(oldp+104,(vlSelf->tb_structural__DOT__dut__DOT__init_price_p4));
        bufp->chgBit(oldp+105,(vlSelf->tb_structural__DOT__dut__DOT__init_c01));
        bufp->chgBit(oldp+106,(vlSelf->tb_structural__DOT__dut__DOT__init_c02));
        bufp->chgBit(oldp+107,(vlSelf->tb_structural__DOT__dut__DOT__init_c05));
        bufp->chgBit(oldp+108,(vlSelf->tb_structural__DOT__dut__DOT__init_c10));
        bufp->chgCData(oldp+109,((0x3fU & ((IData)(vlSelf->tb_structural__DOT__dut__DOT__qty_p1_q) 
                                           - (IData)(1U)))),6);
        bufp->chgCData(oldp+110,((0x3fU & ((IData)(vlSelf->tb_structural__DOT__dut__DOT__qty_p2_q) 
                                           - (IData)(1U)))),6);
        bufp->chgCData(oldp+111,((0x3fU & ((IData)(vlSelf->tb_structural__DOT__dut__DOT__qty_p3_q) 
                                           - (IData)(1U)))),6);
        bufp->chgCData(oldp+112,((0x3fU & ((IData)(vlSelf->tb_structural__DOT__dut__DOT__qty_p4_q) 
                                           - (IData)(1U)))),6);
        bufp->chgBit(oldp+113,(((IData)(vlSelf->tb_structural__DOT__dut__DOT__init_c01) 
                                | (IData)(vlSelf->tb_structural__DOT__dut__DOT__do_erogazione))));
        bufp->chgBit(oldp+114,(((IData)(vlSelf->tb_structural__DOT__dut__DOT__init_c02) 
                                | (IData)(vlSelf->tb_structural__DOT__dut__DOT__do_erogazione))));
        bufp->chgBit(oldp+115,(((IData)(vlSelf->tb_structural__DOT__dut__DOT__init_c05) 
                                | (IData)(vlSelf->tb_structural__DOT__dut__DOT__do_erogazione))));
        bufp->chgBit(oldp+116,(((IData)(vlSelf->tb_structural__DOT__dut__DOT__init_c10) 
                                | (IData)(vlSelf->tb_structural__DOT__dut__DOT__do_erogazione))));
        bufp->chgCData(oldp+117,(((IData)(vlSelf->tb_structural__DOT__dut__DOT__clear_outputs)
                                   ? 0U : ((IData)(vlSelf->tb_structural__DOT__dut__DOT__do_erogazione)
                                            ? (IData)(vlSelf->tb_structural__DOT__dut__DOT__c10_calc)
                                            : (IData)(vlSelf->tb_structural__DOT__dut__DOT__coin10_q)))),6);
        bufp->chgCData(oldp+118,(((IData)(vlSelf->tb_structural__DOT__dut__DOT__clear_outputs)
                                   ? 0U : ((IData)(vlSelf->tb_structural__DOT__dut__DOT__do_erogazione)
                                            ? (IData)(vlSelf->tb_structural__DOT__dut__DOT__c05_calc)
                                            : (IData)(vlSelf->tb_structural__DOT__dut__DOT__coin05_q)))),6);
        bufp->chgCData(oldp+119,(((IData)(vlSelf->tb_structural__DOT__dut__DOT__clear_outputs)
                                   ? 0U : ((IData)(vlSelf->tb_structural__DOT__dut__DOT__do_erogazione)
                                            ? (IData)(vlSelf->tb_structural__DOT__dut__DOT__c02_calc)
                                            : (IData)(vlSelf->tb_structural__DOT__dut__DOT__coin02_q)))),6);
        bufp->chgCData(oldp+120,(((IData)(vlSelf->tb_structural__DOT__dut__DOT__clear_outputs)
                                   ? 0U : ((IData)(vlSelf->tb_structural__DOT__dut__DOT__do_erogazione)
                                            ? (IData)(vlSelf->tb_structural__DOT__dut__DOT__c01_calc)
                                            : (IData)(vlSelf->tb_structural__DOT__dut__DOT__coin01_q)))),6);
        bufp->chgBit(oldp+121,(vlSelf->tb_structural__DOT__dut__DOT__we_coin_out));
        bufp->chgCData(oldp+122,(vlSelf->tb_structural__DOT__dut__DOT__CTRL__DOT__stato),2);
        bufp->chgCData(oldp+123,(vlSelf->tb_structural__DOT__dut__DOT__greedy_inst__DOT__calc_resto),6);
        bufp->chgCData(oldp+124,(vlSelf->tb_structural__DOT__dut__DOT__greedy_inst__DOT__calc_qty),6);
    }
    bufp->chgBit(oldp+125,(vlSelf->tb_structural__DOT__clk));
    bufp->chgCData(oldp+126,(vlSelf->tb_structural__DOT__dut__DOT__init_data),6);
    bufp->chgCData(oldp+127,(vlSelf->tb_structural__DOT__dut__DOT__coin_value),6);
    bufp->chgSData(oldp+128,(vlSelf->tb_structural__DOT__dut__DOT__coin_value),10);
    bufp->chgCData(oldp+129,((0x3fU & ((IData)(vlSelf->tb_structural__DOT__dut__DOT__init_qty_p1)
                                        ? (IData)(vlSelf->tb_structural__DOT__dut__DOT__init_data)
                                        : ((IData)(vlSelf->tb_structural__DOT__dut__DOT__qty_p1_q) 
                                           - (IData)(vlSelf->tb_structural__DOT__dut__DOT__do_dec_p1))))),6);
    bufp->chgCData(oldp+130,((0x3fU & ((IData)(vlSelf->tb_structural__DOT__dut__DOT__init_qty_p2)
                                        ? (IData)(vlSelf->tb_structural__DOT__dut__DOT__init_data)
                                        : ((IData)(vlSelf->tb_structural__DOT__dut__DOT__qty_p2_q) 
                                           - (IData)(vlSelf->tb_structural__DOT__dut__DOT__do_dec_p2))))),6);
    bufp->chgCData(oldp+131,((0x3fU & ((IData)(vlSelf->tb_structural__DOT__dut__DOT__init_qty_p3)
                                        ? (IData)(vlSelf->tb_structural__DOT__dut__DOT__init_data)
                                        : ((IData)(vlSelf->tb_structural__DOT__dut__DOT__qty_p3_q) 
                                           - (IData)(vlSelf->tb_structural__DOT__dut__DOT__do_dec_p3))))),6);
    bufp->chgCData(oldp+132,((0x3fU & ((IData)(vlSelf->tb_structural__DOT__dut__DOT__init_qty_p4)
                                        ? (IData)(vlSelf->tb_structural__DOT__dut__DOT__init_data)
                                        : ((IData)(vlSelf->tb_structural__DOT__dut__DOT__qty_p4_q) 
                                           - (IData)(vlSelf->tb_structural__DOT__dut__DOT__do_dec_p4))))),6);
    bufp->chgCData(oldp+133,(((IData)(vlSelf->tb_structural__DOT__dut__DOT____VdfgTmp_hf3f60487__0)
                               ? 0U : (0x3fU & ((IData)(vlSelf->tb_structural__DOT__dut__DOT__do_add_coin)
                                                 ? 
                                                ((IData)(vlSelf->tb_structural__DOT__dut__DOT__coin_value) 
                                                 + (IData)(vlSelf->tb_structural__DOT__dut__DOT__credito_q))
                                                 : (IData)(vlSelf->tb_structural__DOT__dut__DOT__credito_q))))),6);
    bufp->chgSData(oldp+134,((0x3ffU & ((IData)(vlSelf->tb_structural__DOT__dut__DOT__do_cancel)
                                         ? ((IData)(vlSelf->tb_structural__DOT__dut__DOT__disponibile_q) 
                                            - (IData)(vlSelf->tb_structural__DOT__dut__DOT__credito_q))
                                         : ((IData)(vlSelf->tb_structural__DOT__dut__DOT__do_erogazione)
                                             ? ((IData)(vlSelf->tb_structural__DOT__dut__DOT__disponibile_q) 
                                                - (IData)(vlSelf->tb_structural__DOT__dut__DOT__change6))
                                             : ((IData)(vlSelf->tb_structural__DOT__dut__DOT__do_add_coin)
                                                 ? 
                                                ((IData)(vlSelf->tb_structural__DOT__dut__DOT__disponibile_q) 
                                                 + (IData)(vlSelf->tb_structural__DOT__dut__DOT__coin_value))
                                                 : (IData)(vlSelf->tb_structural__DOT__dut__DOT__disponibile_q)))))),10);
}

void Vtb_structural___024root__trace_cleanup(void* voidSelf, VerilatedVcd* /*unused*/) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_structural___024root__trace_cleanup\n"); );
    // Init
    Vtb_structural___024root* const __restrict vlSelf VL_ATTR_UNUSED = static_cast<Vtb_structural___024root*>(voidSelf);
    Vtb_structural__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    // Body
    vlSymsp->__Vm_activity = false;
    vlSymsp->TOP.__Vm_traceActivity[0U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[1U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[2U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[3U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[4U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[5U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[6U] = 0U;
}
